-- BAR Droid: Kailil's BAR Controller Support v0.8.5 (c3352a7ba7488e6ad4f592a8b7b1c7db4d52f60c) as BAR's developer game.
-- Only v0.8.5's own files are here; the rest of the game is the BAR release it was ported to (depend).
return {
	name = "Beyond All Reason",
	description = "Beyond All Reason",
	shortName = "BYAR",
	version = "$VERSION",
	mutator = "Official",
	game = "Beyond All Reason",
	shortGame = "BYAR",
	modtype = 1,
	url = "https://www.beyondallreason.info",
	depend = { "Beyond All Reason test-31691-a617033" },
}
