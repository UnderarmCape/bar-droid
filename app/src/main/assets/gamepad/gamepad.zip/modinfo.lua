-- BAR Droid: Kailil's BAR Controller Support v0.8.5 (2c50ab82e485fc3de8a12b4c8aa51681081b0efa) as BAR's developer game.
-- Only v0.8.5's own files are here; the rest of the game is the BAR release it was ported to (depend).
return {
	name = "Beyond All Reason",
	description = "Beyond All Reason",
	shortName = "BYAR",
	version = "$VERSION",
	mutator = "Official",
	game = "Beyond All Reason",
	shortGame = "BYAR",
	modtype = 1,
	url = "https://www.beyondallreason.info",
	depend = { "Beyond All Reason test-31691-a617033" },
}
