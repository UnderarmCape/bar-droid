-- BAR Droid: one of BAR's developer tools, off in the phone's game (tools/build-gamepad-game.py DEV_TOOLS_OFF)
return
