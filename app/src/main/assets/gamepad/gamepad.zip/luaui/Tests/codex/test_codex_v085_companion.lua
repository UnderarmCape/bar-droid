-- attempt-01 v0.8.5, ported 1:1: the companion path end to end. The test launcher starts the companion
-- with --fake (a scripted pad: left stick full right for 1 s, then A held for 0.5 s, on a 4 s loop).
-- Its BARCTRL1 packets must reach the Controller Camera Test widget through controller_socket_bridge.lua,
-- switch it into controller mode, and the left stick must move the camera or the cursor.
-- Reads the widget as it runs in a normal game (widgetHandler:FindWidget), not reloaded "with locals".
local widgetName = "Controller Camera Test"
local WAIT_FRAMES = 30 * 20

-- headless renders an 8x8 view, so this needs a windowed engine (scripts/run-game-tests.ps1 -Codex)
local function skip()
	local _, viewHeight = Spring.GetViewGeometry()
	return Spring.GetGameFrame() <= 0 or viewHeight < 200
end

local function waitFor(predicate, failure)
	local ok = yieldable_pcall(Test.waitUntil, predicate, WAIT_FRAMES)
	assert(ok, type(failure) == "function" and failure() or failure)
end

-- the controller hooks v0.8.5's patched upstream widgets add (rebased onto current BAR), checked for
-- every widget that runs here (some remove themselves for the spectating test player)
local HOOKS = {
	{ "SmartSelect", "smartselect", "controllerApplyUnits" },
	{ "Smart Area Reclaim", "smartareareclaim", "controllerCompleteArea" },
	{ "Order menu", "ordermenu", "controllerCompleteTargetShape" },
	{ "Build menu", "buildmenu", "controllerGetItems" },
	{ "Area Mex", "controllerAreaMex", "issueArea" },
	{ "Build Split", "build_split", "controllerDistribute" },
	{ "CustomFormations2", "customformations", "controllerCompleteShape" },
	{ "Idle Builders", "idlebuilders", "controllerGetLiveIdleEntries" },
}

local function test()
	local camera = widgetHandler:FindWidget(widgetName)
	assert(camera, widgetName .. " is not running")
	local checked = {}
	for _, hook in ipairs(HOOKS) do
		if widgetHandler:FindWidget(hook[1]) then
			local api = WG[hook[2]]
			assert(api and type(api[hook[3]]) == "function", "missing hook WG." .. hook[2] .. "." .. hook[3])
			checked[hook[1]] = true
		end
	end
	assert(checked["Order menu"] and checked["Build menu"], "the patched Order menu and Build menu must run")
	local function status()
		return tostring(camera.ControllerCameraTestInputBackend) .. " / " .. tostring(camera.ControllerCameraTestBridgeStatus)
	end

	waitFor(function()
		return camera.ControllerCameraTestInputBackend == "companion UDP bridge"
	end, function()
		return "the widget is not reading the companion bridge: " .. status()
	end)
	waitFor(function()
		local bridge = camera.ControllerCameraTestSocketBridge
		return bridge ~= nil and bridge:IsFresh()
	end, function()
		return "no fresh packets from the companion: " .. status()
	end)

	local startCamera = Spring.GetCameraState()
	local startX = Spring.GetMouseState()
	waitFor(function()
		return camera.controllerMode == true
	end, "the companion's input did not switch the widget into controller mode")
	waitFor(function()
		local cam = Spring.GetCameraState()
		local mouseX = Spring.GetMouseState()
		local panned = math.abs((cam.px or 0) - (startCamera.px or 0)) + math.abs((cam.pz or 0) - (startCamera.pz or 0))
		return panned > 50 or math.abs(mouseX - startX) > 40
	end, "the companion's left stick moved neither the camera nor the cursor")
end

return { skip = skip, test = test }
