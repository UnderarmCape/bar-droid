-- BAR 2026.10 compatibility: v0.8.5's selected-unit status panel ("Constructor Status") is anchored at
-- the bottom right, where BAR's player list and its docked panels (game info, music, ...) sit and draw
-- over it. With a commander selected in controller mode, the panel must overlap none of them.
-- Run with the companion's scripted pad (scripts/run-game-tests.ps1 -Codex -CompanionArgs "--fake --codex").
local widgetName = "Controller Camera Test"
local WAIT_FRAMES = 30 * 20
local PANELS = { "advplayerlist_api", "displayinfo", "music", "unittotals", "advplayerlist_mascot", "playertv" }

local function skip()
	local _, viewHeight = Spring.GetViewGeometry()
	return Spring.GetGameFrame() <= 0 or viewHeight < 200
end

local function waitFor(predicate, failure)
	local ok = yieldable_pcall(Test.waitUntil, predicate, WAIT_FRAMES)
	assert(ok, type(failure) == "function" and failure() or failure)
end

local function findCommander()
	for _, unitID in ipairs(Spring.GetAllUnits()) do
		local unitDef = UnitDefs[Spring.GetUnitDefID(unitID)]
		if unitDef and unitDef.customParams and unitDef.customParams.iscommander then
			return unitID
		end
	end
end

local function test()
	local camera = widgetHandler:FindWidget(widgetName)
	assert(camera, widgetName .. " is not running")
	local commanderID = findCommander()
	assert(commanderID, "no commander on the map")

	waitFor(function()
		return camera.controllerMode == true
	end, "the companion's input did not switch the widget into controller mode")
	-- the scripted pad taps A now and then, which can change the selection: select again until drawn
	waitFor(function()
		Spring.SelectUnitArray({ commanderID })
		return camera.ControllerCameraTestSelectedStatus.mode == "constructor"
	end, "the Constructor Status panel did not show for the selected commander")

	local bounds = camera.ControllerCameraTestGetControllerUIBounds("selectedStatus", 294, 94)
	assert(bounds, "no layout bounds for the status panel")
	local x1, width, height = bounds.x1, 294 * bounds.scale, 94 * bounds.scale
	local y1 = camera.ControllerCameraTestStatusPanelClearY(x1, bounds.y1, width, height)

	-- the test player is a spectator, so PlayerTV's buttons show too
	local checked = 0
	for _, apiName in ipairs(PANELS) do
		local api = WG[apiName]
		if type(api) == "table" and type(api.GetPosition) == "function" then
			local position = api.GetPosition()
			if type(position) == "table" and position[1] > position[3] then
				local top, left, bottom, right = position[1], position[2], position[3], position[4]
				local overlaps = x1 < right and x1 + width > left and y1 < top and y1 + height > bottom
				assert(not overlaps, string.format("status panel (%d,%d %dx%d) overlaps %s (%d..%d, %d..%d)",
					x1, y1, width, height, apiName, left, right, bottom, top))
				checked = checked + 1
			end
		end
	end
	assert(checked > 0, "none of BAR's bottom-right panels is running (expected the player list)")
	Spring.Echo(string.format("[codex test] status panel at %d,%d (layout y %d), clear of %d BAR panels", x1, y1, bounds.y1, checked))
	Test.waitFrames(30)
	Spring.SendCommands("screenshot png")
	Test.waitFrames(5)
	local status = camera.ControllerCameraTestSelectedStatus
	Spring.Echo(string.format("[codex test] after the screenshot: panel %s (%s), %d selected, controller mode %s",
		tostring(status.mode), tostring(status.lastResult), #Spring.GetSelectedUnits(), tostring(camera.controllerMode)))
end

return { skip = skip, test = test }
