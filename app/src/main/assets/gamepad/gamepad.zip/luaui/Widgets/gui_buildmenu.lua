local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Build menu (controller)", -- BAR Droid: tools/build-gamepad-game.py
		desc = "",
		author = "Floris",
		date = "April 2020",
		license = "GNU GPL, v2 or later",
		layer = 0,
		enabled = false,
		handler = true,
	}
end

-- Localized functions for performance
local mathFloor = math.floor
local mathMax = math.max

-- Localized Spring API for performance
local spGetGameFrame = Spring.GetGameFrame
local spGetGameSeconds = Spring.GetGameSeconds
local spGetMyTeamID = Spring.GetLocalTeamID
local spGetViewGeometry = Spring.GetViewGeometry
local spGetSpectatingState = Spring.GetSpectatingState

include("keysym.h.lua")
local dynamicBuildOptions = require("common/dynamicBuildOptions")
local ControllerNativeBuildCellRenderer = VFS.Include('luaui/Include/controller_native_build_cell_renderer.lua')

local pairs = pairs
local ipairs = ipairs
local tonumber = tonumber
local string_format = string.format
local table_invert = table.invert
local pcall = pcall
--- CHANGE START ---
-- Helper function to clear a table without creating garbage, using the standard Lua method.
local function clearTable(t)
	for k in pairs(t) do
		t[k] = nil
	end
end
--- CHANGE END ---

SYMKEYS = table_invert(KEYSYMS)

local CMD_STOP_PRODUCTION = GameCMD.STOP_PRODUCTION

local comBuildOptions
local boundUnits = {}
local stickToBottom = false

local alwaysShow = false

local cfgCellPadding = 0.007
local cfgIconPadding = 0.015 -- space between icons
local cfgIconCornerSize = 0.025
local cfgPriceFontSizeFourColls = 0.16
local cfgPriceFontSizeFiveColls = 0.19
local cfgActiveAreaMargin = 0.1 -- (# * bgpadding) space between the background border and active area

local defaultColls = 5
local dynamicIconsize = true
local minColls = 4
local maxColls = 5

local smartOrderUnits = true

local maxPosY = 0.74

local disableInputWhenSpec = false -- disable specs selecting buildoptions

local showPrice = true -- false will still show hover
local showRadarIcon = true -- false will still show hover
local showGroupIcon = true -- false will still show hover
local showBuildProgress = true
local progressColor = { 0.08, 0.08, 0.08, 0.6 }
local drawnBuildTargets = {}

-- Highlight API state: { [unitDefID] = { color={r,g,b}, startTime=os_clock() } }
local highlights = {}
local highlightCount = 0
local defaultHighlightColor = { 1.0, 1.0, 1.0 }
local controllerFocusDefID
local controllerInputActive = false
ControllerBuildMenuHybridState = ControllerBuildMenuHybridState or {
	radialOpen = false, focusVisible = true, focusRevision = 0, modelRevision = 0, focusSource = "none",
}

local zoomMult = 1.5
local defaultCellZoom = 0.025 * zoomMult
local rightclickCellZoom = 0.033 * zoomMult
local clickCellZoom = 0.07 * zoomMult
local hoverCellZoom = 0.05 * zoomMult
local clickSelectedCellZoom = 0.125 * zoomMult
local selectedCellZoom = 0.135 * zoomMult

local bgpadding, activeAreaMargin
local dlistGuishader, dlistBuildmenuBg, dlistBuildmenu, font2
local doUpdate, ordermenuHeight, prevAdvplayerlistLeft
local cellPadding, iconPadding, cornerSize, cellInnerSize, cellSize, priceFontSize
local activeCmd, selBuildQueueDefID
local prevHoveredCellID, hoverDlist
local buildmenuTexHasContent = false
local buildmenuRenderedCells = 0

local math_isInRect = math.isInRect

local buildmenuShows = false
local controllerPanelVisible = true
local refreshBuildmenu = true
local delayRefresh

local costOverrides = {}
--[[ MODIFICATION START ]]
-- New state variables for the robust update system
local selectionUpdateTime = 0 -- Time-based debouncer for selection changes
local raceConditionUpdateCountdown = 0 -- Timer for race conditions
local forceRefreshNextFrame = false -- The failsafe retry flag
local refreshRetryCounter = 0 -- Failsafe counter to prevent infinite retries
--[[ MODIFICATION END ]]

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

local playSounds = true
local sound_queue_add = "LuaUI/Sounds/buildbar_add.wav"
local sound_queue_rem = "LuaUI/Sounds/buildbar_rem.wav"

local vsx, vsy = spGetViewGeometry()

local ordermenuLeft = mathFloor(vsx / 5)
local advplayerlistLeft = vsx * 0.8

local ui_opacity = Spring.GetConfigFloat("ui_opacity", 0.7)
local ui_scale = Spring.GetConfigFloat("ui_scale", 1)

local units = require("luaui/configs/unit_buildmenu_config")

local isSpec = spGetSpectatingState()
local myTeamID = spGetMyTeamID()

local startDefID = Spring.GetTeamRulesParam(myTeamID, "startUnit")

local disableInput = disableInputWhenSpec and isSpec
---@type ScreenRect
local backgroundRect = { 0, 0, 0, 0 }
local colls = 5
local rows = 5
local minimapHeight = 0.235
local posY = 0
local posY2 = 0
local posX = 0
local posX2 = 0.2
local width = 0
local height = 0
local selectedBuilders = {}
local selectedBuilderCount = 0
local selectedFactoryCount = 0
local prevAnyFactoryUnfinished = false
local cellRects = {}
local cmds = {}
local cmdsCount = 0
local currentPage = 1
local pages = 1
local paginatorRects = {}
local preGamestartPlayer = spGetGameFrame() == 0 and not isSpec

local unitDefToCellMap = {}
local cellQuotas = {}

-- Reusable tables to reduce allocations in hot paths
local cmdUnitdefsTemp = {}
local selBuilderDefsTemp1 = {}
local selBuilderDefsTemp2 = {}
local currentSelBuilderDefs = selBuilderDefsTemp1 -- Track which temp table is current
local buildCycleTemp = {}
local emptyParams = {}
local buildmenuUnitpicWarm = { warmed = {}, queued = {}, queuedSet = {}, count = 0 }
local buildmenuUnitpicWarmPerFrame = 2

-- Cache for expensive Spring API calls
local cachedActiveCmdDescs = nil
local cachedActiveCmdDescsTime = 0
local activeCmdDescsCacheDelay = 0.05 -- Cache for 50ms

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

local unitName = {}
local unitBuildOptions = {}
local unitBuildOptionSet = {} -- unitDefID -> { buildOptionDefID = true }
local unitMetal_extractor = {}
local unitTranslatedHumanName = {}
local unitTranslatedTooltip = {}
local iconTypes = {}
local function refreshUnitDefs()
	unitName = {}
	unitBuildOptions = {}
	unitBuildOptionSet = {}
	unitMetal_extractor = {}
	unitTranslatedHumanName = {}
	unitTranslatedTooltip = {}
	iconTypes = {}
	local orgIconTypes = require("gamedata/icontypes")
	for udid, ud in pairs(UnitDefs) do
		unitName[udid] = ud.name
		unitBuildOptions[udid] = ud.buildOptions
		unitTranslatedHumanName[udid] = ud.translatedHumanName
		unitTranslatedTooltip[udid] = ud.translatedTooltip
		if ud.customParams.metal_extractor then
			unitMetal_extractor[udid] = ud.customParams.metal_extractor
		end
		if ud.iconType and orgIconTypes[ud.iconType] and orgIconTypes[ud.iconType].bitmap then
			iconTypes[ud.name] = orgIconTypes[ud.iconType].bitmap
		end
	end
	dynamicBuildOptions.apply(unitBuildOptions)
	for udid, buildOptions in pairs(unitBuildOptions) do
		local set = {}
		for i = 1, #buildOptions do
			set[buildOptions[i]] = true
		end
		unitBuildOptionSet[udid] = set
	end
end

local spIsUnitSelected = Spring.IsUnitSelected
local spGetSelectedUnitsCount = Spring.GetSelectedUnitsCount
local spGetSelectedUnits = Spring.GetSelectedUnits
local spGetActiveCommand = Spring.GetActiveCommand
local spGetActiveCmdDescs = Spring.GetActiveCmdDescs
local spGetCmdDescIndex = Spring.GetCmdDescIndex
local spGetUnitDefID = Spring.GetUnitDefID
local spGetTeamRulesParam = Spring.GetTeamRulesParam
local spGetMouseState = Spring.GetMouseState
local spGetUnitIsBeingBuilt = Spring.GetUnitIsBeingBuilt
local spGetUnitIsBuilding = Spring.GetUnitIsBuilding

local SelectedUnitsCount = spGetSelectedUnitsCount()

local string_sub = string.sub
local os_clock = os.clock

local math_floor = mathFloor
local math_ceil = math.ceil
local math_max = mathMax
local math_min = math.min

local glTexture = gl.Texture
local glColor = gl.Color
local glBlending = gl.Blending
local GL_SRC_ALPHA = GL.SRC_ALPHA
local GL_ONE_MINUS_SRC_ALPHA = GL.ONE_MINUS_SRC_ALPHA
local GL_ONE = GL.ONE
local GL_DST_ALPHA = GL.DST_ALPHA
local GL_ONE_MINUS_SRC_COLOR = GL.ONE_MINUS_SRC_COLOR

-- Helper function for cached Spring API calls (must be after localizations)
local function getCachedActiveCmdDescs()
	local now = os_clock()
	if not cachedActiveCmdDescs or (now - cachedActiveCmdDescsTime) > activeCmdDescsCacheDelay then
		cachedActiveCmdDescs = spGetActiveCmdDescs()
		cachedActiveCmdDescsTime = now
	end
	return cachedActiveCmdDescs
end

---Greyed out when blocked for the team, or for every selected builder type that offers it.
local function isUnitRestricted(uDefID)
	if preGamestartPlayer then
		return units.isRestricted(uDefID, startDefID)
	end
	if units.unitRestricted[uDefID] then
		return true
	end
	local anyBlocked = false
	for builderDefID in pairs(currentSelBuilderDefs) do
		local blocked = units.builderUnitRestricted[builderDefID]
		if blocked and blocked[uDefID] then
			anyBlocked = true
		elseif unitBuildOptionSet[builderDefID][uDefID] then
			return false -- a selected builder of another type can still build it
		end
	end
	return anyBlocked
end

local function clearBuildmenuUnitpicWarmQueue()
	local warm = buildmenuUnitpicWarm
	for defID in pairs(warm.queuedSet) do
		warm.queuedSet[defID] = nil
	end
	for i = 1, warm.count do
		warm.queued[i] = nil
	end
	warm.count = 0
end

local function queueBuildmenuUnitpicWarm(unitDefID)
	local warm = buildmenuUnitpicWarm
	if unitDefID and not warm.warmed[unitDefID] and not warm.queuedSet[unitDefID] then
		warm.count = warm.count + 1
		warm.queued[warm.count] = unitDefID
		warm.queuedSet[unitDefID] = true
	end
end

local function queueBuildmenuUnitpicWarmFromCommands()
	clearBuildmenuUnitpicWarmQueue()
	local numCellsPerPage = rows * colls
	local startCellID = numCellsPerPage * (currentPage - 1)
	local maxCellRectID = numCellsPerPage * currentPage
	if maxCellRectID > cmdsCount then
		maxCellRectID = cmdsCount
	end
	for cellRectID = startCellID + 1, maxCellRectID do
		local cmd = cmds[cellRectID]
		if cmd and cmd.id then
			queueBuildmenuUnitpicWarm(-cmd.id)
		end
	end
end

local function flushBuildmenuUnitpicWarmQueue()
	local warm = buildmenuUnitpicWarm
	local count = warm.count
	if count <= 0 then
		return true
	end

	tracy.ZoneBeginN("W:BuildMenu:UnitpicWarmup")
	local limit = math_min(count, buildmenuUnitpicWarmPerFrame)
	for i = 1, limit do
		local unitDefID = warm.queued[i]
		if unitDefID then
			if glTexture("#" .. unitDefID) then
				warm.warmed[unitDefID] = true
			end
			warm.queuedSet[unitDefID] = nil
		end
	end
	glTexture(false)
	if limit < count then
		for i = limit + 1, count do
			local unitDefID = warm.queued[i]
			local newIndex = i - limit
			warm.queued[newIndex] = unitDefID
			warm.queued[i] = nil
		end
		warm.count = count - limit
	else
		for i = 1, count do
			warm.queued[i] = nil
		end
		warm.count = 0
	end
	tracy.ZoneEnd()

	return warm.count == 0
end

local RectRound, RectRoundProgress, UiUnit, UiElement, UiButton, elementCorner

local folder = "LuaUI/Images/groupicons/"
local groups = {
	energy = folder .. "energy.png",
	metal = folder .. "metal.png",
	builder = folder .. "builder.png",
	buildert2 = folder .. "buildert2.png",
	buildert3 = folder .. "buildert3.png",
	buildert4 = folder .. "buildert4.png",
	util = folder .. "util.png",
	weapon = folder .. "weapon.png",
	explo = folder .. "weaponexplo.png",
	weaponaa = folder .. "weaponaa.png",
	weaponsub = folder .. "weaponsub.png",
	aa = folder .. "aa.png",
	emp = folder .. "emp.png",
	sub = folder .. "sub.png",
	nuke = folder .. "nuke.png",
	antinuke = folder .. "antinuke.png",
}

local modKeyMultiplier = {
	ctrl = 20,
	shift = 5,
	right = -1,
}

local function isFiniteNumber(value)
	return value and value == value and value > -math.huge and value < math.huge
end

local function isValidRect(x1, y1, x2, y2)
	return isFiniteNumber(x1)
		and isFiniteNumber(y1)
		and isFiniteNumber(x2)
		and isFiniteNumber(y2)
		and x2 > x1
		and y2 > y1
end

local function isValidBuildmenuGeometry()
	return isValidRect(backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4])
		and isFiniteNumber(width)
		and isFiniteNumber(height)
		and width > 0
		and height > 0
		and isFiniteNumber(cellSize)
		and cellSize > 0
		and isFiniteNumber(cellPadding)
		and isFiniteNumber(iconPadding)
		and cellSize > ((cellPadding + iconPadding) * 2)
end

local function checkGuishader(force)
	if WG.guishader then
		if force and dlistGuishader then
			dlistGuishader = gl.DeleteList(dlistGuishader)
		end
		if
			not dlistGuishader
			and isValidRect(backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4])
		then
			dlistGuishader = gl.CreateList(function()
				RectRound(backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4], elementCorner)
			end)
			if selectedBuilderCount > 0 then
				WG.guishader.InsertDlist(dlistGuishader, "buildmenu")
			end
		end
	elseif dlistGuishader then
		dlistGuishader = gl.DeleteList(dlistGuishader)
	end
end

function widget:PlayerChanged(playerID)
	isSpec = spGetSpectatingState()
	myTeamID = spGetMyTeamID()
end

local function UpdateGridGeometry()
	tracy.ZoneBeginN("W:BuildMenu:UpdateGridGeometry")
	local activeArea = {
		backgroundRect[1] + (stickToBottom and bgpadding or 0) + activeAreaMargin,
		backgroundRect[2] + (stickToBottom and 0 or bgpadding) + activeAreaMargin,
		backgroundRect[3] - bgpadding - activeAreaMargin,
		backgroundRect[4] - bgpadding - activeAreaMargin,
	}
	local contentHeight = activeArea[4] - activeArea[2]
	local contentWidth = activeArea[3] - activeArea[1]
	local maxCellSize = contentHeight / 2
	-- CONTROLLER NATIVE UI INTEGRATION: use fewer native grid columns while
	-- gamepad input is stable.  This enlarges the existing cells and their
	-- authoritative icons/costs without creating a second build renderer.
	local gridDefaultColls = controllerInputActive and math_max(3, defaultColls - 1) or defaultColls
	local gridMinColls = controllerInputActive and math_max(4, minColls - (stickToBottom and 2 or 0)) or minColls
	local gridMaxColls = controllerInputActive
		and (stickToBottom and math_max(gridMinColls, math_min(maxColls, 12)) or gridMinColls)
		or maxColls
	-- determine grid size
	if not dynamicIconsize then
		colls = gridDefaultColls
		cellSize = math_min(maxCellSize, math_floor((contentWidth / colls)))
		rows = math_floor(contentHeight / cellSize)
	else
		colls = gridMinColls
		cellSize = math_min(maxCellSize, math_floor((contentWidth / colls)))

		rows = math_floor(contentHeight / cellSize)
		if gridMinColls < gridMaxColls then
			while cmdsCount > rows * colls do
				colls = colls + 1
				cellSize = math_min(maxCellSize, math_floor((contentWidth / colls)))
				rows = math_floor(contentHeight / cellSize)
				if colls == gridMaxColls then
					break
				end
			end
		end
		if stickToBottom then
			if rows > 1 and cmdsCount <= (colls - 1) * rows then
				colls = colls - 1
				cellSize = math_min(maxCellSize, math_floor((contentHeight / rows)))
			end
		end
	end

	-- adjust grid size when pages are needed
	local paginatorCellHeight = math_floor(contentHeight - (rows * cellSize))
	if cmdsCount > colls * rows then
		pages = math_ceil(cmdsCount / (colls * rows))
		-- when more than 1 page: reserve bottom row for paginator and calc again
		if pages > 1 then
			pages = math_ceil(cmdsCount / (colls * (rows - 1)))
		end
		if currentPage > pages then
			currentPage = pages
		end

		-- remove a row if there isn't enough room for the paginator UI
		if not stickToBottom then
			if paginatorCellHeight < (0.06 * (1 - ((colls / 4) * 0.25))) * vsy then
				rows = rows - 1
			end
		else
			if paginatorCellHeight < (0.06 * (1 - ((rows / 4) * 0.25))) * vsx then
				colls = colls - 1
			end
		end
	else
		currentPage = 1
		pages = 1
	end

	-- these are globals so it can be reused (hover highlight)
	cellPadding = math_floor(cellSize * cfgCellPadding)
	iconPadding = math_max(1, math_floor(cellSize * cfgIconPadding))
	cornerSize = math_floor(cellSize * cfgIconCornerSize)
	cellInnerSize = cellSize - cellPadding - cellPadding
	priceFontSize =
		math_floor((cellInnerSize * (colls == 5 and cfgPriceFontSizeFiveColls or cfgPriceFontSizeFourColls)) + 0.5)
	tracy.ZoneEnd()
end

local function RefreshCommands()
	tracy.ZoneBeginN("W:BuildMenu:RefreshCommands")
	tracy.ZoneBeginN("W:BuildMenu:RefreshCommands:Collect")
	-- Clear and reuse cmds table instead of creating new one
	for i = #cmds, 1, -1 do
		cmds[i] = nil
	end
	cmdsCount = 0
	clearTable(cellRects)

	if preGamestartPlayer then
		if startDefID then
			-- Clear and reuse temp table instead of creating new one
			clearTable(cmdUnitdefsTemp)
			for i, udefid in ipairs(unitBuildOptions[startDefID]) do
				cmdUnitdefsTemp[udefid] = i
			end
			for k, uDefID in ipairs(units.unitOrder) do
				if cmdUnitdefsTemp[uDefID] and not units.unitHidden[uDefID] then
					cmdsCount = cmdsCount + 1
					-- mimic output of spGetActiveCmdDescs
					cmds[cmdsCount] = {
						id = -uDefID,
						name = unitName[uDefID],
						params = emptyParams,
					}
				end
			end
		end
	else
		local activeCmdDescs = getCachedActiveCmdDescs()
		if smartOrderUnits then
			-- Clear and reuse temp table instead of creating new one
			clearTable(cmdUnitdefsTemp)
			for index, cmd in ipairs(activeCmdDescs) do
				if type(cmd) == "table" then
					if not cmd.disabled and string_sub(cmd.action, 1, 10) == "buildunit_" then
						cmdUnitdefsTemp[-cmd.id] = index
					end
				end
			end
			for k, uDefID in ipairs(units.unitOrder) do
				if cmdUnitdefsTemp[uDefID] and not units.unitHidden[uDefID] then
					cmdsCount = cmdsCount + 1
					cmds[cmdsCount] = activeCmdDescs[cmdUnitdefsTemp[uDefID]]
				end
			end
		else
			for index, cmd in ipairs(activeCmdDescs) do
				if type(cmd) == "table" then
					local uDefID = -cmd.id
					if
						not cmd.disabled
						and string_sub(cmd.action, 1, 10) == "buildunit_"
						and not units.unitHidden[uDefID]
					then
						cmdsCount = cmdsCount + 1
						cmds[cmdsCount] = cmd
					end
				end
			end
		end
	end
	tracy.ZoneEnd()

	--[[ MODIFICATION START ]]
	-- Failsafe check with reset logic
	if (not preGamestartPlayer) and cmdsCount == 0 and selectedBuilderCount > 0 then
		forceRefreshNextFrame = true
		refreshRetryCounter = 10 -- Set a retry limit
	else
		-- On success, explicitly cancel any ongoing retry
		forceRefreshNextFrame = false
		refreshRetryCounter = 0
	end
	--[[ MODIFICATION END ]]

	tracy.ZoneBeginN("W:BuildMenu:RefreshCommands:GridGeometry")
	UpdateGridGeometry()
	tracy.ZoneEnd()
	queueBuildmenuUnitpicWarmFromCommands()

	--- CHANGE START ---
	tracy.ZoneBeginN("W:BuildMenu:RefreshCommands:CellMap")
	clearTable(unitDefToCellMap)
	clearTable(cellQuotas)
	--- CHANGE END ---

	local numCellsPerPage = rows * colls
	local startCellID = numCellsPerPage * (currentPage - 1)
	for i = 1, numCellsPerPage do
		local cellRectID = startCellID + i
		if cmds[cellRectID] then
			local uDefID = -cmds[cellRectID].id
			unitDefToCellMap[uDefID] = cellRectID
		end
	end
	tracy.ZoneEnd()

	if WG.Quotas then
		tracy.ZoneBeginN("W:BuildMenu:RefreshCommands:Quotas")
		local quotas = WG.Quotas.getQuotas()
		for _, factoryID in ipairs(spGetSelectedUnits()) do
			if quotas[factoryID] then
				for uDefID, quotaValue in pairs(quotas[factoryID]) do
					cellQuotas[uDefID] = {
						builderID = factoryID,
						quota = quotaValue,
					}
				end
			end
		end
		tracy.ZoneEnd()
	end
	ControllerBuildMenuHybridState.modelRevision = ControllerBuildMenuHybridState.modelRevision + 1
	tracy.ZoneEnd()
end

local function clear()
	refreshBuildmenu = true
	dlistBuildmenu = gl.DeleteList(dlistBuildmenu)
	dlistBuildmenuBg = gl.DeleteList(dlistBuildmenuBg)
	hoverDlist = gl.DeleteList(hoverDlist)
	prevHoveredCellID = nil
	if buildmenuTex then
		gl.DeleteTexture(buildmenuBgTex)
		buildmenuBgTex = nil
		gl.DeleteTexture(buildmenuTex)
		buildmenuTex = nil
		buildmenuTexHasContent = false
	end
end

function widget:ViewResize()
	tracy.ZoneBeginN("W:BuildMenu:ViewResize")
	vsx, vsy = spGetViewGeometry()

	local outlineMult = math.clamp(1 / (vsy / 1400), 1, 1.5)
	font2 = WG.fonts.getFont(2)

	if WG.minimap then
		minimapHeight = WG.minimap.getHeight()
	end

	local widgetSpaceMargin = WG.FlowUI.elementMargin
	bgpadding = WG.FlowUI.elementPadding
	elementCorner = WG.FlowUI.elementCorner

	RectRound = WG.FlowUI.Draw.RectRound
	RectRoundProgress = WG.FlowUI.Draw.RectRoundProgress
	UiUnit = WG.FlowUI.Draw.Unit
	UiButton = WG.FlowUI.Draw.Button
	UiElement = WG.FlowUI.Draw.Element

	activeAreaMargin = math_ceil(bgpadding * cfgActiveAreaMargin)

	if stickToBottom then
		posY = math_floor(0.14 * ui_scale * vsy) / vsy
		posY2 = 0
		posX = ordermenuLeft + widgetSpaceMargin
		posX2 = advplayerlistLeft - widgetSpaceMargin
		width = (posX2 - posX) / vsx
		height = posY
		minColls = math_max(8, math_floor((width / vsx) * 25))
		maxColls = 30
	else
		posY = math.clamp(((vsy - minimapHeight) / vsy) - (widgetSpaceMargin / vsy), 0.4615, maxPosY)
		posY2 = math_floor(0.14 * ui_scale * vsy) / vsy
		posY2 = posY2 + (widgetSpaceMargin / vsy)
		posX = 0
		minColls = 4
		maxColls = 5

		if WG.minimap then
			posY = 1 - (WG.minimap.getHeight() / vsy) - (widgetSpaceMargin / vsy)
			if posY > maxPosY then
				posY = maxPosY
			end

			if WG.ordermenu then
				local oposX, oposY, owidth, oheight = WG.ordermenu.getPosition()
				if oposY > 0.5 then
					posY = oposY - oheight - (widgetSpaceMargin / vsy)
				end
			end
		end

		posY = math_floor(posY * vsy) / vsy
		posX = math_floor(posX * vsx) / vsx

		height = (posY - posY2)
		width = 0.212

		width = width / (vsx / vsy) * 1.78 -- make smaller for ultrawide screens
		width = width * ui_scale

		posX2 = math_floor(width * vsx)

		-- make pixel aligned
		width = math_floor(width * vsx) / vsx
		height = math_floor(height * vsy) / vsy
	end

	backgroundRect = { posX, (posY - height) * vsy, posX2, posY * vsy }

	checkGuishader(true)
	clear()
	doUpdate = true
	if cmdsCount > 0 then
		UpdateGridGeometry()
	end
	tracy.ZoneEnd()
end

function widget:LanguageChanged()
	refreshUnitDefs()
	clear()
	doUpdate = true
end

-- update queue number
function widget:UnitFromFactory(unitID, unitDefID, unitTeam, factID, factDefID, userOrders)
	if spIsUnitSelected(factID) then
		raceConditionUpdateCountdown = 2
	end
end

local sec = 0
function widget:Update(dt)
	tracy.ZoneBeginN("W:BuildMenu:Update")
	if delayRefresh and spGetGameSeconds() >= delayRefresh then
		clear()
		doUpdate = true
		delayRefresh = nil
	end
	--[[ MODIFICATION START ]]
	-- Check failsafe retry flag
	if forceRefreshNextFrame and refreshRetryCounter > 0 then
		doUpdate = true
		refreshRetryCounter = refreshRetryCounter - 1
		if refreshRetryCounter == 0 then
			forceRefreshNextFrame = false
		end
	end

	-- Debounced selection update logic (time-based)
	if selectionUpdateTime > 0 then
		tracy.ZoneBeginN("W:BuildMenu:Update:Selection")
		local now = os_clock()
		if now >= selectionUpdateTime then
			selectionUpdateTime = 0
			-- The old `updateSelection = false` is no longer needed
			-- The rest of the original logic from `if updateSelection` block is moved here
			selectedBuilders = {}
			selectedBuilderCount = 0
			local prevSelectedFactoryCount = selectedFactoryCount
			selectedFactoryCount = 0

			-- Swap to the other temp table (ping-pong buffering)
			local prevSelBuilderDefs = currentSelBuilderDefs
			currentSelBuilderDefs = (currentSelBuilderDefs == selBuilderDefsTemp1) and selBuilderDefsTemp2
				or selBuilderDefsTemp1
			clearTable(currentSelBuilderDefs)

			SelectedUnitsCount = spGetSelectedUnitsCount()
			if SelectedUnitsCount > 0 then
				local sel = Spring.GetSelectedUnits()
				for _, unitID in ipairs(sel) do
					local uDefID = spGetUnitDefID(unitID)
					if units.isFactory[uDefID] then
						selectedFactoryCount = selectedFactoryCount + 1
						currentSelBuilderDefs[uDefID] = true
					end
					if units.isBuilder[uDefID] then
						selectedBuilders[unitID] = true
						selectedBuilderCount = selectedBuilderCount + 1
						currentSelBuilderDefs[uDefID] = true
					end
				end

				if selectedFactoryCount ~= prevSelectedFactoryCount then
					doUpdate = true
				end

				-- check if builder type selection actually differs from previous selection
				if not doUpdate then
					if #currentSelBuilderDefs ~= #prevSelBuilderDefs then
						doUpdate = true
					else
						for uDefID, _ in pairs(prevSelBuilderDefs) do
							if not currentSelBuilderDefs[uDefID] then
								doUpdate = true
								break
							end
						end
						if not doUpdate then
							for uDefID, _ in pairs(currentSelBuilderDefs) do
								if not prevSelBuilderDefs[uDefID] then
									doUpdate = true
									break
								end
							end
						end
					end
				end
			end
		end
		tracy.ZoneEnd()
	end
	--[[ MODIFICATION END ]]

	local prevBuildmenuShows = buildmenuShows
	if not preGamestartPlayer and selectedBuilderCount == 0 and not alwaysShow then
		buildmenuShows = false
	else
		buildmenuShows = true
	end

	if WG.guishader and prevBuildmenuShows ~= buildmenuShows and dlistGuishader then
		if buildmenuShows and controllerPanelVisible then
			WG.guishader.InsertDlist(dlistGuishader, "buildmenu")
		else
			WG.guishader.RemoveDlist("buildmenu")
		end
	end

	sec = sec + dt
	if sec > 0.33 then
		tracy.ZoneBeginN("W:BuildMenu:Update:Periodic")
		sec = 0
		checkGuishader()
		if WG.minimap and minimapHeight ~= WG.minimap.getHeight() then
			widget:ViewResize()
		end

		if stickToBottom then
			if WG.advplayerlist_api ~= nil then
				local advplayerlistPos = WG.advplayerlist_api.GetPosition() -- returns {top,left,bottom,right,widgetScale}
				advplayerlistLeft = advplayerlistPos[2]
			end
		end
		local prevOrdermenuLeft = ordermenuLeft
		local prevOrdermenuHeight = ordermenuHeight
		if WG.ordermenu then
			local oposX, oposY, owidth, oheight = WG.ordermenu.getPosition()
			ordermenuLeft = math_floor((oposX + owidth) * vsx)
			ordermenuHeight = oheight
		end
		if
			not prevAdvplayerlistLeft
			or advplayerlistLeft ~= prevAdvplayerlistLeft
			or not prevOrdermenuLeft
			or ordermenuLeft ~= prevOrdermenuLeft
			or not prevOrdermenuHeight
			or ordermenuHeight ~= prevOrdermenuHeight
		then
			prevAdvplayerlistLeft = advplayerlistLeft
			widget:ViewResize()
		end

		disableInput = Spring.IsGodModeEnabled() and false or (disableInputWhenSpec and isSpec)
		tracy.ZoneEnd()
	end
	tracy.ZoneEnd()
end

function drawBuildmenuBg()
	UiElement(
		backgroundRect[1],
		backgroundRect[2],
		backgroundRect[3],
		backgroundRect[4],
		(posX > 0 and 1 or 0),
		1,
		((posY - height > 0 or posX <= 0) and 1 or 0),
		0,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil
	)
end

-- The player queue vs the widget-provided queue have different accounting due to quota mode.
-- cellQuotas contains the live count from the widget, which we should remove from the total.
local function getPlayerQueueCount(cellRectID, uDefID)
	local queueCount = tonumber(cmds[cellRectID].params[1])
	if not queueCount then
		return nil
	end
	local quotaInfo = cellQuotas[uDefID]
	if quotaInfo and WG.Quotas then
		queueCount = queueCount - WG.Quotas.getQuotaOrderCount(quotaInfo.builderID, uDefID)
	end
	if queueCount < 1 then
		return nil
	end
	return queueCount
end

local function drawCell(cellRectID, usedZoom, cellColor, disabled, underConstruction)
	tracy.ZoneBeginN("W:BuildMenu:DrawCell")
	local uDefID = -cmds[cellRectID].id
	local queueCount = getPlayerQueueCount(cellRectID, uDefID)
	local unitTexture = "#" .. uDefID
	local cellRect = cellRects[cellRectID]
	if not cellRect then
		tracy.ZoneEnd()
		return false
	end
	local quotaInfo = cellQuotas[uDefID]
	local quotaText, quotaCount, quotaDesired = nil, nil, nil
	if quotaInfo and quotaInfo.quota ~= 0 and WG.Quotas and type(WG.Quotas.getUnitAmount) == "function" then
		quotaCount = WG.Quotas.getUnitAmount(quotaInfo.builderID, uDefID)
		quotaDesired = quotaInfo.quota
		quotaText = tostring(quotaCount) .. "/" .. tostring(quotaDesired)
	end
	if ControllerNativeBuildCellRenderer then
		local rendered = ControllerNativeBuildCellRenderer.Draw({
			rect = cellRect, flow = WG.FlowUI, font = font2, unitDefID = uDefID,
			texture = unitTexture, metalCost = units.unitMetalCost[uDefID],
			energyCost = units.unitEnergyCost[uDefID],
			queueCount = quotaText and 0 or tonumber(cmds[cellRectID].params[1]),
			quotaText = quotaText,
			disabled = disabled, underConstruction = underConstruction, zoom = usedZoom,
			padding = cellPadding, iconPadding = iconPadding, corner = cornerSize,
			innerSize = cellInnerSize, fontSize = priceFontSize, selectedTint = cellColor,
			showPrice = showPrice, costOverride = costOverrides and costOverrides[uDefID],
			textureWarm = buildmenuUnitpicWarm.warmed,
			radarTexture = showRadarIcon and units.unitIconType[uDefID]
				and iconTypes[units.unitIconType[uDefID]] and (':l:' .. iconTypes[units.unitIconType[uDefID]]) or nil,
			groupTexture = showGroupIcon and groups[units.unitGroup[uDefID]]
				and (':l:' .. groups[units.unitGroup[uDefID]]) or nil,
		})
		tracy.ZoneEnd()
		return rendered
	end
	local iconX1 = cellRect[1] + cellPadding + iconPadding
	local iconY1 = cellRect[2] + cellPadding + iconPadding
	local iconX2 = cellRect[3] - cellPadding - iconPadding
	local iconY2 = cellRect[4] - cellPadding - iconPadding
	if not isValidRect(iconX1, iconY1, iconX2, iconY2) then
		tracy.ZoneEnd()
		return false
	end
	if not buildmenuUnitpicWarm.warmed[uDefID] then
		tracy.ZoneBeginN("W:BuildMenu:DrawCell:TextureWarmFallback")
		if glTexture(unitTexture) then
			buildmenuUnitpicWarm.warmed[uDefID] = true
		end
		glTexture(false)
		tracy.ZoneEnd()
	end

	-- unit icon
	local texprefix = ""
	if disabled then
		glColor(0.4, 0.4, 0.4, 1)
		texprefix = "t0.3,0.3,0.3"
	elseif underConstruction then
		glColor(0.77, 0.77, 0.77, 1)
		texprefix = "t0.63,0.63,0.63"
	else
		glColor(1, 1, 1, 1)
	end
	tracy.ZoneBeginN("W:BuildMenu:DrawCell:UiUnit")
	UiUnit(
		iconX1,
		iconY1,
		iconX2,
		iconY2,
		cornerSize,
		1,
		1,
		1,
		1,
		usedZoom,
		nil,
		disabled and 0 or nil,
		unitTexture,
		showRadarIcon
				and ((units.unitIconType[uDefID] and iconTypes[units.unitIconType[uDefID]]) and ":l" .. texprefix .. ":" .. iconTypes[units.unitIconType[uDefID]] or nil)
			or nil,
		showGroupIcon
				and (groups[units.unitGroup[uDefID]] and ":l" .. texprefix .. ":" .. groups[units.unitGroup[uDefID]] or nil)
			or nil,
		{ units.unitMetalCost[uDefID], units.unitEnergyCost[uDefID] },
		queueCount
	)
	tracy.ZoneEnd()

	-- colorize/highlight unit icon
	if cellColor then
		glBlending(GL_DST_ALPHA, GL_ONE_MINUS_SRC_COLOR)
		glColor(cellColor[1], cellColor[2], cellColor[3], cellColor[4])
		glTexture(unitTexture)
		UiUnit(
			cellRects[cellRectID][1] + cellPadding + iconPadding,
			cellRects[cellRectID][2] + cellPadding + iconPadding,
			cellRects[cellRectID][3] - cellPadding - iconPadding,
			cellRects[cellRectID][4] - cellPadding - iconPadding,
			cornerSize,
			1,
			1,
			1,
			1,
			usedZoom
		)
		if cellColor[4] > 0 then
			glBlending(GL_SRC_ALPHA, GL_ONE)
			UiUnit(
				cellRects[cellRectID][1] + cellPadding + iconPadding,
				cellRects[cellRectID][2] + cellPadding + iconPadding,
				cellRects[cellRectID][3] - cellPadding - iconPadding,
				cellRects[cellRectID][4] - cellPadding - iconPadding,
				cornerSize,
				1,
				1,
				1,
				1,
				usedZoom
			)
		end
		glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
	end
	glTexture(false)

	-- price
	if showPrice then
		local function AddSpaces(price)
			if price >= 1000 then
				return string_format("%s %03d", AddSpaces(math_floor(price / 1000)), price % 1000)
			end
			return price
		end

		local costOverride = costOverrides and costOverrides[uDefID]

		if costOverride then
			local topValue = costOverride.top and costOverride.top.value or units.unitMetalCost[uDefID]
			local bottomValue = costOverride.bottom and costOverride.bottom.value or units.unitEnergyCost[uDefID]

			if costOverride.top and not costOverride.top.disabled then
				local costColor = costOverride.top.color or "\255\100\255\100"
				if disabled then
					costColor = costOverride.top.colorDisabled or "\255\100\200\100"
				end
				local costPrice = AddSpaces(mathFloor(topValue))
				local costPriceText = costColor .. costPrice
				font2:Print(
					costPriceText,
					cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
					cellRects[cellRectID][2] + cellPadding + (priceFontSize * 1.35),
					priceFontSize,
					"ro"
				)
			elseif not costOverride.top then
				local metalColor = disabled and "\255\125\125\125" or "\255\245\245\245"
				local metalPrice = AddSpaces(units.unitMetalCost[uDefID])
				font2:Print(
					metalColor .. metalPrice,
					cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
					cellRects[cellRectID][2] + cellPadding + (priceFontSize * 1.35),
					priceFontSize,
					"ro"
				)
			end

			if costOverride.bottom and not costOverride.bottom.disabled then
				local costColor = costOverride.bottom.color or "\255\255\255\000"
				if disabled then
					costColor = costOverride.bottom.colorDisabled or "\255\135\135\135"
				end
				local costPrice = AddSpaces(mathFloor(bottomValue))
				local costPriceText = costColor .. costPrice
				font2:Print(
					costPriceText,
					cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
					cellRects[cellRectID][2] + cellPadding + (priceFontSize * 0.35),
					priceFontSize,
					"ro"
				)
			elseif not costOverride.bottom then
				local energyColor = disabled and "\255\135\135\135" or "\255\255\255\000"
				local energyPrice = AddSpaces(units.unitEnergyCost[uDefID])
				font2:Print(
					energyColor .. energyPrice,
					cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
					cellRects[cellRectID][2] + cellPadding + (priceFontSize * 0.35),
					priceFontSize,
					"ro"
				)
			end
		else
			local metalColor = disabled and "\255\125\125\125" or "\255\245\245\245"
			local energyColor = disabled and "\255\135\135\135" or "\255\255\255\000"
			local metalPrice = AddSpaces(units.unitMetalCost[uDefID])
			local energyPrice = AddSpaces(units.unitEnergyCost[uDefID])
			local metalPriceText = metalColor .. metalPrice
			local energyPriceText = energyColor .. energyPrice
			font2:Print(
				metalPriceText,
				cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
				cellRects[cellRectID][2] + cellPadding + (priceFontSize * 1.35),
				priceFontSize,
				"ro"
			)
			font2:Print(
				energyPriceText,
				cellRects[cellRectID][3] - cellPadding - (cellInnerSize * 0.048),
				cellRects[cellRectID][2] + cellPadding + (priceFontSize * 0.35),
				priceFontSize,
				"ro"
			)
		end
	end

	-- factory queue number
	if queueCount then
		local pad = math_floor(cellInnerSize * 0.03)
		local textWidth = math_floor(font2:GetTextWidth(queueCount .. "  ") * cellInnerSize * 0.285)
		local pad2 = 0
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2,
			cellRects[cellRectID][4] - cellPadding - iconPadding - math_floor(cellInnerSize * 0.365) - pad2,
			cellRects[cellRectID][3] - cellPadding - iconPadding,
			cellRects[cellRectID][4] - cellPadding - iconPadding,
			cornerSize * 3.3,
			0,
			0,
			0,
			1,
			{ 0.15, 0.15, 0.15, 0.95 },
			{ 0.25, 0.25, 0.25, 0.95 }
		)
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2,
			cellRects[cellRectID][4] - cellPadding - iconPadding - math_floor(cellInnerSize * 0.15) - pad2,
			cellRects[cellRectID][3] - cellPadding - iconPadding,
			cellRects[cellRectID][4] - cellPadding - iconPadding,
			0,
			0,
			0,
			0,
			0,
			{ 1, 1, 1, 0 },
			{ 1, 1, 1, 0.05 }
		)
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2 + pad,
			cellRects[cellRectID][4] - cellPadding - iconPadding - math_floor(cellInnerSize * 0.365) - pad2 + pad,
			cellRects[cellRectID][3] - cellPadding - iconPadding - pad2,
			cellRects[cellRectID][4] - cellPadding - iconPadding - pad2,
			cornerSize * 2.6,
			0,
			0,
			0,
			1,
			{ 0.7, 0.7, 0.7, 0.1 },
			{ 1, 1, 1, 0.1 }
		)
		font2:Print(
			"\255\190\255\190" .. queueCount,
			cellRects[cellRectID][1] + cellPadding + math_floor(cellInnerSize * 0.96) - pad2,
			cellRects[cellRectID][2] + cellPadding + math_floor(cellInnerSize * 0.735) - pad2,
			cellInnerSize * 0.29,
			"ro"
		)
	end

	if quotaInfo and quotaInfo.quota ~= 0 then
		local quotaText = WG.Quotas.getUnitAmount(quotaInfo.builderID, uDefID) .. "/" .. quotaInfo.quota
		local quotaFontSize = cellInnerSize * 0.29
		local textWidth = font2:GetTextWidth(quotaText .. "  ") * quotaFontSize
		local pad = math_floor(cellInnerSize * 0.03)
		if textWidth > 0.75 * cellInnerSize then
			local newFontSize = quotaFontSize * 0.75 * cellInnerSize / textWidth
			textWidth = font2:GetTextWidth(quotaText .. "  ") * newFontSize
			quotaFontSize = newFontSize
		end
		local pad2 = 0
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2,
			cellRects[cellRectID][2] + cellPadding + iconPadding,
			cellRects[cellRectID][3] - cellPadding - iconPadding,
			cellRects[cellRectID][2] + cellPadding + iconPadding + math_floor(cellInnerSize * 0.365) + pad2,
			cornerSize * 3.3,
			1,
			0,
			0,
			0,
			{ 0.15, 0.15, 0.15, 0.95 },
			{ 0.25, 0.25, 0.25, 0.95 }
		)
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2,
			cellRects[cellRectID][2] + cellPadding + iconPadding,
			cellRects[cellRectID][3] - cellPadding - iconPadding,
			cellRects[cellRectID][2] + cellPadding + iconPadding + math_floor(cellInnerSize * 0.15) + pad2,
			0,
			0,
			0,
			0,
			0,
			{ 1, 1, 1, 0 },
			{ 1, 1, 1, 0.05 }
		)
		RectRound(
			cellRects[cellRectID][3] - cellPadding - iconPadding - textWidth - pad2 + pad,
			cellRects[cellRectID][2] + cellPadding + iconPadding,
			cellRects[cellRectID][3] - cellPadding - iconPadding - pad2,
			cellRects[cellRectID][2] + cellPadding + iconPadding + math_floor(cellInnerSize * 0.365) + pad2 - pad,
			cornerSize * 2.6,
			1,
			0,
			0,
			0,
			{ 0.7, 0.7, 0.7, 0.1 },
			{ 1, 1, 1, 0.1 }
		)
		font2:Print(
			"\255\255\130\190" .. quotaText,
			cellRects[cellRectID][1] + cellPadding + math_floor(cellInnerSize * 0.96) - pad2,
			cellRects[cellRectID][2]
				+ cellPadding
				+ (math_floor(cellInnerSize * 0.365) - font2:GetTextHeight(quotaInfo.quota) * quotaFontSize) / 2,
			quotaFontSize,
			"ro"
		)
	end
	tracy.ZoneEnd()
	return true
end

local function drawHighlights()
	if highlightCount == 0 or not next(highlights) then
		return
	end
	local now = os_clock()
	for uDefID, hl in pairs(highlights) do
		local cellRectID = unitDefToCellMap[uDefID]
		local rect = cellRectID and cellRects[cellRectID]
		if rect then
			local color = hl.color or defaultHighlightColor
			local r, g, b = color[1], color[2], color[3]
			local t = now - (hl.startTime or now)
			-- Pulse, period ~1.4s
			local pulse = 0.5 + 0.5 * math.sin(t * 4.5)

			local x1 = rect[1] + cellPadding + iconPadding
			local y1 = rect[2] + cellPadding + iconPadding
			local x2 = rect[3] - cellPadding - iconPadding
			local y2 = rect[4] - cellPadding - iconPadding

			-- Brighten unit icon (additive overlay using its own texture)
			local brighten = 0.10 + 0.22 * pulse
			glBlending(GL_SRC_ALPHA, GL_ONE)
			glColor(r * brighten, g * brighten, b * brighten, 1)
			glTexture("#" .. uDefID)
			UiUnit(x1, y1, x2, y2, cornerSize, 1, 1, 1, 1, defaultCellZoom)
			glTexture(false)

			-- Feathered inner outline ring with pulsing alpha (proper chamfered corners)
			local thickness = math_max(2, math_floor((x2 - x1) * 0.04))
			local outlineAlpha = 0.45 + 0.5 * pulse
			local cs = cornerSize
			local outerCol = { r, g, b, outlineAlpha }
			local innerCol = { r, g, b, outlineAlpha * 0.85 }
			WG.FlowUI.Draw.RectRoundOutline(x1, y1, x2, y2, cs, thickness, 1, 1, 1, 1, outerCol, innerCol)

			-- Soft inner glow fading inward from the outline
			local glowAlpha = 0.10 + 0.20 * pulse
			local glowWidth = thickness * 3
			WG.FlowUI.Draw.RectRoundOutline(
				x1 + thickness,
				y1 + thickness,
				x2 - thickness,
				y2 - thickness,
				math_max(0, cs - thickness),
				glowWidth,
				1,
				1,
				1,
				1,
				{ r, g, b, glowAlpha },
				{ r, g, b, 0 }
			)

			glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
		end
	end
end

function drawBuildmenu()
	tracy.ZoneBeginN("W:BuildMenu:DrawBuildmenu")
	buildmenuRenderedCells = 0
	local activeArea = {
		backgroundRect[1] + (stickToBottom and bgpadding or 0) + activeAreaMargin,
		backgroundRect[2] + (stickToBottom and 0 or bgpadding) + activeAreaMargin,
		backgroundRect[3] - bgpadding - activeAreaMargin,
		backgroundRect[4] - bgpadding - activeAreaMargin,
	}
	local contentHeight = activeArea[4] - activeArea[2]
	local contentWidth = activeArea[3] - activeArea[1]
	local paginatorCellHeight = math_floor(contentHeight - (rows * cellSize))

	--- CHANGE START ---
	clearTable(cellRects)
	--- CHANGE END ---

	local numCellsPerPage = rows * colls
	local cellRectID = numCellsPerPage * (currentPage - 1)
	local maxCellRectID = numCellsPerPage * currentPage
	if maxCellRectID > cmdsCount then
		maxCellRectID = cmdsCount
	end
	-- build set of unit defs that can be built by at least one finished factory
	tracy.ZoneBeginN("W:BuildMenu:DrawBuildmenu:Buildable")
	local finishedBuildable = {}
	if selectedFactoryCount > 0 then
		for _, unitID in ipairs(spGetSelectedUnits()) do
			local defID = spGetUnitDefID(unitID)
			if units.isFactory and units.isFactory[defID] and not spGetUnitIsBeingBuilt(unitID) then
				local opts = unitBuildOptions[defID]
				if opts then
					for _, optDefID in ipairs(opts) do
						finishedBuildable[optDefID] = true
					end
				end
			end
		end
	end
	tracy.ZoneEnd()
	tracy.ZoneBeginN("W:BuildMenu:DrawBuildmenu:Cells")
	font2:Begin(true)
	local iconCount = 0
	for row = 1, rows do
		if cellRectID >= maxCellRectID then
			break
		end
		for coll = 1, colls do
			if cellRectID >= maxCellRectID then
				break
			end

			iconCount = iconCount + 1
			cellRectID = cellRectID + 1

			if stickToBottom then
				cellRects[cellRectID] = {
					activeArea[1] + ((coll - 1) * cellSize),
					activeArea[4] - (row * cellSize),
					activeArea[1] + (coll * cellSize),
					activeArea[4] - ((row - 1) * cellSize),
				}
			else
				cellRects[cellRectID] = {
					activeArea[3] - ((colls - coll + 1) * cellSize),
					activeArea[4] - (row * cellSize),
					activeArea[3] - ((colls - coll) * cellSize),
					activeArea[4] - ((row - 1) * cellSize),
				}
			end
			local cellIsSelected = (activeCmd and cmds[cellRectID] and activeCmd == cmds[cellRectID].name)
			local usedZoom = cellIsSelected and selectedCellZoom or defaultCellZoom

			local uDefIDCell = -cmds[cellRectID].id
			if
				drawCell(
					cellRectID,
					usedZoom,
					cellIsSelected and { 1, 0.85, 0.2, 0.25 } or nil,
					isUnitRestricted(uDefIDCell),
					selectedFactoryCount > 0 and not finishedBuildable[uDefIDCell]
				)
			then
				buildmenuRenderedCells = buildmenuRenderedCells + 1
			end
		end
	end
	tracy.ZoneEnd()

	-- paginator
	if pages == 1 then
		paginatorRects = {}
	else
		tracy.ZoneBeginN("W:BuildMenu:DrawBuildmenu:Paginator")
		local paginatorFontSize = math_max(0.016 * vsy, paginatorCellHeight * 0.2)
		local paginatorCellWidth = math_floor(contentWidth * 0.3)

		paginatorRects[1] = {
			activeArea[1],
			activeArea[2],
			activeArea[1] + paginatorCellWidth,
			activeArea[2] + paginatorCellHeight - cellPadding - activeAreaMargin,
		}
		paginatorRects[2] = {
			activeArea[3] - paginatorCellWidth,
			activeArea[2],
			activeArea[3],
			activeArea[2] + paginatorCellHeight - cellPadding - activeAreaMargin,
		}

		UiButton(
			paginatorRects[1][1] + cellPadding,
			paginatorRects[1][2] + cellPadding,
			paginatorRects[1][3] - cellPadding,
			paginatorRects[1][4] - cellPadding,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			nil,
			{ 0, 0, 0, 0.8 },
			{ 0.2, 0.2, 0.2, 0.8 },
			bgpadding * 0.5
		)
		font2:Print(
			"<",
			paginatorRects[1][1] + (paginatorCellWidth * 0.5),
			paginatorRects[1][2] + (paginatorCellHeight * 0.5) - (paginatorFontSize * 0.25),
			paginatorFontSize * 1.2,
			"co"
		)
		UiButton(
			paginatorRects[2][1] + cellPadding,
			paginatorRects[2][2] + cellPadding,
			paginatorRects[2][3] - cellPadding,
			paginatorRects[2][4] - cellPadding,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			nil,
			{ 0, 0, 0, 0.8 },
			{ 0.2, 0.2, 0.2, 0.8 },
			bgpadding * 0.5
		)
		font2:Print(
			">",
			paginatorRects[2][1] + (paginatorCellWidth * 0.5),
			paginatorRects[2][2] + (paginatorCellHeight * 0.5) - (paginatorFontSize * 0.25),
			paginatorFontSize * 1.2,
			"co"
		)

		font2:Print(
			"\255\245\245\245" .. currentPage .. "  /  " .. pages,
			contentWidth * 0.5,
			activeArea[2] + (paginatorCellHeight * 0.5) - (paginatorFontSize * 0.25),
			paginatorFontSize,
			"co"
		)
		tracy.ZoneEnd()
	end

	font2:End()
	tracy.ZoneEnd()
end

local function refreshBuildmenuTexture()
	if not refreshBuildmenu then
		return
	end
	tracy.ZoneBeginN("W:BuildMenu:DrawScreen:RefreshTexture")
	if not isValidBuildmenuGeometry() then
		refreshBuildmenu = true
		tracy.ZoneEnd()
		return
	end
	if cmdsCount <= 0 then
		refreshBuildmenu = true
		tracy.ZoneEnd()
		return
	end
	local buildmenuUnitpicsWarmDone = true
	local warmedBuildmenuUnitpicThisFrame = false
	if buildmenuUnitpicWarm.count > 0 then
		warmedBuildmenuUnitpicThisFrame = true
		buildmenuUnitpicsWarmDone = flushBuildmenuUnitpicWarmQueue()
	end
	refreshBuildmenu = false
	if not buildmenuTex and width > 0.05 and height > 0.05 then
		tracy.ZoneBeginN("W:BuildMenu:DrawScreen:CreateTextures")
		buildmenuTex =
			gl.CreateTexture(math_floor(width * vsx) * 2, math_floor(height * vsy) * 2, { --*(vsy<1400 and 2 or 1)
				target = GL.TEXTURE_2D,
				format = GL.RGBA,
				fbo = true,
			})
		buildmenuTexHasContent = false
		buildmenuBgTex = gl.CreateTexture(math_floor(width * vsx), math_floor(height * vsy), {
			target = GL.TEXTURE_2D,
			format = GL.RGBA,
			fbo = true,
		})
		gl.R2tHelper.RenderInRect(
			buildmenuBgTex,
			backgroundRect[1],
			backgroundRect[2],
			backgroundRect[3],
			backgroundRect[4],
			drawBuildmenuBg,
			true
		)
		tracy.ZoneEnd()
	end
	local forceInitialRender = buildmenuTex and not buildmenuTexHasContent
	local renderedBuildmenuTex = false
	if buildmenuTex and (forceInitialRender or (buildmenuUnitpicsWarmDone and not warmedBuildmenuUnitpicThisFrame)) then
		tracy.ZoneBeginN("W:BuildMenu:DrawScreen:RenderTexture")
		gl.R2tHelper.RenderInRect(
			buildmenuTex,
			backgroundRect[1],
			backgroundRect[2],
			backgroundRect[3],
			backgroundRect[4],
			drawBuildmenu,
			true
		)
		if buildmenuRenderedCells > 0 then
			buildmenuTexHasContent = true
			renderedBuildmenuTex = true
			if forceInitialRender then
				clearBuildmenuUnitpicWarmQueue()
			end
		else
			buildmenuTexHasContent = false
			refreshBuildmenu = true
		end
		tracy.ZoneEnd()
	end
	if not renderedBuildmenuTex and (not buildmenuUnitpicsWarmDone or warmedBuildmenuUnitpicThisFrame) then
		refreshBuildmenu = true
	end
	tracy.ZoneEnd()
end

function ControllerBuildMenuRefreshHiddenPanel()
	-- Keep cells, revisions, queue counts, and activation APIs authoritative
	-- while suppressing only the native panel's pixels and mouse ownership.
	local previous = activeCmd
	if spGetGameFrame() == 0 and WG['pregame-build'] then
		activeCmd = WG["pregame-build"].getPreGameDefID()
		if activeCmd then activeCmd = unitName[activeCmd] end
	else
		activeCmd = select(4, spGetActiveCommand())
	end
	if activeCmd ~= previous then doUpdate = true end
	if raceConditionUpdateCountdown > 0 then
		raceConditionUpdateCountdown = raceConditionUpdateCountdown - 1
		if raceConditionUpdateCountdown == 0 then doUpdate = true end
	end
	if doUpdate or refreshBuildmenu then
		RefreshCommands()
		doUpdate = nil
		refreshBuildmenu = false
	end
	if WG['guishader'] and dlistGuishader then WG['guishader'].RemoveDlist('buildmenu') end
end

function ControllerBuildMenuRefreshVisiblePanel()
	local previous = activeCmd
	if spGetGameFrame() == 0 and WG['pregame-build'] then
		activeCmd = WG["pregame-build"].getPreGameDefID()
		if activeCmd then activeCmd = unitName[activeCmd] end
	else
		activeCmd = select(4, spGetActiveCommand())
	end
	if activeCmd ~= previous then doUpdate = true end
	if raceConditionUpdateCountdown > 0 then
		raceConditionUpdateCountdown = raceConditionUpdateCountdown - 1
		if raceConditionUpdateCountdown == 0 then doUpdate = true end
	end
	if doUpdate or refreshBuildmenu then
		tracy.ZoneBeginN("W:BuildMenu:DrawScreen:RefreshCommands")
		RefreshCommands()
		doUpdate = nil
		refreshBuildmenu = true
		tracy.ZoneEnd()
	end
	refreshBuildmenuTexture()
end

function widget:DrawScreen()
	tracy.ZoneBeginN("W:BuildMenu:DrawScreen")
	if not controllerPanelVisible then
		ControllerBuildMenuRefreshHiddenPanel()
		tracy.ZoneEnd()
		return
	end
	glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

	if WG.buildmenu then
		WG.buildmenu.hoverID = nil
	end

	if not buildmenuShows then
		tracy.ZoneEnd()
		return
	end

	local x, y, b, b2, b3 = spGetMouseState()
	ControllerBuildMenuRefreshVisiblePanel()

	-- draw buildmenu background
	tracy.ZoneBeginN("W:BuildMenu:DrawScreen:BlendBackground")
	if buildmenuBgTex and backgroundRect then
		gl.R2tHelper.BlendTexRect(
			buildmenuBgTex,
			backgroundRect[1],
			backgroundRect[2],
			backgroundRect[3],
			backgroundRect[4],
			true
		)
	end
	tracy.ZoneEnd()

	local hovering = false
	if math_isInRect(x, y, backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4]) then
		Spring.SetMouseCursor("cursornormal")
		hovering = true
	end

	if preGamestartPlayer or selectedBuilderCount ~= 0 then
		tracy.ZoneBeginN("W:BuildMenu:DrawScreen:Content")
		-- pre process + 'highlight' under the icons
		local hoveredCellID
		if not WG.topbar or not WG.topbar.showingQuit() then
			if hovering then
				for cellRectID, cellRect in pairs(cellRects) do
					local cmd = cmds[cellRectID]
					if cmd and math_isInRect(x, y, cellRect[1], cellRect[2], cellRect[3], cellRect[4]) then
						hoveredCellID = cellRectID
						local uDefID = -cmd.id
						WG.buildmenu.hoverID = uDefID
						if ControllerBuildMenuHybridState.radialOpen and controllerFocusDefID ~= uDefID
								and WG.buildmenu and type(WG.buildmenu.controllerSetFocus) == 'function' then
							WG.buildmenu.controllerSetFocus(uDefID, "vanilla-mouse")
						end
						gl.Color(1, 1, 1, 1)
						local _, _, meta, _ = Spring.GetModKeyState()
						if WG.tooltip and not meta then
							-- when meta: unitstats does the tooltip
							local text
							local textColor = "\255\215\255\215"
							if isUnitRestricted(uDefID) then
								text = BAR.I18N("ui.buildMenu.disabled", {
									unit = unitTranslatedHumanName[uDefID],
									textColor = textColor,
									warnColor = "\255\166\166\166",
								})
							else
								text = UnitDefs[uDefID].translatedHumanName
							end
							local tooltip = unitTranslatedTooltip[uDefID]
							if unitMetal_extractor[uDefID] then
								tooltip = tooltip .. "\n" .. BAR.I18N("ui.buildMenu.areamex_tooltip")
							end
							WG.tooltip.ShowTooltip("buildmenu", "\255\240\240\240" .. tooltip, nil, nil, text)
						end

						-- highlight --if b and not disableInput then
						glBlending(GL_SRC_ALPHA, GL_ONE)
						RectRound(
							cellRects[cellRectID][1] + cellPadding,
							cellRects[cellRectID][2] + cellPadding,
							cellRects[cellRectID][3] - cellPadding,
							cellRects[cellRectID][4] - cellPadding,
							cellSize * 0.03,
							1,
							1,
							1,
							1,
							{ 0, 0, 0, 0.1 * ui_opacity },
							{ 0, 0, 0, 0.1 * ui_opacity }
						)
						glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
						break
					end
				end
			end
		end

		-- draw buildmenu content
		if buildmenuTex and buildmenuTexHasContent then
			tracy.ZoneBeginN("W:BuildMenu:DrawScreen:BlendContent")
			-- content
			gl.Color(1, 1, 1, 1)
			gl.Texture(buildmenuTex)
			gl.TexRect(backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4], false, true)
			gl.Texture(false)
			tracy.ZoneEnd()
		elseif dlistBuildmenu then
			gl.CallList(dlistBuildmenu)
		end

		-- draw highlight
		local usedZoom
		local cellColor
		if not WG.topbar or not WG.topbar.showingQuit() then
			if math_isInRect(x, y, backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4]) then
				-- paginator buttons
				local paginatorHovered = false
				if
					paginatorRects[1]
					and math_isInRect(
						x,
						y,
						paginatorRects[1][1],
						paginatorRects[1][2],
						paginatorRects[1][3],
						paginatorRects[1][4]
					)
				then
					paginatorHovered = 1
				end
				if
					paginatorRects[2]
					and math_isInRect(
						x,
						y,
						paginatorRects[2][1],
						paginatorRects[2][2],
						paginatorRects[2][3],
						paginatorRects[2][4]
					)
				then
					paginatorHovered = 2
				end
				if paginatorHovered then
					if WG.tooltip then
						local text = "\255\240\240\240"
							.. (
								paginatorHovered == 1 and BAR.I18N("ui.buildMenu.previousPage")
								or BAR.I18N("ui.buildMenu.nextPage")
							)
						WG.tooltip.ShowTooltip("buildmenu", text)
					end
					RectRound(
						paginatorRects[paginatorHovered][1] + cellPadding,
						paginatorRects[paginatorHovered][2] + cellPadding,
						paginatorRects[paginatorHovered][3] - cellPadding,
						paginatorRects[paginatorHovered][4] - cellPadding,
						cellSize * 0.03,
						2,
						2,
						2,
						2,
						{ 1, 1, 1, 0 },
						{ 1, 1, 1, (b and 0.35 or 0.15) }
					)
					-- gloss
					RectRound(
						paginatorRects[paginatorHovered][1] + cellPadding,
						paginatorRects[paginatorHovered][4]
							- cellPadding
							- ((paginatorRects[paginatorHovered][4] - paginatorRects[paginatorHovered][2]) * 0.5),
						paginatorRects[paginatorHovered][3] - cellPadding,
						paginatorRects[paginatorHovered][4] - cellPadding,
						cellSize * 0.03,
						2,
						2,
						0,
						0,
						{ 1, 1, 1, 0.015 },
						{ 1, 1, 1, 0.13 }
					)
					RectRound(
						paginatorRects[paginatorHovered][1] + cellPadding,
						paginatorRects[paginatorHovered][2] + cellPadding,
						paginatorRects[paginatorHovered][3] - cellPadding,
						paginatorRects[paginatorHovered][2]
							+ cellPadding
							+ ((paginatorRects[paginatorHovered][4] - paginatorRects[paginatorHovered][2]) * 0.33),
						cellSize * 0.03,
						0,
						0,
						2,
						2,
						{ 1, 1, 1, 0.025 },
						{ 1, 1, 1, 0 }
					)
				end

				-- draw cell hover
				if hoveredCellID then
					local uDefID = -cmds[hoveredCellID].id
					local cellIsSelected = (activeCmd and cmds[hoveredCellID] and activeCmd == cmds[hoveredCellID].name)
					if
						not prevHoveredCellID
						or hoveredCellID ~= prevHoveredCellID
						or uDefID ~= hoverUdefID
						or cellIsSelected ~= hoverCellSelected
						or b ~= prevB
						or b3 ~= prevB3
						or cmds[hoveredCellID].params[1] ~= prevQueueNr
					then
						prevQueueNr = cmds[hoveredCellID].params[1]
						prevB = b
						prevB3 = b3
						prevHoveredCellID = hoveredCellID
						hoverCellSelected = cellIsSelected
						hoverUdefID = uDefID
						if hoverDlist then
							hoverDlist = gl.DeleteList(hoverDlist)
						end
						hoverDlist = gl.CreateList(function()
							-- determine zoom amount and cell color
							usedZoom = hoverCellZoom
							if not cellIsSelected then
								if (b or b2) and cellIsSelected then
									usedZoom = clickSelectedCellZoom
								elseif cellIsSelected then
									usedZoom = selectedCellZoom
								elseif (b or b2) and not disableInput then
									usedZoom = clickCellZoom
								elseif b3 and not disableInput and cmds[hoveredCellID].params[1] then
									-- has queue
									usedZoom = rightclickCellZoom
								end
								-- determine color
								if (b or b2) and not disableInput then
									cellColor = { 0.3, 0.8, 0.25, 0.2 }
								elseif b3 and not disableInput then
									cellColor = { 1, 0.35, 0.3, 0.2 }
								else
									cellColor = { 0.63, 0.63, 0.63, 0 }
								end
							else
								-- selected cell
								if b or b2 or b3 then
									usedZoom = clickSelectedCellZoom
								else
									usedZoom = selectedCellZoom
								end
								cellColor = { 1, 0.85, 0.2, 0.25 }
							end
							if not isUnitRestricted(uDefID) then
								local unsetShowPrice
								if not showPrice then
									unsetShowPrice = true
									showPrice = true
								end

								-- re-draw cell with hover zoom (and price shown)
								font2:Begin(true)
								drawCell(hoveredCellID, usedZoom, cellColor, isUnitRestricted(uDefID))
								font2:End()

								if unsetShowPrice then
									showPrice = false
									unsetShowPrice = nil
								end
							end
						end)
					end
					if hoverDlist then
						gl.CallList(hoverDlist)
					end
				end
			end
		end

		-- draw attention highlights (animated)
		tracy.ZoneBeginN("W:BuildMenu:DrawScreen:Highlights")
		drawHighlights()
		tracy.ZoneEnd()

		-- draw builders buildoption progress
		if showBuildProgress then
			tracy.ZoneBeginN("W:BuildMenu:DrawScreen:BuildProgress")
			for builderUnitID, _ in pairs(selectedBuilders) do
				local unitBuildID = spGetUnitIsBuilding(builderUnitID)
				if unitBuildID and not drawnBuildTargets[unitBuildID] then
					drawnBuildTargets[unitBuildID] = true
					local unitBuildDefID = spGetUnitDefID(unitBuildID)
					if unitBuildDefID then
						local cellRectID = unitDefToCellMap[unitBuildDefID]
						if cellRectID and cellRects[cellRectID] then
							local _, progress = spGetUnitIsBeingBuilt(unitBuildID)
							progress = 1 - progress -- make the effect wind counter-clockwise
							local progressRect = cellRects[cellRectID]
							local x1 = progressRect[1] + cellPadding + iconPadding
							local y1 = progressRect[2] + cellPadding + iconPadding
							local x2 = progressRect[3] - cellPadding - iconPadding
							local y2 = progressRect[4] - cellPadding - iconPadding
							if isValidRect(x1, y1, x2, y2) then
								RectRoundProgress(x1, y1, x2, y2, cellSize * 0.03, progress, progressColor)
							end
						end
					end
				end
			end
			for k in pairs(drawnBuildTargets) do
				drawnBuildTargets[k] = nil
			end
			tracy.ZoneEnd()
		end
		tracy.ZoneEnd()
	end
	tracy.ZoneEnd()
end

function widget:DrawWorld()
	-- Avoid unnecessary overhead after buildqueue has been setup in early frames
	if spGetGameFrame() > 0 then
		widgetHandler:RemoveWidgetCallIn("DrawWorld", self)
		return
	end

	if not preGamestartPlayer then
		return
	end

	if startDefID ~= Spring.GetTeamRulesParam(myTeamID, "startUnit") then
		startDefID = Spring.GetTeamRulesParam(myTeamID, "startUnit")
		doUpdate = true
	end
end

function widget:UnitCommand(unitID, unitDefID, unitTeam, cmdID, cmdOpts, cmdParams, cmdTag)
	if units.isFactory[unitDefID] and cmdID < 0 then
		-- filter away non build cmd's
		raceConditionUpdateCountdown = 2
	end
	if cmdID == CMD_STOP_PRODUCTION then
		if WG.Quotas then
			local quotas = WG.Quotas.getQuotas()
			quotas[unitID] = nil
			doUpdate = true
		end
	end
end

function widget:SelectionChanged(sel)
	--[[ MODIFICATION START ]]
	-- Adaptive throttling: increase delay based on selection size
	local selCount = #sel
	local throttleDelay = 0.01
	if selCount >= 300 then
		throttleDelay = 0.03
	elseif selCount >= 160 then
		throttleDelay = 0.02
	elseif selCount >= 80 then
		throttleDelay = 0.015
	end

	selectionUpdateTime = os_clock() + throttleDelay
	-- Invalidate cached commands on selection change
	cachedActiveCmdDescs = nil
	--[[ MODIFICATION END ]]
end

local function unbindBuildUnits()
	for _, buildOption in ipairs(boundUnits) do
		widgetHandler.actionHandler:RemoveAction(self, "buildunit_" .. buildOption, "p") ---@diagnostic disable-line: undefined-global
	end

	boundUnits = {}
end

function widget:GameStart()
	preGamestartPlayer = false

	unbindBuildUnits()
end

function widget:GameFrame(n)
	if n % 15 ~= 0 or selectedFactoryCount == 0 then
		return
	end
	local finishedCount = 0
	for _, unitID in ipairs(spGetSelectedUnits()) do
		local defID = spGetUnitDefID(unitID)
		if units.isFactory and units.isFactory[defID] then
			if not spGetUnitIsBeingBuilt(unitID) then
				finishedCount = finishedCount + 1
			end
		end
	end
	if finishedCount ~= prevAnyFactoryUnfinished then
		prevAnyFactoryUnfinished = finishedCount
		refreshBuildmenu = true
	end
end

local function setPreGamestartDefID(uDefID)
	selBuildQueueDefID = uDefID
	if WG["pregame-build"] then
		WG["pregame-build"].setPreGamestartDefID(uDefID)
	end
end

local function isOnQuotaBuildMode(targetDefID)
	for _, unitID in ipairs(spGetSelectedUnits()) do
		local uDefID = spGetUnitDefID(unitID)
		if units.isFactory[uDefID] and table.contains(unitBuildOptions[uDefID], targetDefID) then
			return WG.Quotas and WG.Quotas.isOnQuotaMode(unitID)
		end
	end
	return false
end

local function updateQuotaNumber(unitDefID, count)
	if WG.Quotas then
		local quotaChanged = false
		for _, builderID in ipairs(Spring.GetSelectedUnits()) do
			local uDefID = spGetUnitDefID(builderID)
			if units.isFactory[uDefID] and table.contains(unitBuildOptions[uDefID], unitDefID) then
				local quotas = WG.Quotas.getQuotas()
				quotas[builderID] = quotas[builderID] or {}
				quotas[builderID][unitDefID] = quotas[builderID][unitDefID] or 0
				local prev = quotas[builderID][unitDefID]
				quotas[builderID][unitDefID] = mathMax(quotas[builderID][unitDefID] + (count or 0), 0)
				quotaChanged = quotaChanged or prev ~= quotas[builderID][unitDefID]
			end
		end
		doUpdate = true
		return quotaChanged
	end
end

local function changeQuotas(uDefID, quantity)
	local alt, ctrl, meta, shift = Spring.GetModKeyState()
	if ctrl then
		quantity = quantity * modKeyMultiplier.ctrl
	end
	if shift then
		quantity = quantity * modKeyMultiplier.shift
	end
	return updateQuotaNumber(uDefID, quantity)
end

function widget:MousePress(x, y, button)
	if not controllerPanelVisible then return false end
	if Spring.IsGUIHidden() then
		return
	end
	if WG.topbar and WG.topbar.showingQuit() then
		return
	end

	if
		buildmenuShows
		and math_isInRect(x, y, backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4])
	then
		if selectedBuilderCount > 0 or (preGamestartPlayer and startDefID) then
			if
				paginatorRects[1]
				and math_isInRect(
					x,
					y,
					paginatorRects[1][1],
					paginatorRects[1][2],
					paginatorRects[1][3],
					paginatorRects[1][4]
				)
			then
				currentPage = currentPage - 1
				if currentPage < 1 then
					currentPage = pages
				end
				doUpdate = true
			end
			if
				paginatorRects[2]
				and math_isInRect(
					x,
					y,
					paginatorRects[2][1],
					paginatorRects[2][2],
					paginatorRects[2][3],
					paginatorRects[2][4]
				)
			then
				currentPage = currentPage + 1
				if currentPage > pages then
					currentPage = 1
				end
				doUpdate = true
			end
			if not disableInput then
				for cellRectID, cellRect in pairs(cellRects) do
					if
						cmds[cellRectID]
						and cmds[cellRectID].id
						and unitTranslatedHumanName[-cmds[cellRectID].id]
						and math_isInRect(x, y, cellRect[1], cellRect[2], cellRect[3], cellRect[4])
						and not isUnitRestricted(-cmds[cellRectID].id)
					then
						local uDefID = cmds[cellRectID].id --WARNING: THIS IS -unitDefID, not unitDefID
						local setQuotas = isOnQuotaBuildMode(-uDefID)
						local alt, ctrl, meta, shift = Spring.GetModKeyState()
						if button ~= 3 then
							if playSounds then
								Spring.PlaySoundFile(sound_queue_add, 0.75, "ui")
							end
							if setQuotas and not alt then
								changeQuotas(-uDefID, 1)
							else
								if preGamestartPlayer then
									setPreGamestartDefID(-uDefID)
								elseif spGetCmdDescIndex(uDefID) then
									local isRepeatMex = unitMetal_extractor[-uDefID] and unitName[-uDefID] == activeCmd
									local cmd = isRepeatMex and "areamex" or spGetCmdDescIndex(uDefID)
									if isRepeatMex then
										WG.areamex.setAreaMexType(uDefID)
									end
									Spring.SetActiveCommand(cmd, 1, true, false, alt, ctrl, meta, shift)
								end
							end
						else
							-- Ignores the count from the quota widget.
							local queueCount = getPlayerQueueCount(cellRectID, -uDefID) or 0

							local function decreaseQuota()
								if changeQuotas(-uDefID, modKeyMultiplier.right) and playSounds then
									Spring.PlaySoundFile(sound_queue_rem, 0.75, "ui")
								end
							end

							local function decreaseQueue()
								if queueCount > 0 and playSounds then
									Spring.PlaySoundFile(sound_queue_rem, 0.75, "ui")
								end
								if preGamestartPlayer then
									setPreGamestartDefID(-cmds[cellRectID].id)
								elseif spGetCmdDescIndex(cmds[cellRectID].id) then
									Spring.SetActiveCommand(
										spGetCmdDescIndex(cmds[cellRectID].id),
										3,
										false,
										true,
										Spring.GetModKeyState()
									)
								end
							end

							local isQuotaMode = setQuotas and not alt
							local quotaInfo = cellQuotas[-uDefID]
							local currentQuota = (quotaInfo and quotaInfo.quota) or 0

							if isQuotaMode then
								if currentQuota > 0 then
									decreaseQuota()
								else
									decreaseQueue()
								end
							else
								if queueCount > 0 then
									decreaseQueue()
								else
									decreaseQuota()
								end
							end
						end
						raceConditionUpdateCountdown = 2
						return true
					end
				end
			end
			return true
		elseif alwaysShow then
			return true
		end
	end
end

-- Used for hotkeys at pregamestart
local function buildUnitHandler(_, _, _, data)
	-- sanity check
	if not preGamestartPlayer then
		return
	end
	if isUnitRestricted(data.unitDefID) then
		return
	end

	if
		not unitName[startDefID]
		or not comBuildOptions[unitName[startDefID]]
		or not comBuildOptions[unitName[startDefID]][data.unitDefID]
	then
		return
	end

	-- If no current active selection we can return early
	if not selBuildQueueDefID then
		setPreGamestartDefID(data.unitDefID)
		return true
	end

	-- Find the buildcycle for current key and iterate on it
	local pressedKey, pressedScan
	for k, v in pairs(Spring.GetPressedKeys()) do
		if v and tonumber(k) then
			local key = Spring.GetKeySymbol(tonumber(k))
			if key and #key == 1 then
				pressedKey = key
				break
			end
		end
	end

	-- check if engine supports GetPressedScans first, adjust when/if https://github.com/beyond-all-reason/spring/pull/388 is deployed
	local pressedScans = Spring.GetPressedScans and Spring.GetPressedScans() or {}
	for k, v in pairs(pressedScans) do
		if v and tonumber(k) then
			local scan = Spring.GetScanSymbol(tonumber(k))
			if scan and #scan == 4 then -- quick hack to avoid modifiers
				pressedScan = scan
				break
			end
		end
	end

	-- didn't find a suitable binding to cycle from
	if not (pressedKey or pressedScan) then
		return
	end

	-- Clear and reuse temp table instead of creating new one
	clearTable(buildCycleTemp)
	local buildCycleCount = 0
	for _, keybind in ipairs(Spring.GetKeyBindings(pressedKey, pressedScan)) do
		if string_sub(keybind.command, 1, 10) == "buildunit_" then
			local uDefName = string_sub(keybind.command, 11)
			local uDef = UnitDefNames[uDefName]
			if uDef then -- prevents crashing when trying to access unloaded units (legion)
				if comBuildOptions[unitName[startDefID]][uDef.id] and not isUnitRestricted(uDef.id) then
					buildCycleCount = buildCycleCount + 1
					buildCycleTemp[buildCycleCount] = uDef.id
				end
			end
		end
	end

	if buildCycleCount == 0 then
		return
	end

	local buildCycleIndex
	for i = 1, buildCycleCount do
		if buildCycleTemp[i] == selBuildQueueDefID then
			buildCycleIndex = i
			break
		end
	end

	if not buildCycleIndex then
		setPreGamestartDefID(data.unitDefID)
		return true
	end

	buildCycleIndex = buildCycleIndex + 1
	if buildCycleIndex > buildCycleCount then
		buildCycleIndex = 1
	end

	setPreGamestartDefID(buildCycleTemp[buildCycleIndex])

	return true
end

local function bindBuildUnits(widget)
	if not preGamestartPlayer then
		return
	end

	unbindBuildUnits()

	comBuildOptions = {}
	local validStartUnits = string.split(
		spGetTeamRulesParam(myTeamID, "validStartUnits") or Spring.GetGameRulesParam("validStartUnits"),
		"|"
	)
	for _, unitDefIDString in ipairs(validStartUnits) do
		local unitDefID = tonumber(unitDefIDString)
		local unitDef = unitDefID and UnitDefs[unitDefID]
		if unitDef then
			comBuildOptions[unitDef.name] = {}
		end
	end

	for comDefName, buildOptions in pairs(comBuildOptions) do
		for _, buildOption in ipairs(UnitDefNames[comDefName].buildOptions) do
			if not units.unitRestricted[buildOption] then
				local unitDefName = unitName[buildOption]
				buildOptions[buildOption] = true
				table.insert(boundUnits, unitDefName)
				widgetHandler.actionHandler:AddAction(
					widget,
					"buildunit_" .. unitDefName,
					buildUnitHandler,
					{ unitDefID = buildOption },
					"p"
				)
			end
		end
	end
end

function widget:Initialize()
	widgetHandler:RegisterUnitCommand(widget, CMD.BUILD)
	widgetHandler:RegisterUnitCommand(widget, CMD_STOP_PRODUCTION)
	refreshUnitDefs()
	units.loadBlocked()

	if widgetHandler:IsWidgetKnown("Grid menu") then
		-- Grid menu needs to be disabled right now and before we recreate
		-- WG['buildmenu'] since its Shutdown will destroy it.
		widgetHandler:DisableWidgetRaw("Grid menu")
	end

	-- If mission disables the initial commander spawn, suppress the entire pregame build path (build menu, startDefID binding, buildmenuShows = true, etc.)
	if preGamestartPlayer then
		local missionOptions = require("luaui/Include/mission_options")
		preGamestartPlayer = not missionOptions.IsStartUnitSpawnDisabled()
	end

	-- Get our starting unit
	if preGamestartPlayer then
		bindBuildUnits(self)
		if not startDefID or startDefID ~= spGetTeamRulesParam(myTeamID, "startUnit") then
			startDefID = spGetTeamRulesParam(myTeamID, "startUnit")
			doUpdate = true
		end
	end

	widget:ViewResize()
	widget:SelectionChanged(spGetSelectedUnits())

	WG.buildmenu = {}
	WG.buildmenu.getGroups = function()
		return groups, units.unitGroup
	end
	WG.buildmenu.getOrder = function()
		return units.unitOrder
	end
	WG.buildmenu.getShowPrice = function()
		return showPrice
	end
	WG.buildmenu.setShowPrice = function(value)
		showPrice = value
		clear()
	end
	WG.buildmenu.getAlwaysShow = function()
		return alwaysShow
	end
	WG.buildmenu.setAlwaysShow = function(value)
		alwaysShow = value
		clear()
	end
	WG.buildmenu.getShowRadarIcon = function()
		return showRadarIcon
	end
	WG.buildmenu.setShowRadarIcon = function(value)
		showRadarIcon = value
		clear()
	end
	WG.buildmenu.getShowGroupIcon = function()
		return showGroupIcon
	end
	WG.buildmenu.setShowGroupIcon = function(value)
		showGroupIcon = value
		clear()
	end
	WG.buildmenu.getDynamicIconsize = function()
		return dynamicIconsize
	end
	WG.buildmenu.setDynamicIconsize = function(value)
		dynamicIconsize = value
		clear()
	end
	WG.buildmenu.getMinColls = function()
		return minColls
	end
	WG.buildmenu.setMinColls = function(value)
		minColls = value
		clear()
	end
	WG.buildmenu.getMaxColls = function()
		return maxColls
	end
	WG.buildmenu.setMaxColls = function(value)
		maxColls = value
		clear()
	end
	WG.buildmenu.getDefaultColls = function()
		return defaultColls
	end

	WG.buildmenu.setDefaultColls = function(value)
		defaultColls = value
		clear()
	end
	WG.buildmenu.getBottomPosition = function()
		return stickToBottom
	end
	WG.buildmenu.setBottomPosition = function(value)
		stickToBottom = value
		widget:Update(1000)
		widget:ViewResize()
		clear()
	end
	WG.buildmenu.getSize = function()
		return posY, posY2
	end
	WG.buildmenu.getMaxPosY = function()
		return maxPosY
	end
	WG.buildmenu.setMaxPosY = function(value)
		maxPosY = value
		clear()
	end
	WG.buildmenu.reloadBindings = function()
		bindBuildUnits(self)
	end
	WG.buildmenu.getIsShowing = function()
		return buildmenuShows
	end
	---@class CostLine
	---@field value number?
	---@field color string?
	---@field colorDisabled string?
	---@field disabled boolean?

	---@class CostData
	---@field top CostLine?
	---@field bottom CostLine?

	---Override the cost display for a specific unit in the build menu
	---@param unitDefID UnitDefID The unit definition ID to override costs for
	---@param costData CostData Cost override configuration table with optional properties
	WG.buildmenu.setCostOverride = function(unitDefID, costData)
		if unitDefID and costData then
			costOverrides[unitDefID] = costData
			clear()
		end
	end

	---Clear cost overrides for a specific unit or all units
	---@param unitDefID UnitDefID? The unit definition ID to clear overrides for. If nil or not provided, clears all cost overrides.
	WG.buildmenu.clearCostOverrides = function(unitDefID)
		if unitDefID then
			costOverrides[unitDefID] = nil
		else
			for defID in pairs(costOverrides) do
				costOverrides[defID] = nil
			end
		end
		clear()
	end

	---Highlight a build option to draw the player's attention to it with a pulsing
	---inner outline and a soft inner glow. Non-destructive: does not affect input or
	---block hover/selection visuals. Subsequent calls update the existing highlight.
	---@param unitDefID UnitDefID The unit definition ID to highlight.
	---@param color number[]? Optional {r,g,b} in 0..1. Defaults to a warm yellow.
	WG.buildmenu.setHighlight = function(unitDefID, color)
		if not unitDefID then
			return
		end
		if not highlights[unitDefID] then
			highlightCount = highlightCount + 1
		end
		highlights[unitDefID] = {
			color = color,
			startTime = (highlights[unitDefID] and highlights[unitDefID].startTime) or os_clock(),
		}
	end

	---Remove a highlight previously set via setHighlight.
	---@param unitDefID UnitDefID
	WG.buildmenu.removeHighlight = function(unitDefID)
		if unitDefID and highlights[unitDefID] then
			highlights[unitDefID] = nil
			highlightCount = math_max(0, highlightCount - 1)
		end
	end

	---Clear all active highlights.
	WG.buildmenu.clearHighlights = function()
		for k in pairs(highlights) do
			highlights[k] = nil
		end
		highlightCount = 0
	end

	---Returns true if there is an active highlight for the given unitDefID.
	---@param unitDefID UnitDefID
	---@return boolean
	WG.buildmenu.hasHighlight = function(unitDefID)
		return unitDefID ~= nil and highlights[unitDefID] ~= nil
	end

	-- CONTROLLER NATIVE UI INTEGRATION (v0.8.0 experimental hybrid)
	-- Export all authoritative cells.  The controller radial owns presentation,
	-- while this widget owns ordering, availability, focus and activation.
	WG['buildmenu'].controllerGetItems = function()
		local result = {}
		local pageSize = rows * colls
		for cellID = 1, cmdsCount do
			local cmd = cmds[cellID]
			if cmd and cmd.id then
				local unitDefID = -cmd.id
				local page = math_floor((cellID - 1) / math_max(1, pageSize)) + 1
				local pageCell = ((cellID - 1) % math_max(1, pageSize))
				local unitDef = UnitDefs and UnitDefs[unitDefID]
				local quotaInfo = cellQuotas[unitDefID]
				local quotaCount, quotaDesired, quotaText = nil, nil, nil
				if quotaInfo and quotaInfo.quota ~= 0 and WG.Quotas and type(WG.Quotas.getUnitAmount) == "function" then
					quotaCount = WG.Quotas.getUnitAmount(quotaInfo.builderID, unitDefID)
					quotaDesired = quotaInfo.quota
					quotaText = tostring(quotaCount) .. "/" .. tostring(quotaDesired)
				end
				result[#result + 1] = {
					stableKey = "build:" .. tostring(unitDefID),
					unitDefID = unitDefID,
					cmdID = cmd.id,
					name = unitTranslatedHumanName[unitDefID],
					tooltip = cmd.tooltip,
					description = unitTranslatedTooltip[unitDefID] or cmd.tooltip,
					queueCount = tonumber(cmd.params and cmd.params[1]) or 0,
					quotaCount = quotaCount,
					quotaDesired = quotaDesired,
					quotaText = quotaText,
					builderID = quotaInfo and quotaInfo.builderID or nil,
					disabled = units.unitRestricted[unitDefID] == true,
					metalCost = units.unitMetalCost[unitDefID],
					energyCost = units.unitEnergyCost[unitDefID],
					radarTexture = showRadarIcon and units.unitIconType[unitDefID]
						and iconTypes[units.unitIconType[unitDefID]] and (':l:' .. iconTypes[units.unitIconType[unitDefID]]) or nil,
					groupTexture = showGroupIcon and groups[units.unitGroup[unitDefID]]
						and (':l:' .. groups[units.unitGroup[unitDefID]]) or nil,
					health = unitDef and unitDef.health,
					iconTexture = "#" .. tostring(unitDefID),
					selected = activeCmd and cmd.name == activeCmd or false,
					focused = unitDefID == controllerFocusDefID,
					cell = cellID,
					vanillaIndex = cellID,
					page = page,
					row = math_floor(pageCell / math_max(1, colls)) + 1,
					column = (pageCell % math_max(1, colls)) + 1,
				}
			end
		end
		return result, currentPage, pages, colls, rows, ControllerBuildMenuHybridState.modelRevision
	end

	WG['buildmenu'].controllerSetFocus = function(unitDefID, source)
		if type(unitDefID) == "string" then
			unitDefID = tonumber(string.match(unitDefID, "^build:(%-?%d+)$"))
		end
		unitDefID = tonumber(unitDefID)
		if unitDefID and not unitDefToCellMap[unitDefID] then
			local targetCell
			for cellID = 1, cmdsCount do
				if cmds[cellID] and -cmds[cellID].id == unitDefID then targetCell = cellID; break end
			end
			if targetCell then
				local pageSize = math_max(1, rows * colls)
				local targetPage = math_floor((targetCell - 1) / pageSize) + 1
				if targetPage ~= currentPage then
					currentPage = targetPage
					RefreshCommands()
					doUpdate = true
				end
			else
				unitDefID = nil
			end
		end
		if controllerFocusDefID and controllerFocusDefID ~= unitDefID then
			WG['buildmenu'].removeHighlight(controllerFocusDefID)
		end
		local changed = controllerFocusDefID ~= unitDefID or ControllerBuildMenuHybridState.focusSource ~= (source or "controller")
		controllerFocusDefID = unitDefID
		ControllerBuildMenuHybridState.focusSource = unitDefID and (source or "controller") or "none"
		if unitDefID and ControllerBuildMenuHybridState.focusVisible then
			WG['buildmenu'].setHighlight(unitDefID, { 0.35, 0.78, 1.0 })
		end
		if changed then ControllerBuildMenuHybridState.focusRevision = ControllerBuildMenuHybridState.focusRevision + 1 end
		return controllerFocusDefID
	end
	WG['buildmenu'].controllerGetFocus = function()
		local cellID
		for index = 1, cmdsCount do
			if cmds[index] and -cmds[index].id == controllerFocusDefID then cellID = index; break end
		end
		return {
			stableKey = controllerFocusDefID and ("build:" .. tostring(controllerFocusDefID)) or nil,
			unitDefID = controllerFocusDefID,
			cell = cellID,
			page = cellID and (math_floor((cellID - 1) / math_max(1, rows * colls)) + 1) or currentPage,
			revision = ControllerBuildMenuHybridState.focusRevision,
			modelRevision = ControllerBuildMenuHybridState.modelRevision,
			source = ControllerBuildMenuHybridState.focusSource,
			radialOpen = ControllerBuildMenuHybridState.radialOpen,
		}
	end

	WG['buildmenu'].controllerMoveFocus = function(deltaX, deltaY)
		local items = WG['buildmenu'].controllerGetItems()
		if #items == 0 then
			WG['buildmenu'].controllerSetFocus(nil)
			return nil
		end
		local index = 1
		for i = 1, #items do
			if items[i].unitDefID == controllerFocusDefID then
				index = i
				break
			end
		end
		index = math_max(1, math.min(#items, index + (deltaX or 0) + ((deltaY or 0) * colls)))
		return WG['buildmenu'].controllerSetFocus(items[index].unitDefID, "controller-grid"), items[index]
	end

	WG['buildmenu'].controllerActivate = function(unitDefID, button)
		if type(unitDefID) == "string" then
			unitDefID = tonumber(string.match(unitDefID, "^build:(%-?%d+)$"))
		end
		local cellID = unitDefToCellMap[unitDefID]
		if not cellID then
			for index = 1, cmdsCount do
				if cmds[index] and -cmds[index].id == unitDefID then cellID = index; break end
			end
		end
		local cmd = cellID and cmds[cellID]
		if not cmd or units.unitRestricted[unitDefID] then
			return false
		end
		local cmdDescIndex = spGetCmdDescIndex(cmd.id)
		if not cmdDescIndex then
			return false
		end
		button = button or 1
		Spring.SetActiveCommand(cmdDescIndex, button, button == 1, button == 3, Spring.GetModKeyState())
		return true
	end
	-- Factory/Lab queue edits deliberately use the same command-cell click path
	-- as BAR's native Build Menu. Shift is BAR/Recoil's authoritative x5
	-- quantity modifier; right-click removal naturally clamps at queue zero.
	WG['buildmenu'].controllerQueue = function(unitDefID, delta)
		delta = tonumber(delta)
		if delta ~= 1 and delta ~= -1 and delta ~= 5 and delta ~= -5 then return false end
		if type(unitDefID) == "string" then
			unitDefID = tonumber(string.match(unitDefID, "^build:(%-?%d+)$"))
		end
		local cellID = unitDefToCellMap[unitDefID]
		if not cellID then
			for index = 1, cmdsCount do
				if cmds[index] and -cmds[index].id == unitDefID then cellID = index; break end
			end
		end
		local cmd = cellID and cmds[cellID]
		if not cmd or units.unitRestricted[unitDefID] then return false end
		local cmdDescIndex = spGetCmdDescIndex(cmd.id)
		if not cmdDescIndex then return false end
		local button, shift = delta > 0 and 1 or 3, math.abs(delta) == 5
		Spring.SetActiveCommand(cmdDescIndex, button, button == 1, button == 3,
			false, false, false, shift)
		return true
	end
	WG['buildmenu'].controllerSetRadialOpen = function(active, showFocus)
		ControllerBuildMenuHybridState.radialOpen = active == true
		if showFocus ~= nil then WG['buildmenu'].controllerSetFocusVisible(showFocus) end
		if not ControllerBuildMenuHybridState.radialOpen then WG['buildmenu'].controllerSetFocus(nil, "radial-closed") end
		return ControllerBuildMenuHybridState.radialOpen
	end
	WG['buildmenu'].controllerSetFocusVisible = function(visible)
		ControllerBuildMenuHybridState.focusVisible = visible ~= false
		if not ControllerBuildMenuHybridState.focusVisible and controllerFocusDefID then
			WG['buildmenu'].removeHighlight(controllerFocusDefID)
		elseif ControllerBuildMenuHybridState.focusVisible and controllerFocusDefID then
			WG['buildmenu'].setHighlight(controllerFocusDefID, { 0.35, 0.78, 1.0 })
		end
		return ControllerBuildMenuHybridState.focusVisible
	end

	WG['buildmenu'].controllerSetInputActive = function(active)
		local nextActive = active == true
		if controllerInputActive == nextActive then return end
		controllerInputActive = nextActive
		if not controllerInputActive then
			WG['buildmenu'].controllerSetFocus(nil)
		end
		widget:ViewResize()
	end
	WG['buildmenu'].controllerGetInputActive = function()
		return controllerInputActive
	end
	WG['buildmenu'].controllerSetPanelVisible = function(visible)
		controllerPanelVisible = visible ~= false
		if not controllerPanelVisible and WG['guishader'] and dlistGuishader then
			WG['guishader'].RemoveDlist('buildmenu')
		end
		return controllerPanelVisible
	end
	WG['buildmenu'].controllerGetPanelVisible = function() return controllerPanelVisible end
	WG['buildmenu'].controllerApiVersion = 2
end

function widget:UnitBlocked(unitDefID, reasons, builderUnitDefID)
	units.setBlocked(unitDefID, reasons, builderUnitDefID)
	if not delayRefresh or delayRefresh < spGetGameSeconds() then
		delayRefresh = spGetGameSeconds() + 0.5 -- delay so multiple sequential UnitBlocked calls are batched in a single update.
	end
end

function widget:BuildOptionsChanged(builderUnitDefID, builtUnitDefID, added)
	local buildOptions = unitBuildOptions[builderUnitDefID]
	if buildOptions then
		dynamicBuildOptions.patch(buildOptions, builtUnitDefID, added)
		unitBuildOptionSet[builderUnitDefID][builtUnitDefID] = added or nil
	end
	if currentSelBuilderDefs[builderUnitDefID] then
		cachedActiveCmdDescs = nil
		doUpdate = true
	end
end

function widget:Shutdown()
	clear()
	if WG.guishader and dlistGuishader then
		WG.guishader.DeleteDlist("buildmenu")
		dlistGuishader = nil
	end
	WG.buildmenu = nil
end

function widget:GetConfigData()
	return {
		showPrice = showPrice,
		showRadarIcon = showRadarIcon,
		showGroupIcon = showGroupIcon,
		dynamicIconsize = dynamicIconsize,
		minColls = minColls,
		maxColls = maxColls,
		defaultColls = defaultColls,
		stickToBottom = stickToBottom,
		maxPosY = maxPosY,
		gameID = Game.gameID and Game.gameID or Spring.GetGameRulesParam("GameID"),
		alwaysShow = alwaysShow,
	}
end

function widget:SetConfigData(data)
	if data.showPrice ~= nil then
		showPrice = data.showPrice
	end
	if data.showRadarIcon ~= nil then
		showRadarIcon = data.showRadarIcon
	end
	if data.showGroupIcon ~= nil then
		showGroupIcon = data.showGroupIcon
	end
	if data.dynamicIconsize ~= nil then
		dynamicIconsize = data.dynamicIconsize
	end
	if data.minColls ~= nil then
		minColls = data.minColls
	end
	if data.maxColls ~= nil then
		maxColls = data.maxColls
	end
	if data.defaultColls ~= nil then
		defaultColls = data.defaultColls
	end
	if data.stickToBottom ~= nil then
		stickToBottom = data.stickToBottom
	end
	if data.alwaysShow ~= nil then
		alwaysShow = data.alwaysShow
	end
	if data.maxPosY ~= nil then
		maxPosY = data.maxPosY
	end
end
