local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Build Split",
		desc = "Splits builds over cons, and vice versa (use shift+space to activate)",
		author = "Niobium",
		version = "v1.0",
		date = "Jan 11, 2009",
		license = "GNU GPL, v2 or later",
		layer = 0,
		enabled = true,
	}
end

-- Localized Spring API for performance
local spGetSpectatingState = Spring.GetSpectatingState

local spTestBuildOrder = Spring.TestBuildOrder
local spGetSelUnitCount = Spring.GetSelectedUnitsCount
local spGetSelUnitsSorted = Spring.GetSelectedUnitsSorted
local activeModifier = false

local unitBuildOptions = {}
for udefID, def in ipairs(UnitDefs) do
	if #def.buildOptions > 0 then
		unitBuildOptions[udefID] = def.buildOptions
	end
end

local buildID = 0
local buildLocs = {}
local buildCount = 0

-- The consumed commands never reach the LuaRules command limiter, so the batch
-- is bounded here (same figure as the limiter).
local MAX_BUILDINGS = 700
local limitReported = false

local gameStarted = false
local isSpec = false

local function maybeRemoveSelf()
	if isSpec then
		widgetHandler:RemoveWidget()

		return true
	end
end

function widget:GameStart()
	gameStarted = true
end

function widget:PlayerChanged()
	isSpec = spGetSpectatingState()
	maybeRemoveSelf()
end

local function handleSetModifier(_, _, _, data)
	data = data or {}
	activeModifier = data[1]
end

local function getBuilderInfos(unitIDs)
	local builders = {}
	for _, unitID in ipairs(unitIDs) do
		local builderInfo = WG.api_build_orders.getBuilderInfo(unitID)
		if builderInfo and unitBuildOptions[builderInfo.unitDefID] then
			table.insert(builders, builderInfo)
		end
	end
	return builders
end

---@param builderIDs UnitID[]
---@param buildings BuildingInfo[]
---@param cmdOpts table
local function splitBuildings(builderIDs, buildings, cmdOpts)
	local builders = getBuilderInfos(builderIDs)
	WG.api_build_orders.splitBuildOrders(builders, buildings, cmdOpts or { "shift" })
end

-- Minimal controller adapter over the same api_build_orders allocator used by
-- the vanilla shift+space CommandNotify workflow.
local function controllerDistribute(buildCmdID, buildPositions)
	local unitDefID = math.abs(tonumber(buildCmdID) or 0)
	local builderIDs = {}
	for uDefID, unitIDs in pairs(spGetSelUnitsSorted()) do
		local unitDef = UnitDefs[uDefID]
		if unitDef and unitDef.buildOptions and #unitDef.buildOptions > 0 then
			for _, unitID in ipairs(unitIDs) do builderIDs[#builderIDs + 1] = unitID end
		end
	end
	if unitDefID == 0 or #builderIDs < 2 or type(buildPositions) ~= "table" or #buildPositions == 0 then
		return false, #builderIDs, 0
	end
	local buildings = {}
	for _, params in ipairs(buildPositions) do
		buildings[#buildings + 1] = {
			unitDefID = unitDefID,
			position = { params[1], params[2], params[3] },
			facing = params[4] or 0,
		}
	end
	splitBuildings(builderIDs, buildings, { "shift" })
	return true, #builderIDs, #buildings
end

function widget:Initialize()
	gameStarted = Spring.GetGameFrame() > 0
	isSpec = spGetSpectatingState()

	if maybeRemoveSelf() then
		return
	end

	widgetHandler:AddAction("buildsplit", handleSetModifier, { true }, "p")
	widgetHandler:AddAction("buildsplit", handleSetModifier, { false }, "r")

	WG.build_split = {
		isActive = function()
			return activeModifier
		end,
		splitBuildings = splitBuildings,
		controllerDistribute = controllerDistribute,
	}
end

function widget:CommandNotify(cmdID, cmdParams, cmdOpts) -- 3 of 3 parameters
	-- Don't handle blueprint commands (let cmd_blueprint handle those)
	if cmdID == GameCMD.BLUEPRINT_PLACE or cmdID == GameCMD.BLUEPRINT_CREATE then
		return false
	end

	if not (cmdID < 0 and cmdOpts.shift and activeModifier) then
		return false
	end -- Note: All multibuilds require shift

	if spGetSelUnitCount() < 2 then
		return false
	end

	if buildCount >= MAX_BUILDINGS then
		if not limitReported then
			limitReported = true
			Spring.Echo(string.format("[Build Split] limiting to %d buildings", MAX_BUILDINGS))
		end
		return true
	end

	--if #cmdParams < 4 then return false end -- Probably not possible, commented for now
	if spTestBuildOrder(-cmdID, cmdParams[1], cmdParams[2], cmdParams[3], cmdParams[4]) == 0 then
		-- A blocked spot is skipped. Passing it on would hand it to every
		-- selected builder, and to CommandInsert when its modifier is held too.
		return true
	end

	buildID = -cmdID
	buildCount = buildCount + 1
	buildLocs[buildCount] = cmdParams

	return true
end

function widget:Update()
	if buildCount == 0 then
		return
	end

	if not gameStarted then
		return
	end

	local selUnits = spGetSelUnitsSorted()

	local builderIDs = {}
	for uDefID, uIDs in pairs(selUnits) do
		if unitBuildOptions[uDefID] then
			for _, uID in ipairs(uIDs) do
				table.insert(builderIDs, uID)
			end
		end
	end

	local buildings = {}
	for i = 1, buildCount do
		---@type BuildingInfo
		local buildingInfo = {}
		buildingInfo.unitDefID = buildID
		buildingInfo.position = { buildLocs[i][1], buildLocs[i][2], buildLocs[i][3] }
		buildingInfo.facing = buildLocs[i][4]
		table.insert(buildings, buildingInfo)
	end

	splitBuildings(builderIDs, buildings, { "shift" })

	buildCount = 0
	limitReported = false
end

function widget:Shutdown()
	WG.build_split = nil
end
