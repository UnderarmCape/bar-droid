--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  file:    unit_smart_area_reclaim.lua
--  brief:   Area reclaims only metal or energy depending on the center feature
--  original author: Ryan Hileman
--
--  Copyright (C) 2010.
--  Public Domain.
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Smart Area Reclaim",
		desc = "Area reclaims only metal or energy depending on the center feature",
		author = "aegis",
		date = "Jun 25, 2010",
		license = "Public Domain",
		layer = 0,
		enabled = true,
	}
end

-- Localized Spring API for performance
local spGetGameFrame = Spring.GetGameFrame

local maxOrdersCheck = 100 -- max amount of orders to check for duplicate orders on units
local maxReclaimOrders = 1000 -- max amount of orders to issue at once

local maxUnits = Game.maxUnits
local GetSelectedUnits = Spring.GetSelectedUnits
local GetUnitDefID = Spring.GetUnitDefID
local GetUnitCommands = Spring.GetUnitCommands
local GetUnitPosition = Spring.GetUnitPosition
local GetFeaturePosition = Spring.GetFeaturePosition
local GetFeatureResources = Spring.GetFeatureResources
local GiveOrderToUnit = Spring.GiveOrderToUnit

local WorldToScreenCoords = Spring.WorldToScreenCoords
local TraceScreenRay = Spring.TraceScreenRay

local sort = table.sort

local RECLAIM = CMD.RECLAIM
local MOVE = CMD.MOVE
local INSERT = CMD.INSERT
local OPT_SHIFT = CMD.OPT_SHIFT
local OPT_ALT = CMD.OPT_ALT

local abs = math.abs
local sqrt = math.sqrt
local atan2 = math.atan2

local gameStarted

local mapSize = math.max(Game.mapSizeX, Game.mapSizeZ)
local reclaimOrders = {}
local controllerTargeting = {
	active = false,
	mode = nil,
	targetID = nil,
	x = nil,
	y = nil,
	z = nil,
	radius = 120,
}
local smartControllerOwner
local smartOwnerRegistered = false
local controllerHighlightedTargets = {}

local unitCanReclaim = {}
local unitCanMove = {}
local unitBuildDistance = {}
for udefID, def in ipairs(UnitDefs) do
	if def.canReclaim then
		unitCanReclaim[udefID] = true
		unitCanMove[udefID] = def.canMove
		unitBuildDistance[udefID] = def.buildDistance
	end
end

local function maybeRemoveSelf()
	if Spring.GetSpectatingState() and (spGetGameFrame() > 0 or gameStarted) then
		widgetHandler:RemoveWidget()
	end
end

function widget:GameStart()
	gameStarted = true
	maybeRemoveSelf()
end

function widget:PlayerChanged()
	maybeRemoveSelf()
end

function widget:Update()
	-- The restored v0.6 camera owns the controller gesture. Smart Area Reclaim
	-- remains the native mouse command transformer and highlight provider only.
	smartOwnerRegistered = false
end

function widget:Initialize()
	if Spring.IsReplay() or spGetGameFrame() > 0 then
		maybeRemoveSelf()
	end

	-- CONTROLLER NATIVE UI INTEGRATION (v0.8.0 experimental)
	-- Recoil owns CMD.RECLAIM and its one-, four-, and five-parameter forms.
	-- This API only bridges controller focus/radius input into those native
	-- command representations; it does not maintain a separate target set.
	local function selectedReclaimers()
		local result = {}
		local selected = GetSelectedUnits()
		for i = 1, #selected do
			local unitID = selected[i]
			if unitCanReclaim[GetUnitDefID(unitID)] then
				result[#result + 1] = unitID
			end
		end
		return result
	end

	local function cancelControllerTargeting()
		controllerTargeting.active = false
		controllerTargeting.mode = nil
		controllerTargeting.targetID = nil
		Spring.SetActiveCommand(nil)
	end

	WG['smartareareclaim'] = WG['smartareareclaim'] or {}
	WG['smartareareclaim'].controllerCompleteArea = function(descriptor, mode, targetID, x, y, z, radius, options, dispatchMode)
		local api = WG and WG.ordermenu
		if not (api and type(api.controllerCompleteTargetShape) == "function") then
			return false, "Order Menu hybrid dispatcher unavailable"
		end
		mode = mode == "same" and "same" or (mode == "single" and "single" or "any")
		local params, shape
		if mode == "single" then
			if not tonumber(targetID) then return false, "target unavailable" end
			params, shape = { tonumber(targetID) }, "point"
		elseif mode == "same" then
			if not tonumber(targetID) or not tonumber(x) or not tonumber(z) or not tonumber(radius) then
				return false, "incomplete same-type area"
			end
			params, shape = {
				tonumber(targetID), tonumber(x), tonumber(y) or Spring.GetGroundHeight(x, z),
				tonumber(z), math.max(1, tonumber(radius)),
			}, "area"
		else
			if not tonumber(x) or not tonumber(z) or not tonumber(radius) then return false, "incomplete area" end
			params, shape = {
				tonumber(x), tonumber(y) or Spring.GetGroundHeight(x, z), tonumber(z),
				math.max(1, tonumber(radius)),
			}, "area"
		end
		return api.controllerCompleteTargetShape(descriptor, shape, params, options, dispatchMode)
	end
	WG['smartareareclaim'].controllerBegin = function(mode, targetID, x, y, z, radius)
		if #selectedReclaimers() == 0 then
			return false
		end
		local cmdDescIndex = Spring.GetCmdDescIndex(RECLAIM)
		if not cmdDescIndex then
			return false
		end
		controllerTargeting.active = true
		controllerTargeting.mode = mode == 'any' and 'any' or (mode == 'same' and 'same' or 'single')
		controllerTargeting.targetID = targetID
		controllerTargeting.x = x
		controllerTargeting.y = y
		controllerTargeting.z = z
		controllerTargeting.radius = math.max(16, math.min(mapSize / 4, radius or 120))
		Spring.SetActiveCommand(cmdDescIndex, 1, true, false, false, false, false, false)
		return true
	end

	WG['smartareareclaim'].controllerUpdate = function(targetID, x, y, z, radius)
		if not controllerTargeting.active then
			return false
		end
		controllerTargeting.targetID = targetID or controllerTargeting.targetID
		controllerTargeting.x = x or controllerTargeting.x
		controllerTargeting.y = y or controllerTargeting.y
		controllerTargeting.z = z or controllerTargeting.z
		if radius then
			controllerTargeting.radius = math.max(16, math.min(mapSize / 4, radius))
		end
		return true
	end

	WG['smartareareclaim'].controllerConfirm = function(shift)
		if not controllerTargeting.active then
			return false
		end
		local reclaimers = selectedReclaimers()
		if #reclaimers == 0 then
			cancelControllerTargeting()
			return false
		end
		local params
		if controllerTargeting.mode == 'single' then
			if not controllerTargeting.targetID then return false end
			params = { controllerTargeting.targetID }
		elseif controllerTargeting.mode == 'same' then
			if not controllerTargeting.targetID or not controllerTargeting.x or not controllerTargeting.z then return false end
			params = {
				controllerTargeting.targetID,
				controllerTargeting.x,
				controllerTargeting.y or Spring.GetGroundHeight(controllerTargeting.x, controllerTargeting.z),
				controllerTargeting.z,
				controllerTargeting.radius,
			}
		else
			if not controllerTargeting.x or not controllerTargeting.z then return false end
			params = {
				controllerTargeting.x,
				controllerTargeting.y or Spring.GetGroundHeight(controllerTargeting.x, controllerTargeting.z),
				controllerTargeting.z,
				controllerTargeting.radius,
			}
		end
		local api = WG and WG.ordermenu
		if not (api and type(api.controllerIssueCommand) == "function") then return false end
		local accepted = api.controllerIssueCommand(RECLAIM, params, shift and { 'shift' } or {})
		if accepted ~= true then return false end
		cancelControllerTargeting()
		return true
	end

	WG['smartareareclaim'].controllerCancel = cancelControllerTargeting
	WG['smartareareclaim'].controllerGetState = function()
		return controllerTargeting.active, controllerTargeting.mode, controllerTargeting.targetID,
			controllerTargeting.x, controllerTargeting.y, controllerTargeting.z, controllerTargeting.radius
	end
	WG['smartareareclaim'].controllerSetHighlightedTargets = function(targets)
		controllerHighlightedTargets = type(targets) == "table" and targets or {}
	end
	WG['smartareareclaim'].controllerClearHighlightedTargets = function()
		controllerHighlightedTargets = {}
	end
	WG['smartareareclaim'].controllerOwner = nil
	WG['smartareareclaim'].controllerApiVersion = 3
end

function widget:Shutdown()
	local api = WG and WG.ordermenu
	if smartOwnerRegistered and api and type(api.controllerUnregisterCommandOwner) == "function" then
		api.controllerUnregisterCommandOwner(RECLAIM, smartControllerOwner)
	end
	if WG.ControllerNativeCommandOwners then WG.ControllerNativeCommandOwners[RECLAIM] = nil end
	WG['smartareareclaim'] = nil
end

function widget:DrawWorld()
	local ownerState = smartControllerOwner and smartControllerOwner:GetState() or nil
	local hasLegacyArea = controllerTargeting.active and controllerTargeting.mode ~= 'single'
		and controllerTargeting.x and controllerTargeting.z
	if ownerState and ownerState.anchor and ownerState.current
			and ownerState.anchor.x and ownerState.anchor.y and ownerState.anchor.z then
		gl.Color(0.35, 1.0, 0.25, 0.82)
		gl.LineWidth(2.25)
		gl.DrawGroundCircle(ownerState.anchor.x, ownerState.anchor.y or 0,
			ownerState.anchor.z, ownerState.radius or 0, 64)
	elseif hasLegacyArea then
		gl.Color(0.35, 1.0, 0.25, 0.82)
		gl.LineWidth(2.25)
		gl.DrawGroundCircle(controllerTargeting.x, controllerTargeting.y or 0,
			controllerTargeting.z, controllerTargeting.radius, 64)
	end
	for unitID in pairs(controllerHighlightedTargets) do
		local x, y, z = GetUnitPosition(unitID)
		if x then gl.DrawGroundCircle(x, y or 0, z, 34, 24) end
	end
	gl.LineWidth(1)
	gl.Color(1, 1, 1, 1)
end

local function tsp(rList, tList, dx, dz)
	dx = dx or 0
	dz = dz or 0
	tList = tList or {}

	if rList == nil then
		return
	end

	local closestDist
	local closestItem
	local closestIndex

	for i = 1, #rList do
		local item = rList[i]
		if item ~= nil and item ~= 0 then
			local distx, distz = item[1] - dx, item[2] - dz
			local dist = abs(distx) + abs(distz)
			if closestDist == nil or dist < closestDist then
				closestDist = dist
				closestItem = item
				closestIndex = i
			end
		end
	end

	if closestItem == nil then
		return tList
	end

	tList[#tList + 1] = closestItem
	rList[closestIndex] = 0
	return tsp(rList, tList, closestItem[1], closestItem[2])
end

local function stationary(rList)
	local sList = {}
	local sKeys = {}
	local sKeysCount = 0
	local lastKey, lastItem
	local lastItemCount = 0
	for i = 1, #rList do
		local item = rList[i]
		local dx, dz = item[1], item[2]

		local theta = atan2(dx, dz)
		if lastKey ~= theta then
			sKeysCount = sKeysCount + 1
			sKeys[sKeysCount] = theta
			lastItem = { item }
			lastItemCount = 1
			sList[theta] = lastItem
		else
			lastItemCount = lastItemCount + 1
			lastItem[lastItem] = item
			sList[theta] = lastItem
		end
	end

	local oList = {}
	local oListCount = 0
	sort(sKeys)
	for i = 1, #sKeys do
		local theta = sKeys[i]
		local values = sList[theta]
		for j = 1, #values do
			oListCount = oListCount + 1
			oList[oListCount] = values[j]
		end
	end
	return oList
end

local function issue(rList, shift, meta)
	local opts = {}
	local insertPos = {}

	for i = 1, #rList do
		local item = rList[i]
		local uid, fid = item[3], item[4]

		if meta then
			-- insert at the front of the queue, keeping the order computed above
			local pos = insertPos[uid] or 0
			GiveOrderToUnit(uid, INSERT, { pos, RECLAIM, 0, fid + maxUnits }, OPT_ALT)
			insertPos[uid] = pos + 1
		else
			local opt = {}
			if opts[uid] ~= nil or shift then
				opt = OPT_SHIFT
			end

			GiveOrderToUnit(uid, RECLAIM, { fid + maxUnits }, opt)
			opts[uid] = 1
		end
	end
end

-- we use the previous unit loop iterating on cmds to store reclaim orders
-- and return cmds for its original usage
local function storeReclaimOrders(uid)
	local cmds = GetUnitCommands(uid, maxOrdersCheck)

	reclaimOrders[uid] = {}
	local reclaimOrdersCount = 0

	for _, order in pairs(cmds) do
		if order.id == RECLAIM then
			reclaimOrdersCount = reclaimOrdersCount + 1
			reclaimOrders[uid][reclaimOrdersCount] = order.params[1]
		end
	end

	return cmds
end

local function checkNoDuplicateOrder(uid, fid)
	local orderParam = fid + maxUnits

	for _, reclaimParam in pairs(reclaimOrders[uid] or {}) do
		if reclaimParam == orderParam then
			return false
		end
	end

	return true
end

function widget:CommandNotify(id, params, options)
	-- early exit if criteria does not match
	if id ~= RECLAIM then
		return false
	end
	-- CONTROLLER NATIVE UI INTEGRATION: Recoil's five-parameter reclaim form is the native
	-- same-type semantic { targetID, x, y, z, radius }. It must bypass the four-parameter
	-- smart feature transform and reach the engine unchanged.
	if #params == 5 then
		return false
	end
	if not params[4] then
		return false
	end

	local x, y, z, r = params[1], params[2], params[3], params[4]

	if r > mapSize / 4 then
		Spring.Log(widget.GetInfo().name, LOG.WARNING, "Smart reclaim area is too large, limiting size")
		r = math.floor(mapSize / 4)
	end

	local mx, my = WorldToScreenCoords(x, y, z)
	local type, originFeatureId = TraceScreenRay(mx, my)

	if type ~= "feature" then
		return false
	end

	local commandHeight = Spring.GetGroundHeight(x, z)

	local mobiles, stationaries = {}, {}
	local mobileb, stationaryb = false, false

	local rUnits = {}
	local rUnitsCount = 0
	local sUnits = GetSelectedUnits()

	-- clear reclaim orders cache
	reclaimOrders = {}

	for i = 1, #sUnits do
		local uid = sUnits[i]
		local udid = GetUnitDefID(uid)
		if unitCanReclaim[udid] then
			if not unitCanMove[udid] then
				stationaries[uid] = unitBuildDistance[udid]
				stationaryb = true
			else
				mobiles[uid] = unitBuildDistance[udid]
				mobileb = true
			end

			local ux, _, uz = GetUnitPosition(uid)
			if options.shift or options.meta then
				local cmds = storeReclaimOrders(uid)
				-- appended orders start where the queue ends; inserted ones run
				-- first, so those keep the unit's current position
				if options.shift and not options.meta then
					for ci = #cmds, 1, -1 do
						local cmd = cmds[ci]
						if cmd.id == MOVE then
							ux, uz = cmd.params[1], cmd.params[3]
							break
						end
					end
				end
			end
			rUnitsCount = rUnitsCount + 1
			rUnits[rUnitsCount] = { uid = uid, ux = ux, uz = uz }
		end
	end

	if #rUnits > 0 then
		local retw, rmtw, retg, rmtg = {}, {}, {}, {}

		-- Sort features by above water, below water, metal value, energy value
		local features = Spring.GetFeaturesInCylinder(x, z, r)
		for i = 1, #features, 1 do
			local featureID = features[i]
			local _, featY, _ = GetFeaturePosition(featureID)
			local featM, _, featE = GetFeatureResources(featureID)
			if featY < 0 then
				if featM > 0 then
					rmtw[#rmtw + 1] = featureID
				elseif featE > 0 then
					retw[#retw + 1] = featureID
				end
			elseif featY > 0 then
				if featM > 0 then
					rmtg[#rmtg + 1] = featureID
				elseif featE > 0 then
					retg[#retg + 1] = featureID
				end
			end
		end

		local featM, _, featE = GetFeatureResources(originFeatureId)

		local mList, sList = {}, {}
		local mListCount, sListCount = 0, 0
		local filteredFeatures = {}

		-- pick most relevant reclaim type, starting with above ground metal, then energy, then uw
		if #rmtg > 0 and featM > 0 and commandHeight > 0 then
			filteredFeatures = rmtg
		elseif #retg > 0 and featE > 0 and commandHeight > 0 then
			filteredFeatures = retg
		elseif #rmtw > 0 and featM > 0 and commandHeight < 0 then
			filteredFeatures = rmtw
		elseif #retw > 0 and featE > 0 and commandHeight < 0 then
			filteredFeatures = retw
		end

		for i = 1, #filteredFeatures do
			local fid = filteredFeatures[i]
			if fid ~= nil then
				local fx, _, fz = GetFeaturePosition(fid)
				for ui = 1, #rUnits do
					local unit = rUnits[ui]
					local uid, ux, uz = unit.uid, unit.ux, unit.uz
					local dx, dz = ux - fx, uz - fz
					local item = { dx, dz, uid, fid }
					if mobiles[uid] ~= nil then
						if not (options.shift or options.meta) or checkNoDuplicateOrder(uid, fid) then
							mListCount = mListCount + 1
							mList[mListCount] = item
						end
					elseif stationaries[uid] ~= nil then
						if
							sqrt((dx * dx) + (dz * dz)) <= stationaries[uid]
							and (not (options.shift or options.meta) or checkNoDuplicateOrder(uid, fid))
						then
							sListCount = sListCount + 1
							sList[sListCount] = item
						end
					end
				end
				if mListCount > maxReclaimOrders then
					Spring.Log(
						widget:GetInfo().name,
						LOG.WARNING,
						"Command count exceeded, feature selection may be incomplete"
					)
					break
				end
			end
		end

		local issued = false
		if mobileb then
			mList = tsp(mList)
			issue(mList, options.shift, options.meta)
			issued = true
		end

		if stationaryb then
			sList = stationary(sList)
			issue(sList, options.shift, options.meta)
			issued = true
		end

		return issued
	end
end
