local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Order menu",
		desc = "",
		author = "Floris",
		date = "April 2020",
		license = "GNU GPL, v2 or later",
		layer = 1,
		enabled = true,
	}
end

-- Localized functions for performance
local mathCeil = math.ceil
local mathFloor = math.floor

-- Localized Spring API for performance
local spGetSelectedUnits = Spring.GetSelectedUnits
local spGetGameFrame = Spring.GetGameFrame
local spGetViewGeometry = Spring.GetViewGeometry
local spGetSpectatingState = Spring.GetSpectatingState

local CustomFirestateDefs = require("modules/custom_firestate_defs")
local OrderMenuFirestate = require("luaui/Include/ordermenu_firestate")
local keyConfig = require("luaui/configs/keyboard_layouts")
local ControllerNativeCommandOwner = VFS.Include("luaui/Include/controller_native_command_owner.lua")
local CANCEL_TARGET_CMD_ID = 34924
local currentLayout

local function resolveHotkeyTargetVirtualIndex(optWords)
	local selectedUnits = spGetSelectedUnits()
	if #selectedUnits == 0 then
		return nil
	end
	local param = optWords[1] and tonumber(optWords[1])
	if param ~= nil then
		return param + 1
	end
	local virtualIndex = OrderMenuFirestate.resolveVirtualIndex(selectedUnits[1])
	if virtualIndex == nil then
		return nil
	end
	local _, _, shift = Spring.GetModKeyState()
	return OrderMenuFirestate.nextCycledVirtualIndex(virtualIndex, shift)
end

local function installFirestateNotifyHooks()
	local originalHotkeyHandler = OrderMenuFirestate.hotkeyHandler
	OrderMenuFirestate.hotkeyHandler = function(cmd, optLine, optWords, data, isRepeat, release)
		if not release then
			local targetIndex = resolveHotkeyTargetVirtualIndex(optWords)
			if targetIndex then
				OrderMenuFirestate.giveVirtualIndex(targetIndex, 0)
				return false
			end
		end
		return originalHotkeyHandler(cmd, optLine, optWords, data, isRepeat, release)
	end
end

local cellZoom = 1
local cellClickedZoom = 1.05
local cellHoverZoom = 1.035

local showIcons = false
local colorize = 0
local playSounds = true
local stickToBottom = true
local alwaysShow = false

---@type number
local posX = 0
local posY = 0.8
---@type number
local width = 0
---@type number
local height = 0
local cellMarginOriginal = 0.055
local cellMargin = cellMarginOriginal
local commandInfo = {
	move = { red = 0.64, green = 1, blue = 0.64 },
	stop = { red = 1, green = 0.3, blue = 0.3 },
	attack = { red = 1, green = 0.5, blue = 0.35 },
	areaattack = { red = 1, green = 0.35, blue = 0.15 },
	manualfire = { red = 1, green = 0.7, blue = 0.7 },
	patrol = { red = 0.73, green = 0.73, blue = 1 },
	fight = { red = 0.9, green = 0.5, blue = 1 },
	resurrect = { red = 1, green = 0.75, blue = 1 },
	guard = { red = 0.33, green = 0.92, blue = 1 },
	wait = { red = 0.7, green = 0.66, blue = 0.6 },
	repair = { red = 1, green = 0.95, blue = 0.7 },
	reclaim = { red = 0.86, green = 1, blue = 0.86 },
	restore = { red = 0.77, green = 1, blue = 0.77 },
	capture = { red = 1, green = 0.85, blue = 0.22 },
	settarget = { red = 1, green = 0.66, blue = 0.35 },
	canceltarget = { red = 0.8, green = 0.55, blue = 0.2 },
	areamex = { red = 0.93, green = 0.93, blue = 0.93 },
	upgrademex = { red = 0.93, green = 0.93, blue = 0.93 },
	loadunits = { red = 0.1, green = 0.7, blue = 1 },
	unloadunits = { red = 0, green = 0.5, blue = 1 },
	wantcloak = { red = nil, green = nil, blue = nil },
	onoff = { red = nil, green = nil, blue = nil },
	sellunit = { red = nil, green = nil, blue = nil },
}
local isStateCommand = {}

local disabledCommand = {}

---@type number, number
local vsx, vsy = spGetViewGeometry()

local barGlowCenterTexture = ":l:LuaUI/Images/barglow-center.png"
local barGlowEdgeTexture = ":l:LuaUI/Images/barglow-edge.png"

local soundButton = "LuaUI/Sounds/buildbar_waypoint.wav"

local uiOpacity = Spring.GetConfigFloat("ui_opacity", 0.7)
local uiScale = Spring.GetConfigFloat("ui_scale", 1)

---@alias OrderMenuRect [number, number, number, number]

---@type OrderMenuRect
local backgroundRect = { 0, 0, 0, 0 }
---@type OrderMenuRect
local activeRect = { 0, 0, 0, 0 }
---@type OrderMenuRect[]
local cellRects = {}
local cellMarginPx = 0
local cellMarginPx2 = 0
---@class OrderMenuCommand : CommandDescription
---@field id integer
---@field action string
---@field name string
---@field cursor string
---@field params string[]
---@field cachedText string?
---@field virtualIndex integer?
---@field pipFillMin integer?
---@field pipFillMax integer?

---@type OrderMenuCommand[]
local commands = {}
local rows = 0
local cols = 0
local disableInput = false

-- Highlight API state: items[cmdID] = { color={r,g,b}, startTime=os.clock() }
local highlight = { items = {}, count = 0, defaultColor = { 1.0, 1.0, 1.0 } }
ControllerOrderMenuHybridState = ControllerOrderMenuHybridState or {
	focusCmdID = nil, radialOpen = false, focusVisible = true,
	focusRevision = 0, modelRevision = 0, focusSource = "none",
}
local math_isInRect = math.isInRect
local clickCountDown = 2

---@type LuaFont, number, number, integer?, integer?
local font, backgroundPadding, widgetSpaceMargin, displayListOrders, displayListGuiShader
---@type integer?, number?, integer?, number, number
local clickedCell, clickedCellTime, clickedCellDesiredState, cellWidth, cellHeight
local buildmenuBottomPosition
local activeCommand, previousActiveCommand, doUpdate, doUpdateClock
---@type number
local minimapHeight = 0
local ordermenuTex, ordermenuBgTex
local ordermenuShows = false
local controllerPanelVisible = true
local stateLightDisplayLists = {}
local controllerTargetOwner
local controllerCommandOwners = {}
local controllerActiveTargetAPI
local controllerTargetDiagnostics = { revision = 0, events = {}, last = "IDLE" }
local drawCell

local function controllerTargetTrace(event, detail)
	local row = tostring(event) .. (detail and (" | " .. tostring(detail)) or "")
	if controllerTargetDiagnostics.last == row then return end
	controllerTargetDiagnostics.revision = controllerTargetDiagnostics.revision + 1
	controllerTargetDiagnostics.last = row
	controllerTargetDiagnostics.events[#controllerTargetDiagnostics.events + 1] = row
	while #controllerTargetDiagnostics.events > 12 do table.remove(controllerTargetDiagnostics.events, 1) end
end

-- Cache for translations to avoid repeated Spring.I18N calls
local translationCache = {}
local function getCachedTranslation(key, params)
	if params then
		-- Don't cache when params are provided since they can vary
		return BAR.I18N(key, params)
	end
	if not translationCache[key] then
		translationCache[key] = BAR.I18N(key)
	end
	return translationCache[key]
end

-- Throttling for command refresh
---@type number
local lastCommandRefreshTime = 0
local commandRefreshDelay = 0.05 -- 50ms delay

-- Cache for hotkey strings
---@type table<string, string>
local hotkeyCache = {}

-- Reusable tables to reduce allocations in hot paths
local stateCommandsTemp = {}
local otherCommandsTemp = {}

-- Persistent cache for command display text (survives across refreshCommands calls)
local commandTextCache = {}

-- Cached WAIT command state (computed once per refresh, not per drawCell call)
local cachedWaitState = nil
local hasWaitCommand = false
local cachedFirstUnit = nil -- first selected unit, avoids spGetSelectedUnits() table alloc

-- Cancel target button visibility tracking
---@type number
local cancelTargetPollSec = 0
local cancelTargetLastState = false

local function selectionHasPriorityTarget(selected)
	for i = 1, #selected do
		if Spring.GetUnitRulesParam(selected[i], "hasPriorityTarget") then
			return true
		end
	end
	return false
end

-- Command fingerprint to skip redundant R2T redraws
local prevCmdCount = 0
local prevCmdIDs = {}
local prevCmdStates = {}
local prevCmdModes = {}
local prevActiveCmd = nil
local commandsVisuallyChanged = true

-- Font metrics cache (cleared on ViewResize when font changes)
---@type table<string, number>
local fontWidthCache = {} -- text -> GetTextWidth result (with padding)
---@type table<string, number>
local fontHeightCache = {} -- text -> GetTextHeight result

-- Colorized text color cache (cleared when colorize changes)
local colorStrCache = {}
local lastColorize = -1

-- Pre-built printable text cache: textColor .. text (cleared on redraw)
local printTextCache = {}

local hiddenCommands = {
	[CMD.LOAD_ONTO] = true,
	[CMD.SELFD] = true,
	[CMD.GATHERWAIT] = true,
	[CMD.SQUADWAIT] = true,
	[CMD.DEATHWAIT] = true,
	[CMD.TIMEWAIT] = true,
	[CMD.AUTOREPAIRLEVEL] = true, -- retreat/idle mode (air repair pads removed)
	[39812] = true, -- raw move
	[34922] = true, -- set unit target (no ground)
}

local hiddenCommandTypes = {
	[CMDTYPE.CUSTOM] = true,
	[CMDTYPE.PREV] = true,
	[CMDTYPE.NEXT] = true,
}

local CMDTYPE_ICON_BUILDING = CMDTYPE.ICON_BUILDING
local CMDTYPE_ICON_MODE = CMDTYPE.ICON_MODE

local spGetActiveCommand = Spring.GetActiveCommand
local spGetActiveCmdDescs = Spring.GetActiveCmdDescs

local os_clock = os.clock

local glTexture = gl.Texture
local glTexRect = gl.TexRect
local glColor = gl.Color
local glRect = gl.Rect
local glBlending = gl.Blending
local glCreateList = gl.CreateList
local glCallList = gl.CallList
local glDeleteList = gl.DeleteList
local GL_SRC_ALPHA = GL.SRC_ALPHA
local GL_ONE_MINUS_SRC_ALPHA = GL.ONE_MINUS_SRC_ALPHA
local GL_ONE = GL.ONE

local math_min = math.min
local math_max = math.max
local math_clamp = math.clamp
local math_ceil = mathCeil
local math_floor = mathFloor

---@type fun(...: any), fun(...: any), fun(...: any), number
local RectRound, UiElement, UiButton, elementCorner

local isSpectating = spGetSpectatingState()
local cursorTextures = {}
---@type table<string, string>
local actionHotkeys

local function clearStateLightDisplayLists()
	for cell, cache in pairs(stateLightDisplayLists) do
		glDeleteList(cache.list)
		stateLightDisplayLists[cell] = nil
	end
end

local isFactory = {}
for unitDefID, unitDef in pairs(UnitDefs) do
	if unitDef.isFactory then
		isFactory[unitDefID] = true
	end
end

local function checkGuiShader(force)
	if WG.guishader then
		if force and displayListGuiShader then
			displayListGuiShader = gl.DeleteList(displayListGuiShader)
		end
		if not displayListGuiShader then
			displayListGuiShader = gl.CreateList(function()
				RectRound(
					backgroundRect[1],
					backgroundRect[2],
					backgroundRect[3],
					backgroundRect[4],
					elementCorner * uiScale,
					((posX <= 0) and 0 or 1),
					1,
					((posY - height > 0 or posX <= 0) and 1 or 0),
					((posY - height > 0 and posX > 0) and 1 or 0)
				)
			end)
		end
	elseif displayListGuiShader then
		displayListGuiShader = gl.DeleteList(displayListGuiShader)
	end
end

function widget:PlayerChanged(playerID)
	isSpectating = spGetSpectatingState()
end

local function setupCellGrid(force)
	tracy.ZoneBeginN("W:OrderMenu:SetupCellGrid")
	local oldCols = cols
	local oldRows = rows
	local cmdCount = #commands
	local addCol = uiScale < 0.85 and -1 or 0
	local addRow = uiScale < 0.85 and 0 or 0
	if cmdCount <= (4 + addCol) * (4 + addRow) then
		cols = 4 + addCol
		rows = 4 + addRow
	elseif cmdCount <= (5 + addCol) * (4 + addRow) then
		cols = 5 + addCol
		rows = 4 + addRow
	elseif cmdCount <= (5 + addCol) * (5 + addRow) then
		cols = 5 + addCol
		rows = 5 + addRow
	elseif cmdCount <= (5 + addCol) * (6 + addRow) then
		cols = 5 + addCol
		rows = 6 + addRow
	elseif cmdCount <= (6 + addCol) * (6 + addRow) then
		cols = 6 + addCol
		rows = 6 + addRow
	elseif cmdCount <= (6 + addCol) * (7 + addRow) then
		cols = 6 + addCol
		rows = 7 + addRow
	else
		cols = 7 + addCol
		rows = 7 + addRow
	end

	-- BAR Droid (Kailil, 2026-10-29): while the pad is the input the orders it gives with its buttons are hidden
	-- (bardroid_pad.lua, through setDisabledCmd) and the rest fill the menu evenly, whatever their number: as many rows as
	-- make the buttons about twice as wide as tall (BAR's own buttons' shape: their words stay readable), each row's
	-- buttons sharing its width (WG.BarDroidPadOrders)
	local evenRows = nil
	if WG.BarDroidPadOrders and cmdCount > 0 then
		local w, h = activeRect[3] - activeRect[1], activeRect[4] - activeRect[2]
		local r = math_max(1, math.min(cmdCount, math_floor(math.sqrt(2 * cmdCount * h / math_max(1, w)) + 0.5)))
		evenRows = {}
		local left = cmdCount
		for i = 1, r do
			evenRows[i] = math_ceil(left / (r - i + 1))
			left = left - evenRows[i]
		end
		cols, rows = evenRows[1], r
	end
	local evenKey = evenRows and (cmdCount .. "x" .. rows) or nil
	if evenKey ~= ControllerOrderMenuHybridState.droidEvenKey then
		ControllerOrderMenuHybridState.droidEvenKey = evenKey
		force = true
	end

	local sizeDivider = ((cols + rows) / 16)
	cellMargin = (cellMarginOriginal / sizeDivider) * uiScale

	if (force or oldCols ~= cols or oldRows ~= rows) and evenRows then
		clearStateLightDisplayLists()
		clickedCell = nil
		clickedCellTime = nil
		clickedCellDesiredState = nil
		local w = activeRect[3] - activeRect[1]
		cellHeight = math_floor((activeRect[4] - activeRect[2]) / rows)
		cellWidth = math_floor(w / cols)
		cellMarginPx = math_max(1, math_ceil(cellHeight * 0.5 * cellMargin))
		cellMarginPx2 = math_max(0, math_ceil(cellHeight * 0.18 * cellMargin))
		local i = 0
		for row = 1, rows do
			local k = evenRows[row]
			for col = 1, k do
				i = i + 1
				cellRects[i] = cellRects[i] or {}
				local rect = cellRects[i]
				rect[1] = math_floor(activeRect[1] + w * (col - 1) / k + 0.5)
				rect[2] = math_floor(activeRect[4] - cellHeight * row + 0.5)
				rect[3] = math_floor(activeRect[1] + w * col / k + 0.5)
				rect[4] = math_floor(activeRect[4] - cellHeight * (row - 1) + 0.5)
			end
		end
		for j = i + 1, #cellRects do
			cellRects[j] = nil
		end
	elseif force or oldCols ~= cols or oldRows ~= rows then
		clearStateLightDisplayLists()
		clickedCell = nil
		clickedCellTime = nil
		clickedCellDesiredState = nil

		-- Reuse cellRects table instead of creating new one
		local i = 0
		cellWidth = math_floor((activeRect[3] - activeRect[1]) / cols)
		cellHeight = math_floor((activeRect[4] - activeRect[2]) / rows)
		local leftOverWidth = ((activeRect[3] - activeRect[1]) - (cellWidth * cols)) - 1
		local leftOverHeight = ((activeRect[4] - activeRect[2]) - (cellHeight * rows)) - (posY - height <= 0 and 1 or 0)
		cellMarginPx = math_max(1, math_ceil(cellHeight * 0.5 * cellMargin))
		cellMarginPx2 = math_max(0, math_ceil(cellHeight * 0.18 * cellMargin))

		---@type number
		local addedWidth = 0
		---@type number
		local addedHeight = 0
		local addedWidthFloat = 0
		local addedHeightFloat = 0
		local prevAddedWidth = 0
		local prevAddedHeight = 0
		for row = 1, rows do
			prevAddedHeight = addedHeight
			addedHeightFloat = addedHeightFloat + (leftOverHeight / rows)
			addedHeight = math_floor(addedHeightFloat)
			prevAddedWidth = 0
			addedWidthFloat = 0
			for col = 1, cols do
				addedWidthFloat = addedWidthFloat + (leftOverWidth / cols)
				addedWidth = math_floor(addedWidthFloat)
				i = i + 1
				-- Reuse existing table if available
				if not cellRects[i] then
					cellRects[i] = {}
				end
				local rect = cellRects[i]
				rect[1] = math_floor(activeRect[1] + prevAddedWidth + (cellWidth * (col - 1)) + 0.5)
				rect[2] = math_floor(activeRect[4] - addedHeight - (cellHeight * row) + 0.5)
				rect[3] = math_ceil(activeRect[1] + addedWidth + (cellWidth * col) + 0.5)
				rect[4] = math_ceil(activeRect[4] - prevAddedHeight - (cellHeight * (row - 1)) + 0.5)
				prevAddedWidth = addedWidth
			end
		end
		-- Clear unused cellRects
		for j = i + 1, #cellRects do
			cellRects[j] = nil
		end
	end
	tracy.ZoneEnd()
end

local function computeWaitState()
	if not hasWaitCommand then
		cachedWaitState = nil
		return
	end
	-- Use cached first unit instead of calling spGetSelectedUnits() which allocates a large table
	local ref = cachedFirstUnit
	if ref and Spring.ValidUnitID(ref) and Spring.FindUnitCmdDesc(ref, CMD.WAIT) then
		local commandQueue
		if isFactory[Spring.GetUnitDefID(ref)] then
			commandQueue = Spring.GetFactoryCommands(ref, 1)
		else
			commandQueue = Spring.GetUnitCommands(ref, 1)
		end
		if commandQueue and commandQueue[1] and commandQueue[1].id == CMD.WAIT then
			cachedWaitState = 2
		else
			cachedWaitState = 1
		end
	else
		cachedWaitState = nil
	end
end

local function refreshCommands()
	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands")
	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands:Collect")
	local waitCommand
	-- Clear and reuse temp tables instead of creating new ones
	local stateCommandsCount = 0
	local waitCommandCount = 0
	local otherCommandsCount = 0

	-- Clear old entries
	for i = #stateCommandsTemp, 1, -1 do
		stateCommandsTemp[i] = nil
	end
	for i = #otherCommandsTemp, 1, -1 do
		otherCommandsTemp[i] = nil
	end

	-- cancelTargetLastState is kept current by SelectionChanged and by the poll in Update
	local cancelTargetRelevant = cancelTargetLastState

	local activeCmdDescs = spGetActiveCmdDescs()
	for _, command in ipairs(activeCmdDescs) do
		if type(command) == "table" and not disabledCommand[command.name] then
			if command.type == CMDTYPE_ICON_MODE then
				isStateCommand[command.id] = true
				widgetHandler:RegisterUnitCommand(command.id)
			end
			if
				not hiddenCommands[command.id]
				and not hiddenCommandTypes[command.type]
				and command.action ~= nil
				and not command.disabled
				and not (command.id == CANCEL_TARGET_CMD_ID and not cancelTargetRelevant)
			then
				if
					command.type == CMDTYPE_ICON_BUILDING or (string.find(command.action, "buildunit_", 1, true) == 1)
				then
					-- intentionally empty, no action to take
				elseif isStateCommand[command.id] then
					stateCommandsCount = stateCommandsCount + 1
					if command.id == CMD.FIRE_STATE and cachedFirstUnit and Spring.ValidUnitID(cachedFirstUnit) then
						local virtualIndex = OrderMenuFirestate.resolveVirtualIndex(cachedFirstUnit)
						stateCommandsTemp[stateCommandsCount] = virtualIndex
								and OrderMenuFirestate.buildCmdDesc(command, virtualIndex)
							or command
					else
						stateCommandsTemp[stateCommandsCount] = command
					end
				elseif command.id == CMD.WAIT then
					waitCommandCount = 1
					waitCommand = command
				else
					otherCommandsCount = otherCommandsCount + 1
					otherCommandsTemp[otherCommandsCount] = command
				end
			end
		end
	end
	tracy.ZoneEnd()

	-- Reuse commands table instead of creating new one
	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands:BuildList")
	local totalCommands = stateCommandsCount + waitCommandCount + otherCommandsCount
	-- Clear old entries beyond what we need
	for i = totalCommands + 1, #commands do
		commands[i] = nil
	end

	for i = 1, stateCommandsCount do
		commands[i] = stateCommandsTemp[i]
	end
	if waitCommand then
		commands[1 + stateCommandsCount] = waitCommand
	end
	for i = 1, otherCommandsCount do
		commands[i + stateCommandsCount + waitCommandCount] = otherCommandsTemp[i]
	end

	-- OPTIMIZATION: Cache the display text using persistent commandTextCache
	for _, cmd in ipairs(commands) do
		if isStateCommand[cmd.id] then
			local commandState = (cmd.id == CMD.FIRE_STATE) and OrderMenuFirestate.stateLabel(cmd)
				or CustomFirestateDefs.stateLabel(cmd)
			if commandState then
				if not commandTextCache[commandState] then
					commandTextCache[commandState] = getCachedTranslation("commands." .. commandState)
				end
				cmd.cachedText = commandTextCache[commandState]
			else
				cmd.cachedText = "?"
			end
		else
			if cmd.action == "stockpile" then
				-- Stockpile command name gets mutated to reflect the current status, so can't cache persistently
				cmd.cachedText = getCachedTranslation("commands." .. cmd.action, { stockpileStatus = cmd.name })
			else
				local actionKey = cmd.action
				if not commandTextCache[actionKey] then
					commandTextCache[actionKey] = getCachedTranslation("commands." .. actionKey)
				end
				cmd.cachedText = commandTextCache[actionKey]
			end
		end
	end
	tracy.ZoneEnd()

	hasWaitCommand = (waitCommand ~= nil)

	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands:WaitState")
	computeWaitState()
	tracy.ZoneEnd()

	-- Fingerprint: detect if commands visually changed to skip redundant R2T redraws
	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands:Fingerprint")
	commandsVisuallyChanged = false
	local cmdCount = #commands
	if cmdCount ~= prevCmdCount or activeCommand ~= prevActiveCmd then
		commandsVisuallyChanged = true
	else
		for i, cmd in ipairs(commands) do
			if cmd.id ~= prevCmdIDs[i] then
				commandsVisuallyChanged = true
				break
			end
			if isStateCommand[cmd.id] then
				local mode = (cmd.id == CMD.FIRE_STATE) and (cmd.virtualIndex or 1)
					or ((tonumber(cmd.params[1]) or 0) + 1)
				if cmd.cachedText ~= prevCmdStates[i] or mode ~= prevCmdModes[i] then
					commandsVisuallyChanged = true
					break
				end
			elseif cmd.id == CMD.WAIT then
				if cachedWaitState ~= prevCmdStates[i] then
					commandsVisuallyChanged = true
					break
				end
			elseif cmd.action == "stockpile" and cmd.cachedText ~= prevCmdStates[i] then
				commandsVisuallyChanged = true
				break
			end
		end
	end
	if commandsVisuallyChanged then
		prevCmdCount = cmdCount
		prevActiveCmd = activeCommand
		for i, cmd in ipairs(commands) do
			prevCmdIDs[i] = cmd.id
			if isStateCommand[cmd.id] then
				prevCmdStates[i] = cmd.cachedText
				prevCmdModes[i] = (cmd.id == CMD.FIRE_STATE) and (cmd.virtualIndex or 1)
					or ((tonumber(cmd.params[1]) or 0) + 1)
			elseif cmd.id == CMD.WAIT then
				prevCmdStates[i] = cachedWaitState
				prevCmdModes[i] = nil
			elseif cmd.action == "stockpile" then
				prevCmdStates[i] = cmd.cachedText
				prevCmdModes[i] = nil
			else
				prevCmdStates[i] = nil
				prevCmdModes[i] = nil
			end
		end
		-- Clear excess fingerprint entries
		for i = cmdCount + 1, #prevCmdIDs do
			prevCmdIDs[i] = nil
			prevCmdStates[i] = nil
			prevCmdModes[i] = nil
		end
		-- Invalidate print text cache since display changed
		for k in pairs(printTextCache) do
			printTextCache[k] = nil
		end
	end
	tracy.ZoneEnd()

	tracy.ZoneBeginN("W:OrderMenu:RefreshCommands:SetupGrid")
	setupCellGrid(false)
	tracy.ZoneEnd()
	ControllerOrderMenuHybridState.modelRevision = ControllerOrderMenuHybridState.modelRevision + 1
	tracy.ZoneEnd()
end

function widget:ViewResize()
	tracy.ZoneBeginN("W:OrderMenu:ViewResize")
	vsx, vsy = spGetViewGeometry()

	width = 0.2125
	height = 0.14 * uiScale

	width = width / (vsx / vsy) * 1.78 -- make smaller for ultrawide screens
	width = width * uiScale

	-- make pixel aligned
	width = mathFloor(width * vsx) / vsx
	height = mathFloor(height * vsy) / vsy

	if WG.buildmenu then
		buildmenuBottomPosition = WG.buildmenu.getBottomPosition()
	end

	font = WG.fonts.getFont(2)

	elementCorner = WG.FlowUI.elementCorner
	backgroundPadding = WG.FlowUI.elementPadding

	RectRound = WG.FlowUI.Draw.RectRound
	UiElement = WG.FlowUI.Draw.Element
	UiButton = WG.FlowUI.Draw.Button
	elementCorner = WG.FlowUI.elementCorner

	widgetSpaceMargin = WG.FlowUI.elementMargin

	if WG.minimap then
		minimapHeight = WG.minimap.getHeight()
	end
	if stickToBottom then
		posY = height
		posX = width + (widgetSpaceMargin / vsx)
	else
		if buildmenuBottomPosition then
			posX = 0
			posY = height + height + (widgetSpaceMargin / vsy)
		elseif WG.buildmenu then
			local posY2, _ = WG.buildmenu.getSize()
			posY2 = posY2 + (widgetSpaceMargin / vsy)
			posY = posY2 + height
			if WG.minimap then
				posY = 1 - (minimapHeight / vsy) - (widgetSpaceMargin / vsy)
			end
			posX = 0
		end
	end

	backgroundRect = { posX * vsx, (posY - height) * vsy, (posX + width) * vsx, posY * vsy }
	local activeBgpadding = math_floor((backgroundPadding * 1.4) + 0.5)
	activeRect = {
		(posX * vsx) + (posX > 0 and activeBgpadding or mathCeil(backgroundPadding * 0.6)),
		((posY - height) * vsy)
			+ (posY - height > 0 and math_floor(activeBgpadding) or math_floor(activeBgpadding / 3)),
		((posX + width) * vsx) - activeBgpadding,
		(posY * vsy) - activeBgpadding,
	}
	if displayListOrders then
		displayListOrders = gl.DeleteList(displayListOrders)
	end

	checkGuiShader(true)
	setupCellGrid(true)
	doUpdate = true

	-- Clear font metric caches since font changed
	for k in pairs(fontWidthCache) do
		fontWidthCache[k] = nil
	end
	for k in pairs(fontHeightCache) do
		fontHeightCache[k] = nil
	end
	for k in pairs(printTextCache) do
		printTextCache[k] = nil
	end

	if ordermenuTex then
		gl.DeleteTexture(ordermenuBgTex)
		ordermenuBgTex = nil
		gl.DeleteTexture(ordermenuTex)
		ordermenuTex = nil
	end
	-- Reset fingerprint so the next refresh always re-renders into the new texture
	prevCmdCount = -1
	tracy.ZoneEnd()
end

local function reloadBindings()
	currentLayout = Spring.GetConfigString("KeyboardLayout", "qwerty")
	actionHotkeys = require("luaui/Include/action_hotkeys")
end

function widget:Initialize()
	widgetHandler:RegisterUnitCommand(CMD.WAIT)
	OrderMenuFirestate.init({
		onOrderGiven = function()
			doUpdate = true
		end,
	})
	installFirestateNotifyHooks()
	reloadBindings()
	activeCommand = select(4, spGetActiveCommand())
	widget:ViewResize()
	widget:SelectionChanged(spGetSelectedUnits())

	WG.ordermenu = {}
	WG.ordermenu.getPosition = function()
		return posX, posY, width, height
	end
	WG.ordermenu.reloadBindings = reloadBindings
	WG.ordermenu.setBottomPosition = function(value)
		stickToBottom = value
		doUpdate = true
		widget:ViewResize()
	end
	WG.ordermenu.getAlwaysShow = function()
		return alwaysShow
	end
	WG.ordermenu.setAlwaysShow = function(value)
		alwaysShow = value
		doUpdate = true
	end
	WG.ordermenu.getBottomPosition = function()
		return stickToBottom
	end
	WG.ordermenu.getDisabledCmd = function(cmd)
		return disabledCommand[cmd]
	end
	WG.ordermenu.setDisabledCmd = function(params)
		if params[2] then
			disabledCommand[params[1]] = true
		else
			disabledCommand[params[1]] = nil
		end
		doUpdate = true
	end
	WG.ordermenu.getColorize = function()
		return colorize
	end
	WG.ordermenu.setColorize = function(value)
		doUpdate = true
		colorize = value
		if colorize > 1 then
			colorize = 1
		end
	end
	WG.ordermenu.getIsShowing = function()
		return ordermenuShows
	end

	---Highlight a command in the order menu with an animated pulsing outline +
	---inner glow. Subsequent calls update the existing highlight (without
	---restarting the pulse phase).
	---@param cmdID integer|CMD The command ID (e.g. CMD.MOVE, CMD.ATTACK) to highlight.
	---@param color number[]? Optional {r,g,b} in 0..1. Defaults to a warm yellow.
	WG.ordermenu.setHighlight = function(cmdID, color)
		if not cmdID then
			return
		end
		local items = highlight.items
		if not items[cmdID] then
			highlight.count = highlight.count + 1
		end
		items[cmdID] = {
			color = color,
			startTime = (items[cmdID] and items[cmdID].startTime) or os_clock(),
		}
	end

	WG.ordermenu.removeHighlight = function(cmdID)
		local items = highlight.items
		if cmdID and items[cmdID] then
			items[cmdID] = nil
			highlight.count = math_max(0, highlight.count - 1)
		end
	end

	WG.ordermenu.clearHighlights = function()
		local items = highlight.items
		for k in pairs(items) do
			items[k] = nil
		end
		highlight.count = 0
	end

	WG.ordermenu.hasHighlight = function(cmdID)
		return cmdID ~= nil and highlight.items[cmdID] ~= nil
	end

	-- CONTROLLER NATIVE UI INTEGRATION (v0.8.0 experimental)
	-- Export the already-filtered command panel model.  Callers receive shallow
	-- copies so controller focus cannot mutate BAR's authoritative descriptors.
	WG['ordermenu'].controllerGetCommands = function()
		local result = {}
		for i = 1, #commands do
			local cmd = commands[i]
			result[i] = {
				stableKey = "cmd:" .. tostring(cmd.id),
				id = cmd.id,
				cmdID = cmd.id,
				type = cmd.type,
				name = cmd.name,
				action = cmd.action,
				tooltip = cmd.tooltip,
				texture = cmd.texture,
				disabled = cmd.disabled == true,
				params = cmd.params,
				isState = isStateCommand[cmd.id] == true,
				virtualIndex = cmd.virtualIndex,
				currentStateIndex = (cmd.id == CMD.FIRE_STATE and cmd.virtualIndex)
					and math_max(0, cmd.virtualIndex - 1) or (tonumber(cmd.params and cmd.params[1]) or 0),
				vanillaIndex = i,
				cell = i,
				row = math_floor((i - 1) / math_max(1, cols)) + 1,
				column = ((i - 1) % math_max(1, cols)) + 1,
				focused = cmd.id == ControllerOrderMenuHybridState.focusCmdID,
			}
		end
		return result, ControllerOrderMenuHybridState.modelRevision
	end

	WG['ordermenu'].controllerActivate = function(cmdID, direction)
		local cmd
		for i = 1, #commands do
			if commands[i].id == cmdID then
				cmd = commands[i]
				break
			end
		end
		if not cmd or cmd.disabled then
			return false
		end
		local button = (direction or 1) < 0 and 3 or 1
		if cmd.id == CMD.FIRE_STATE then
			local virtualIndex = cmd.virtualIndex or 1
			local desired = OrderMenuFirestate.nextCycledVirtualIndex(virtualIndex, button ~= 1)
			OrderMenuFirestate.giveVirtualIndex(desired, 0)
			doUpdate = true
			return true
		end
		local cmdDescIndex = Spring.GetCmdDescIndex(cmd.id)
		if not cmdDescIndex then
			return false
		end
		Spring.SetActiveCommand(cmdDescIndex, button, button == 1, button == 3, Spring.GetModKeyState())
		doUpdate = true
		return true
	end
	-- Return the descriptor that the engine says is active, then reconcile it
	-- against this widget's current authoritative command list.  Controller
	-- targeting never relies on a stale radial selection.
	WG['ordermenu'].controllerGetActiveTargetDescriptor = function()
		local cmdIndex, activeID, activeType, activeName = Spring.GetActiveCommand()
		activeID = tonumber(activeID)
		if not cmdIndex or not activeID then return nil end
		local source
		for i = 1, #commands do
			if commands[i].id == activeID then source = commands[i]; break end
		end
		if not source or source.disabled then return nil end
		local engineDescriptor = type(Spring.GetActiveCmdDesc) == "function"
			and Spring.GetActiveCmdDesc(cmdIndex) or nil
		return {
			stableKey = "cmd:" .. tostring(activeID),
			cmdIndex = cmdIndex,
			id = activeID,
			cmdID = activeID,
			type = tonumber(engineDescriptor and engineDescriptor.type) or tonumber(activeType) or source.type,
			name = (engineDescriptor and engineDescriptor.name) or activeName or source.name,
			action = (engineDescriptor and engineDescriptor.action) or source.action,
			tooltip = (engineDescriptor and engineDescriptor.tooltip) or source.tooltip,
			params = (engineDescriptor and engineDescriptor.params) or source.params,
			disabled = false,
			buildFacing = Spring.GetBuildFacing and Spring.GetBuildFacing() or nil,
		}
	end

	local function controllerCommandOptions(options)
		local list, notify = {}, { alt = false, ctrl = false, meta = false, shift = false, right = false }
		if type(options) == "table" then
			for key, value in pairs(options) do
				local name = type(key) == "number" and tostring(value) or tostring(key)
				local enabled = type(key) == "number" or value == true
				if enabled and notify[name] ~= nil then
					notify[name] = true
					list[#list + 1] = name
				end
			end
		end
		return list, notify
	end
	local function controllerDescriptor(cmdID)
		cmdID = tonumber(cmdID)
		for i = 1, #commands do
			local source = commands[i]
			if source.id == cmdID and source.disabled ~= true then
				local cmdIndex = Spring.GetCmdDescIndex(cmdID)
				local engineDescriptor = cmdIndex and type(Spring.GetActiveCmdDesc) == "function"
					and Spring.GetActiveCmdDesc(cmdIndex) or nil
				return {
					stableKey = "cmd:" .. tostring(cmdID), cmdIndex = cmdIndex,
					id = cmdID, cmdID = cmdID,
					type = tonumber(engineDescriptor and engineDescriptor.type) or source.type,
					name = (engineDescriptor and engineDescriptor.name) or source.name,
					action = (engineDescriptor and engineDescriptor.action) or source.action,
					tooltip = (engineDescriptor and engineDescriptor.tooltip) or source.tooltip,
					params = (engineDescriptor and engineDescriptor.params) or source.params,
					disabled = false,
					buildFacing = Spring.GetBuildFacing and Spring.GetBuildFacing() or nil,
				}
			end
		end
	end
	-- Hybrid controller targeting deliberately captures a live descriptor before
	-- clearing Spring's active mouse command.  This lookup is therefore keyed by
	-- command identity, not by GetActiveCommand state.
	WG['ordermenu'].controllerGetCommandDescriptor = controllerDescriptor

	local function controllerDispatchCommand(cmdID, params, options, dispatchMode, nativeFinalizer)
		cmdID = tonumber(cmdID)
		if not controllerDescriptor(cmdID) or type(params) ~= "table" then
			return false, "live command unavailable"
		end
		local optionList, notifyOptions = controllerCommandOptions(options)
		local notifyOK, handled = pcall(widgetHandler.CommandNotify, widgetHandler,
			cmdID, params, notifyOptions)
		if not notifyOK then return false, "CommandNotify failed" end
		if handled then
			controllerTargetTrace("COMMAND_NOTIFY HANDLED", cmdID)
			return true, "widget"
		end
		if type(nativeFinalizer) == "function" then
			local finalOK, accepted, route = pcall(nativeFinalizer,
				cmdID, params, notifyOptions, optionList, dispatchMode)
			if not finalOK then return false, "native finalizer failed" end
			if accepted == true then controllerTargetTrace("NATIVE FINALIZER HANDLED", cmdID) end
			return accepted == true, route or (accepted and "native-finalizer" or "native finalizer rejected")
		end
		local issuedOK, accepted
		if dispatchMode == "insert-front" then
			local insertParams = { 0, cmdID, 0 }
			for i = 1, #params do insertParams[#insertParams + 1] = params[i] end
			issuedOK, accepted = pcall(Spring.GiveOrder, CMD.INSERT, insertParams, { "alt" })
		else
			issuedOK, accepted = pcall(Spring.GiveOrder, cmdID, params, optionList)
		end
		if issuedOK and accepted ~= false then controllerTargetTrace("GIVE_ORDER FALLBACK", cmdID) end
		return issuedOK and accepted ~= false, issuedOK and "engine" or "GiveOrder failed"
	end

	-- Mirror the native mouse release boundary: LuaUI CommandNotify gets first
	-- refusal (Area Mex and Smart Area Reclaim depend on this), then exactly one
	-- engine order is issued only when no widget handled the command.
	WG['ordermenu'].controllerIssueActiveTarget = function(expectedCmdID, params, options, dispatchMode, cachedDescriptor)
		local descriptor = WG['ordermenu'].controllerGetActiveTargetDescriptor()
		expectedCmdID = tonumber(expectedCmdID)
		if (not descriptor or descriptor.cmdID ~= expectedCmdID) and type(cachedDescriptor) == "table"
				and tonumber(cachedDescriptor.cmdID or cachedDescriptor.id) == expectedCmdID then
			-- BAR may clear Spring.GetActiveCommand after the controller anchor is
			-- placed. Revalidate the cached descriptor against the live Order Menu
			-- model instead of abandoning the controller-owned operation.
			for i = 1, #commands do
				if commands[i].id == expectedCmdID and commands[i].disabled ~= true then
					descriptor = cachedDescriptor
					break
				end
			end
		end
		if not descriptor or tonumber(descriptor.cmdID or descriptor.id) ~= expectedCmdID
				or type(params) ~= "table" then
			return false, "active and cached command unavailable"
		end
		return controllerDispatchCommand(expectedCmdID, params, options, dispatchMode)
	end

	-- Final boundary for controller-owned shapes.  Geometry collection remains
	-- outside the native mouse lifecycle; BAR still owns descriptor validation,
	-- CommandNotify transforms, and the single unhandled engine fallback.
	WG['ordermenu'].controllerCompleteTargetShape = function(descriptor, shape, params, options, dispatchMode, nativeFinalizer)
		local cmdID = type(descriptor) == "table" and tonumber(descriptor.cmdID or descriptor.id) or nil
		local liveDescriptor = cmdID and controllerDescriptor(cmdID) or nil
		if not liveDescriptor or type(params) ~= "table" then
			return false, "live descriptor unavailable"
		end
		local expectedShape = tostring(shape or "point")
		local typeID = tonumber(liveDescriptor.type)
		if expectedShape == "area" and #params < 4 then return false, "incomplete area" end
		if (expectedShape == "front" or expectedShape == "rectangle") and #params < 6 then
			return false, "incomplete shape"
		end
		controllerTargetTrace("NATIVE TRANSFORM CALLED", cmdID)
		controllerTargetTrace("SHAPE: " .. expectedShape, typeID)
		return controllerDispatchCommand(cmdID, params, options, dispatchMode, nativeFinalizer)
	end
	WG['ordermenu'].controllerHybridTargetingAPIVersion = 1

	-- Immediate native shortcut boundary.  Disabled or selection-ineligible
	-- descriptors are rejected before CommandNotify is entered.
	WG['ordermenu'].controllerIssueCommand = controllerDispatchCommand
	local function controllerParamsForTarget(descriptor, target)
		if type(descriptor) ~= "table" or type(target) ~= "table" then return nil end
		local targetType, targetID = target.targetType, tonumber(target.targetID)
		local typeID = tonumber(descriptor.type)
		if targetType == "unit" and targetID and typeID ~= CMDTYPE.ICON_MAP
				and typeID ~= CMDTYPE.ICON_AREA and typeID ~= CMDTYPE.ICON_FRONT then
			return { targetID }
		end
		if targetType == "feature" and targetID and typeID == CMDTYPE.ICON_UNIT_FEATURE_OR_AREA then
			return { tonumber(target.commandID) or targetID + (tonumber(Game and Game.maxUnits) or 32000) }
		end
		local x, y, z = tonumber(target.x), tonumber(target.y), tonumber(target.z)
		if not x or not y or not z then return nil end
		if typeID == CMDTYPE.ICON_UNIT then return nil end
		return { x, y, z }
	end
	WG['ordermenu'].controllerExecuteAtTarget = function(cmdID, target, options, dispatchMode)
		local descriptor = controllerDescriptor(cmdID)
		local params = controllerParamsForTarget(descriptor, target)
		if not params then return false, "native target unavailable" end
		return controllerDispatchCommand(cmdID, params, options, dispatchMode)
	end
	WG['ordermenu'].controllerIssueDefault = function(target, options, dispatchMode)
		if type(Spring.GetDefaultCommand) ~= "function" then return false, "default command API unavailable" end
		local _, cmdID = Spring.GetDefaultCommand()
		local descriptor = controllerDescriptor(cmdID)
		if not descriptor then return false, "default command unavailable" end
		local params = controllerParamsForTarget(descriptor, target)
		if not params then return false, "default target unavailable" end
		local accepted, route = controllerDispatchCommand(cmdID, params, options, dispatchMode)
		return accepted, route, cmdID
	end

	-- v0.6 restore: the controller camera is the sole point/area gesture owner.
	-- Descriptor, focus, state cycling, and immediate-command APIs remain, but
	-- the failed native owner-session broker is intentionally dormant.
	controllerTargetOwner = nil
	WG['ordermenu'].controllerRegisterCommandOwner = function(cmdID, ownerAPI, ownerName)
		return false, "v0.6 camera owns controller targeting"
	end
	WG['ordermenu'].controllerUnregisterCommandOwner = function(cmdID, ownerAPI)
		cmdID = tonumber(cmdID)
		local entry = controllerCommandOwners[cmdID]
		if entry and (ownerAPI == nil or entry.api == ownerAPI) then
			controllerCommandOwners[cmdID] = nil
			if WG.ControllerNativeCommandOwners then WG.ControllerNativeCommandOwners[cmdID] = nil end
		end
	end
	WG['ordermenu'].controllerGetCommandOwner = function(cmdID)
		local entry = controllerCommandOwners[tonumber(cmdID)]
			or (WG.ControllerNativeCommandOwners and WG.ControllerNativeCommandOwners[tonumber(cmdID)])
		return entry and entry.name or "Order Menu generic fallback"
	end
	WG['ordermenu'].controllerBeginTarget = function(cmdID)
		return false, "v0.6 camera owns controller targeting"
	end
	WG['ordermenu'].controllerTargetInput = function(input)
		return false, "inactive: v0.6 camera owns controller targeting"
	end
	WG['ordermenu'].controllerGetTargetState = function()
		return { phase = "IDLE", ownerName = "v0.6 camera", dispatchCount = 0 }
	end
	WG['ordermenu'].controllerCancelTarget = function(reason)
		local active = controllerActiveTargetAPI
		controllerActiveTargetAPI = nil
		local cancelled = active and active:Cancel(reason) or false
		if cancelled then controllerTargetTrace("SESSION CLOSED", reason or "cancelled") end
		return cancelled
	end
	WG['ordermenu'].controllerGetTargetDiagnostics = function()
		local events = {}
		for i, event in ipairs(controllerTargetDiagnostics.events) do events[i] = event end
		local ownerCount = 0
		for _ in pairs(controllerCommandOwners) do ownerCount = ownerCount + 1 end
		return {
			revision = controllerTargetDiagnostics.revision,
			last = controllerTargetDiagnostics.last,
			events = events,
			ownerCount = ownerCount,
			areaMexRegistered = GameCMD and controllerCommandOwners[GameCMD.AREA_MEX] ~= nil,
			smartAreaReclaimRegistered = controllerCommandOwners[CMD.RECLAIM] ~= nil,
			dispatcherConnected = true,
		}
	end
	WG['ordermenu'].controllerTargetingAPIVersion = 6
	WG['ordermenu'].controllerActivateState = function(cmdID, desiredState)
		cmdID, desiredState = tonumber(cmdID), tonumber(desiredState)
		local cmd
		for i = 1, #commands do
			if commands[i].id == cmdID then cmd = commands[i]; break end
		end
		if not cmd or cmd.disabled or not isStateCommand[cmd.id] or desiredState == nil then
			return false
		end
		local stateCount = type(cmd.params) == "table" and math_max(0, #cmd.params - 1) or 0
		if desiredState < 0 or (stateCount > 0 and desiredState >= stateCount) then return false end
		if cmd.id == CMD.FIRE_STATE then
			OrderMenuFirestate.giveVirtualIndex(desiredState + 1, 0)
		elseif type(Spring.GiveOrder) == "function" then
			Spring.GiveOrder(cmd.id, { desiredState }, 0)
		else
			return false
		end
		doUpdate = true
		return true
	end

	WG['ordermenu'].controllerSetFocus = function(cmdID, source)
		if type(cmdID) == "string" then cmdID = tonumber(string.match(cmdID, "^cmd:(%-?%d+)$")) end
		cmdID = tonumber(cmdID)
		local exists = cmdID == nil
		if cmdID then
			for i = 1, #commands do if commands[i].id == cmdID then exists = true; break end end
		end
		if not exists then cmdID = nil end
		if ControllerOrderMenuHybridState.focusCmdID and ControllerOrderMenuHybridState.focusCmdID ~= cmdID then
			WG['ordermenu'].removeHighlight(ControllerOrderMenuHybridState.focusCmdID)
		end
		local changed = ControllerOrderMenuHybridState.focusCmdID ~= cmdID
			or ControllerOrderMenuHybridState.focusSource ~= (source or "controller")
		ControllerOrderMenuHybridState.focusCmdID = cmdID
		ControllerOrderMenuHybridState.focusSource = cmdID and (source or "controller") or "none"
		if cmdID and ControllerOrderMenuHybridState.focusVisible then
			WG['ordermenu'].setHighlight(cmdID, { 0.35, 0.78, 1.0 })
		end
		if changed then ControllerOrderMenuHybridState.focusRevision = ControllerOrderMenuHybridState.focusRevision + 1 end
		return ControllerOrderMenuHybridState.focusCmdID
	end
	WG['ordermenu'].controllerGetFocus = function()
		return {
			stableKey = ControllerOrderMenuHybridState.focusCmdID and ("cmd:" .. tostring(ControllerOrderMenuHybridState.focusCmdID)) or nil,
			cmdID = ControllerOrderMenuHybridState.focusCmdID,
			revision = ControllerOrderMenuHybridState.focusRevision,
			modelRevision = ControllerOrderMenuHybridState.modelRevision,
			source = ControllerOrderMenuHybridState.focusSource,
			radialOpen = ControllerOrderMenuHybridState.radialOpen,
		}
	end
	WG['ordermenu'].controllerSetFocusVisible = function(visible)
		ControllerOrderMenuHybridState.focusVisible = visible ~= false
		if not ControllerOrderMenuHybridState.focusVisible and ControllerOrderMenuHybridState.focusCmdID then
			WG['ordermenu'].removeHighlight(ControllerOrderMenuHybridState.focusCmdID)
		elseif ControllerOrderMenuHybridState.focusVisible and ControllerOrderMenuHybridState.focusCmdID then
			WG['ordermenu'].setHighlight(ControllerOrderMenuHybridState.focusCmdID, { 0.35, 0.78, 1.0 })
		end
		return ControllerOrderMenuHybridState.focusVisible
	end
	WG['ordermenu'].controllerSetPanelVisible = function(visible)
		controllerPanelVisible = visible ~= false
		if not controllerPanelVisible and WG['guishader'] and displayListGuiShader then
			WG['guishader'].RemoveDlist('ordermenu')
		end
		return controllerPanelVisible
	end
	WG['ordermenu'].controllerGetPanelVisible = function() return controllerPanelVisible end
	-- Tactical Radial delegates its outer buttons here, so background, border,
	-- state pips, disabled appearance, and text metrics are literally the Order
	-- Menu renderer rather than a controller approximation.
	WG['ordermenu'].controllerDrawCommandButton = function(cmdID, rect, selected)
		if type(rect) ~= "table" or type(drawCell) ~= "function" or not font then return false end
		local cell
		for i = 1, #commands do if commands[i].id == tonumber(cmdID) then cell = i; break end end
		if not cell then return false end
		local savedRect, savedActive, savedCache = cellRects[cell], activeCommand, stateLightDisplayLists[cell]
		cellRects[cell] = { rect[1], rect[2], rect[3], rect[4] }
		activeCommand = selected == true and commands[cell].name or false
		stateLightDisplayLists[cell] = nil
		font:Begin(true)
		drawCell(cell, 1)
		font:End()
		local temporaryCache = stateLightDisplayLists[cell]
		if temporaryCache and temporaryCache.list then glDeleteList(temporaryCache.list) end
		stateLightDisplayLists[cell], cellRects[cell], activeCommand = savedCache, savedRect, savedActive
		return true
	end
	WG['ordermenu'].controllerSetRadialOpen = function(active, showFocus)
		ControllerOrderMenuHybridState.radialOpen = active == true
		if showFocus ~= nil then WG['ordermenu'].controllerSetFocusVisible(showFocus) end
		if not ControllerOrderMenuHybridState.radialOpen then WG['ordermenu'].controllerSetFocus(nil, "radial-closed") end
		return ControllerOrderMenuHybridState.radialOpen
	end
	WG['ordermenu'].controllerApiVersion = 2
	-- BAR Droid: the cells as laid out (bottom left origin) and the orders in them, in the same order: the app's gamepad
	-- controls step through them (bardroid_pad.lua), the even layout included
	WG['ordermenu'].droidCells = function()
		return cellRects, commands
	end

	widgetHandler:AddAction("firestate", OrderMenuFirestate.hotkeyHandler, nil, "p")
end

function widget:Shutdown()
	clearStateLightDisplayLists()
	if WG.guishader and displayListGuiShader then
		WG.guishader.DeleteDlist("ordermenu")
		displayListGuiShader = nil
	end
	if displayListOrders then
		displayListOrders = gl.DeleteList(displayListOrders)
	end
	if ordermenuBgTex then
		gl.DeleteTexture(ordermenuBgTex)
		ordermenuBgTex = nil
	end
	if ordermenuTex then
		gl.DeleteTexture(ordermenuTex)
		ordermenuTex = nil
	end
	WG.ordermenu = nil
end

local buildmenuBottomPos = false
---@type number
local sec = 0
function widget:Update(dt)
	tracy.ZoneBeginN("W:OrderMenu:Update")
	ordermenuShows = false

	sec = sec + dt
	if sec > 0.5 then
		tracy.ZoneBeginN("W:OrderMenu:Update:Periodic")
		sec = 0
		checkGuiShader()

		if WG.buildmenu and WG.buildmenu.getBottomPosition then
			local prevbuildmenuBottomPos = buildmenuBottomPos
			buildmenuBottomPos = WG.buildmenu.getBottomPosition()
			if buildmenuBottomPos ~= prevbuildmenuBottomPos then
				widget:ViewResize()
			end
		end

		if WG.minimap and minimapHeight ~= WG.minimap.getHeight() then
			widget:ViewResize()
			setupCellGrid(true)
			doUpdate = true
		end

		disableInput = isSpectating
		if Spring.IsGodModeEnabled() then
			disableInput = false
		end
		tracy.ZoneEnd()
	end

	clickCountDown = clickCountDown - 1
	if clickCountDown == 0 then
		doUpdate = true
	end

	-- Poll for priority target changes on selected units to show/hide 'canceltarget'
	cancelTargetPollSec = cancelTargetPollSec + dt
	if cancelTargetPollSec > 0.1 then
		cancelTargetPollSec = 0
		if #commands > 0 or alwaysShow then
			local selected = Spring.GetSelectedUnits()
			local hasTarget = selectionHasPriorityTarget(selected)
			if hasTarget ~= cancelTargetLastState then
				cancelTargetLastState = hasTarget
				doUpdate = true
			end
		end
	end

	if
		(WG.guishader and not displayListGuiShader) or (#commands == 0 and (not alwaysShow or spGetGameFrame() == 0))
	then
		ordermenuShows = false
	else
		ordermenuShows = true
	end
	tracy.ZoneEnd()
end

function widget:ActiveCommandChanged(cmdID)
	previousActiveCommand = activeCommand
	activeCommand = cmdID and select(4, spGetActiveCommand()) or nil
	if activeCommand ~= previousActiveCommand then
		doUpdate = true
	end
end

local function RectQuad(px, py, sx, sy, offset)
	gl.TexCoord(offset, 1 - offset)
	gl.Vertex(px, py, 0)
	gl.TexCoord(1 - offset, 1 - offset)
	gl.Vertex(sx, py, 0)
	gl.TexCoord(1 - offset, offset)
	gl.Vertex(sx, sy, 0)
	gl.TexCoord(offset, offset)
	gl.Vertex(px, sy, 0)
end
local function DrawRect(px, py, sx, sy, zoom)
	gl.BeginEnd(GL.QUADS, RectQuad, px, py, sx, sy, zoom)
end

local function drawHighlights()
	if highlight.count == 0 or not next(highlight.items) then
		return
	end
	if #commands == 0 then
		return
	end
	local now = os_clock()
	local pulse = 0.5 + 0.5 * math.sin(now * 4.5)
	for cell = 1, #commands do
		local cmd = commands[cell]
		local rect = cellRects[cell]
		local hl = cmd and highlight.items[cmd.id]
		if hl and rect and rect[4] then
			local color = hl.color or highlight.defaultColor
			local r, g, b = color[1], color[2], color[3]
			local t = now - (hl.startTime or now)
			local localPulse = 0.5 + 0.5 * math.sin(t * 4.5)
			local locOutlineAlpha = 0.45 + 0.5 * localPulse
			local locGlowAlpha = 0.10 + 0.20 * localPulse

			local leftMargin = cellMarginPx
			local rightMargin = cellMarginPx2
			local topMargin = cellMarginPx
			local bottomMargin = cellMarginPx2
			if cell % cols == 1 then
				leftMargin = cellMarginPx2
			end
			if cell % cols == 0 then
				rightMargin = cellMarginPx2
			end
			if cols / cell >= 1 then
				topMargin = math_floor(((cellMarginPx + cellMarginPx2) / 2) + 0.5)
			end

			local x1 = rect[1] + leftMargin
			local y1 = rect[2] + bottomMargin
			local x2 = rect[3] - rightMargin
			local y2 = rect[4] - topMargin

			local cs = math_max(2, math_floor((x2 - x1) * 0.04))
			local thickness = math_max(2, math_floor((x2 - x1) * 0.05))

			glBlending(GL_SRC_ALPHA, GL_ONE)

			-- Feathered inner outline ring
			WG.FlowUI.Draw.RectRoundOutline(
				x1,
				y1,
				x2,
				y2,
				cs,
				thickness,
				1,
				1,
				1,
				1,
				{ r, g, b, locOutlineAlpha },
				{ r, g, b, locOutlineAlpha * 0.85 }
			)

			-- Soft inner glow fading inward
			local glowWidth = thickness * 3
			WG.FlowUI.Draw.RectRoundOutline(
				x1 + thickness,
				y1 + thickness,
				x2 - thickness,
				y2 - thickness,
				math_max(0, cs - thickness),
				glowWidth,
				1,
				1,
				1,
				1,
				{ r, g, b, locGlowAlpha },
				{ r, g, b, 0 }
			)

			glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
		end
	end
end

local function drawStateLights(
	cell,
	leftMargin,
	rightMargin,
	bottomMargin,
	padding,
	cellInnerWidth,
	cellInnerHeight,
	statecount,
	fillMin,
	fillMax,
	desiredState
)
	local padding2 = padding
	local stateWidth = (cellInnerWidth / statecount) - padding2 - padding2
	local stateHeight = math_floor(cellInnerHeight * 0.14)
	local stateMargin = math_floor((stateWidth * 0.075) + 0.5) + padding2 + padding2
	local glowSize = math_floor(stateHeight * 8)
	---@type number, number, number, number
	local r, g, b, a = 0, 0, 0, 0
	for i = 1, statecount do
		if (fillMin and fillMax and i >= fillMin and i <= fillMax) or i == desiredState then
			if i == 1 then
				r, g, b, a = 1, 0.1, 0.1, (i == desiredState and 0.33 or 0.8)
			elseif i == 2 then
				if statecount == 2 then
					r, g, b, a = 0.1, 1, 0.1, (i == desiredState and 0.22 or 0.8)
				else
					r, g, b, a = 1, 1, 0.1, (i == desiredState and 0.22 or 0.8)
				end
			else
				r, g, b, a = 0.1, 1, 0.1, (i == desiredState and 0.26 or 0.8)
			end
		else
			r, g, b, a = 0, 0, 0, 0.36
		end
		glColor(r, g, b, a)
		local x1 = math_floor(
			cellRects[cell][1]
				+ leftMargin
				+ padding
				+ padding2
				+ (stateWidth * (i - 1))
				+ (i == 1 and 0 or stateMargin)
		)
		local y1 = math_floor(cellRects[cell][2] + bottomMargin + padding + padding2)
		local x2 = math_ceil(
			cellRects[cell][3]
				- rightMargin
				- padding
				- padding2
				- (stateWidth * (statecount - i))
				- (i == statecount and 0 or stateMargin)
		)
		local y2 = math_ceil(cellRects[cell][2] + bottomMargin + stateHeight + padding2)
		if rows < 6 then
			RectRound(
				x1,
				y1,
				x2,
				y2,
				stateHeight * 0.33,
				(i == 1 and 0 or 2),
				(i == statecount and 0 or 2),
				(i == statecount and 2 or 0),
				(i == 1 and 2 or 0)
			)
		else
			glRect(x1, y1, x2, y2)
		end
		if rows < 6 and fillMin and fillMax and i >= fillMin and i <= fillMax then
			glBlending(GL_SRC_ALPHA, GL_ONE)
			glColor(r, g, b, 0.09)
			glTexture(barGlowCenterTexture)
			DrawRect(x1, y1 - glowSize, x2, y2 + glowSize, 0.008)
			glTexture(barGlowEdgeTexture)
			DrawRect(x1 - (glowSize * 2), y1 - glowSize, x1, y2 + glowSize, 0.008)
			DrawRect(x2 + (glowSize * 2), y1 - glowSize, x2, y2 + glowSize, 0.008)
			glTexture(false)
			glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
		end
	end
end

drawCell = function(cell, zoom)
	tracy.ZoneBeginN("W:OrderMenu:DrawCell")
	if not zoom then
		zoom = 1
	end

	local cmd = commands[cell]
	if cmd then
		local leftMargin = cellMarginPx
		local rightMargin = cellMarginPx2
		local topMargin = cellMarginPx
		local bottomMargin = cellMarginPx2

		if cell % cols == 1 then
			leftMargin = cellMarginPx2
		end
		if cell % cols == 0 then
			rightMargin = cellMarginPx2
		end
		if cols / cell >= 1 then
			topMargin = math_floor(((cellMarginPx + cellMarginPx2) / 2) + 0.5)
		end

		local cellInnerWidth =
			math_floor(((cellRects[cell][3] - rightMargin) - (cellRects[cell][1] + leftMargin)) + 0.5)
		local cellInnerHeight =
			math_floor(((cellRects[cell][4] - topMargin) - (cellRects[cell][2] + bottomMargin)) + 0.5)

		local padding = math_max(1, math_floor(backgroundPadding * 0.52))

		local isActiveCmd = (activeCommand == cmd.name)
		-- order button background
		---@type rgba, rgba
		local color1, color2 = { 0, 0, 0, 0 }, { 0, 0, 0, 0 }
		if isActiveCmd then
			zoom = cellClickedZoom
			color1 = { 0.66, 0.66, 0.66, math_clamp(uiOpacity, 0.75, 0.95) } -- bottom
			color2 = { 1, 1, 1, math_clamp(uiOpacity, 0.75, 0.95) } -- top
		else
			if WG.guishader then
				color1 = isStateCommand[cmd.id] and { 0.5, 0.5, 0.5, math_clamp(uiOpacity / 1.5, 0.35, 0.55) }
					or { 0.6, 0.6, 0.6, math_clamp(uiOpacity / 1.5, 0.35, 0.55) }
				color1[4] = math_clamp(uiOpacity - 0.3, 0, 0.35)
				color2 = { 1, 1, 1, math_clamp(uiOpacity - 0.3, 0, 0.35) }
			else
				color1 = isStateCommand[cmd.id] and { 0.33, 0.33, 0.33, 1 } or { 0.33, 0.33, 0.33, 1 }
				color1[4] = math_clamp(uiOpacity - 0.4, 0, 0.35)
				color2 = { 1, 1, 1, math_clamp(uiOpacity - 0.4, 0, 0.35) }
			end
			if color1[4] > 0.06 then
				-- white bg (outline)
				RectRound(
					cellRects[cell][1] + leftMargin,
					cellRects[cell][2] + bottomMargin,
					cellRects[cell][3] - rightMargin,
					cellRects[cell][4] - topMargin,
					cellWidth * 0.021,
					2,
					2,
					2,
					2,
					color1,
					color2
				)
				-- darken inside
				color1 = { 0, 0, 0, color1[4] * 2 }
				color2 = { 0, 0, 0, color2[4] * 2 }
				RectRound(
					cellRects[cell][1] + leftMargin + padding,
					cellRects[cell][2] + bottomMargin + padding,
					cellRects[cell][3] - rightMargin - padding,
					cellRects[cell][4] - topMargin - padding,
					cellWidth * 0.019,
					2,
					2,
					2,
					2,
					color1,
					color2
				)
			end
			color1 = { 0, 0, 0, math_clamp(uiOpacity, 0.55, 0.95) } -- bottom
			color2 = { 0, 0, 0, math_clamp(uiOpacity, 0.55, 0.95) } -- top
		end

		tracy.ZoneBeginN("W:OrderMenu:DrawCell:Button")
		UiButton(
			cellRects[cell][1] + leftMargin + padding,
			cellRects[cell][2] + bottomMargin + padding,
			cellRects[cell][3] - rightMargin - padding,
			cellRects[cell][4] - topMargin - padding,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			nil,
			color1,
			color2,
			padding,
			1
		)
		tracy.ZoneEnd()

		-- icon
		if showIcons then
			tracy.ZoneBeginN("W:OrderMenu:DrawCell:Icon")
			if cursorTextures[cmd.cursor] == nil then
				local cursorTexture = "anims/icexuick_200/cursor" .. string.lower(cmd.cursor) .. "_0.png"
				cursorTextures[cmd.cursor] = VFS.FileExists(cursorTexture) and cursorTexture or false
			end
			if cursorTextures[cmd.cursor] then
				local cursorTexture = "anims/icexuick_200/cursor" .. string.lower(cmd.cursor) .. "_0.png"
				if VFS.FileExists(cursorTexture) then
					local s = 0.45
					local halfsize = s
						* ((cellRects[cell][4] - topMargin - padding) - (cellRects[cell][2] + bottomMargin + padding))
					local midPosX = (cellRects[cell][3] - rightMargin - padding)
						- (
							((cellRects[cell][3] - rightMargin - padding) - (cellRects[cell][1] + leftMargin + padding))
							/ 2
						)
					local midPosY = (cellRects[cell][4] - topMargin - padding)
						- (
							((cellRects[cell][4] - topMargin - padding) - (cellRects[cell][2] + bottomMargin + padding))
							/ 2
						)
					glColor(1, 1, 1, 0.66)
					glTexture("" .. cursorTexture)
					glTexRect(midPosX - halfsize, midPosY - halfsize, midPosX + halfsize, midPosY + halfsize)
					glTexture(false)
				end
			end
			tracy.ZoneEnd()
		end

		-- text
		if not showIcons or not cursorTextures[cmd.cursor] then
			tracy.ZoneBeginN("W:OrderMenu:DrawCell:Text")
			-- OPTIMIZATION: Use the cached text instead of recalculating it
			local text = cmd.cachedText or "?"

			-- Cache font metrics per text string to avoid string concat + measurement each draw
			local textWidth = fontWidthCache[text]
			if not textWidth then
				textWidth = font:GetTextWidth("  " .. text .. " ")
				fontWidthCache[text] = textWidth
			end
			local textHeight = fontHeightCache[text]
			if not textHeight then
				textHeight = font:GetTextHeight(text)
				fontHeightCache[text] = textHeight
			end

			local fontSize = cellInnerWidth / textWidth * math_min(1, (cellInnerHeight / (rows * 6)))
			if fontSize > cellInnerWidth / 7 then
				fontSize = cellInnerWidth / 7
			end
			fontSize = fontSize * zoom
			local fontHeightOffset = textHeight * fontSize * (isStateCommand[cmd.id] and 0.22 or 0.34)

			-- Determine text color, using cache for colorized strings
			local textColor
			if isActiveCmd then
				textColor = "\255\020\020\020"
			elseif colorize > 0 and commandInfo[cmd.action] and commandInfo[cmd.action].red then
				if lastColorize ~= colorize then
					for k in pairs(colorStrCache) do
						colorStrCache[k] = nil
					end
					for k in pairs(printTextCache) do
						printTextCache[k] = nil
					end
					lastColorize = colorize
				end
				if not colorStrCache[cmd.action] then
					local info = commandInfo[cmd.action]
					local part = (1 / colorize)
					local grey = (0.93 * (part - 1))
					colorStrCache[cmd.action] = BAR.Utilities.ConvertColor(
						(grey + info.red) / part,
						(grey + info.green) / part,
						(grey + info.blue) / part
					)
				end
				textColor = colorStrCache[cmd.action]
			else
				textColor = "\255\233\233\233"
			end

			-- Cache the full printable string (textColor .. text) to avoid concat per draw
			local printKey = isActiveCmd and ("A_" .. text) or (cmd.action .. "_" .. text)
			local printStr = printTextCache[printKey]
			if not printStr then
				printStr = textColor .. text
				printTextCache[printKey] = printStr
			end
			font:Print(
				printStr,
				cellRects[cell][1] + ((cellRects[cell][3] - cellRects[cell][1]) / 2),
				(cellRects[cell][2] - ((cellRects[cell][2] - cellRects[cell][4]) / 2) - fontHeightOffset),
				fontSize,
				"con"
			)
			tracy.ZoneEnd()
		end

		-- state lights
		if isStateCommand[cmd.id] or cmd.id == CMD.WAIT then
			tracy.ZoneBeginN("W:OrderMenu:DrawCell:StateLights")
			local statecount, curstate
			local fillMin, fillMax
			if cmd.id == CMD.FIRE_STATE then
				statecount = OrderMenuFirestate.PIP_COUNT
				curstate = cmd.virtualIndex or 1
				fillMin, fillMax = OrderMenuFirestate.pipFill(curstate)
			elseif isStateCommand[cmd.id] then
				statecount = #cmd.params - 1
				curstate = (tonumber(cmd.params[1]) or 0) + 1
				fillMin = cmd.pipFillMin or curstate
				fillMax = cmd.pipFillMax or curstate
			else
				statecount = 2
				curstate = cachedWaitState
				fillMin = curstate
				fillMax = curstate
			end
			local desiredState = nil
			if clickedCellDesiredState and cell == clickedCell then
				if cmd.id == CMD.FIRE_STATE then
					desiredState = clickedCellDesiredState
				else
					desiredState = clickedCellDesiredState + 1
				end
			end
			if cmd.id == CMD.FIRE_STATE then
				if curstate == desiredState then
					clickedCellDesiredState = nil
					desiredState = nil
				end
			elseif curstate == desiredState then
				clickedCellDesiredState = nil
				desiredState = nil
			end
			local cache = stateLightDisplayLists[cell]
			if
				cache
				and cache.statecount == statecount
				and cache.fillMin == fillMin
				and cache.fillMax == fillMax
				and cache.desiredState == desiredState
			then
				glCallList(cache.list)
			else
				if cache then
					glDeleteList(cache.list)
				else
					cache = {}
					stateLightDisplayLists[cell] = cache
				end
				cache.statecount = statecount
				cache.fillMin = fillMin
				cache.fillMax = fillMax
				cache.desiredState = desiredState
				cache.list = glCreateList(
					drawStateLights,
					cell,
					leftMargin,
					rightMargin,
					bottomMargin,
					padding,
					cellInnerWidth,
					cellInnerHeight,
					statecount,
					fillMin,
					fillMax,
					desiredState
				)
				glCallList(cache.list)
			end
			tracy.ZoneEnd()
		end
	end
	tracy.ZoneEnd()
end

local function drawOrdersBackground()
	UiElement(
		backgroundRect[1],
		backgroundRect[2],
		backgroundRect[3],
		backgroundRect[4],
		((posX <= 0) and 0 or 1),
		1,
		((posY - height > 0 or posX <= 0) and 1 or 0),
		((posY - height > 0 and posX > 0) and 1 or 0),
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil
	)
end

local function drawOrders()
	tracy.ZoneBeginN("W:OrderMenu:DrawOrders")
	if #commands > 0 then
		glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
		font:Begin(true)
		for cell = 1, #commands do
			drawCell(cell, cellZoom)
		end
		font:End()
	end
	tracy.ZoneEnd()
end

function widget:DrawScreen()
	tracy.ZoneBeginN("W:OrderMenu:DrawScreen")
	if not controllerPanelVisible then
		-- Rendering is hidden, but this widget remains the authoritative live
		-- descriptor/owner model for controller radials and shortcuts.
		local now = os_clock()
		if doUpdate or (doUpdateClock and now >= doUpdateClock) then
			if now - lastCommandRefreshTime >= commandRefreshDelay then
				if doUpdateClock and now >= doUpdateClock then doUpdateClock, doUpdate = nil, true end
				lastCommandRefreshTime = now
				refreshCommands()
				if not commandsVisuallyChanged then doUpdate = nil end
			elseif not doUpdateClock then
				doUpdateClock = now + commandRefreshDelay
			end
		end
		if WG['guishader'] and displayListGuiShader then WG['guishader'].RemoveDlist('ordermenu') end
		tracy.ZoneEnd()
		return
	end
	glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
	local x, y = Spring.GetMouseState()
	local cellHovered
	tracy.ZoneBeginN("W:OrderMenu:DrawScreen:HoverScan")
	if not WG.topbar or not WG.topbar.showingQuit() then
		if math_isInRect(x, y, backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4]) then
			Spring.SetMouseCursor("cursornormal")
			for cell = 1, #cellRects do
				if commands[cell] then
					if
						math_isInRect(
							x,
							y,
							cellRects[cell][1],
							cellRects[cell][2],
							cellRects[cell][3],
							cellRects[cell][4]
						)
					then
						local cmd = commands[cell]
						if WG.tooltip then
							local tooltipKey = cmd.action .. "_tooltip"
							local tooltip = getCachedTranslation("commands." .. tooltipKey)

							if not hotkeyCache[cmd.action] then
								hotkeyCache[cmd.action] =
									keyConfig.sanitizeKey(actionHotkeys[cmd.action], currentLayout)
							end
							local hotkey = hotkeyCache[cmd.action]
							local hotkeyApplied = false

							if cmd.id == CMD.FIRE_STATE then
								local commandState = OrderMenuFirestate.stateLabel(cmd)
								local modeDescrKey = commandState and OrderMenuFirestate.descrByState[commandState]
								if modeDescrKey then
									local modeDescr = getCachedTranslation("commands." .. modeDescrKey)
									local generalDescr = tooltip
									if generalDescr ~= "" and hotkey ~= "" then
										generalDescr = getCachedTranslation("ui.orderMenu.hotkeyTooltip", {
											hotkey = hotkey:upper(),
											tooltip = generalDescr,
											highlightColor = "\255\255\215\100",
											textColor = "\255\240\240\240",
										})
										hotkeyApplied = true
									end
									if modeDescr ~= "" and generalDescr ~= "" then
										tooltip = modeDescr .. "\n" .. generalDescr
									elseif modeDescr ~= "" then
										tooltip = modeDescr
									elseif generalDescr ~= "" then
										tooltip = generalDescr
									end
								end
							end

							if tooltip ~= "" and hotkey ~= "" and not hotkeyApplied then
								tooltip = getCachedTranslation("ui.orderMenu.hotkeyTooltip", {
									hotkey = hotkey:upper(),
									tooltip = tooltip,
									highlightColor = "\255\255\215\100",
									textColor = "\255\240\240\240",
								})
							end
							if tooltip ~= "" then
								local title
								if isStateCommand[cmd.id] then
									local commandState = (cmd.id == CMD.FIRE_STATE)
											and OrderMenuFirestate.stateLabel(cmd)
										or CustomFirestateDefs.stateLabel(cmd)
									if commandState then
										title = getCachedTranslation("commands." .. commandState)
									end
								else
									title = getCachedTranslation("commands." .. cmd.action)
								end
								WG.tooltip.ShowTooltip("ordermenu", tooltip, nil, nil, title)
							end
						end
						cellHovered = cell
						if ControllerOrderMenuHybridState.radialOpen and ControllerOrderMenuHybridState.focusCmdID ~= cmd.id
								and WG['ordermenu'] and type(WG['ordermenu'].controllerSetFocus) == 'function' then
							WG['ordermenu'].controllerSetFocus(cmd.id, "vanilla-mouse")
						end
					end
				else
					break
				end
			end
		end
	end
	tracy.ZoneEnd()

	-- make all cmd's fit in the grid
	local now = os_clock()
	if clickedCellDesiredState and not doUpdateClock then -- make sure state changes get updated
		doUpdateClock = now + 0.1
	end

	-- Throttle command refresh to avoid excessive updates during rapid selection changes
	if doUpdate or (doUpdateClock and now >= doUpdateClock) then
		tracy.ZoneBeginN("W:OrderMenu:DrawScreen:RefreshCommands")
		-- Only refresh if enough time has passed since last refresh
		if now - lastCommandRefreshTime >= commandRefreshDelay then
			if doUpdateClock and now >= doUpdateClock then
				doUpdateClock = nil
				doUpdate = true
			end
			lastCommandRefreshTime = now
			refreshCommands()
			-- Skip R2T rebuild if commands haven't visually changed
			if not commandsVisuallyChanged then
				doUpdate = nil
			end
		else
			-- Defer the update slightly
			if not doUpdateClock then
				doUpdateClock = now + commandRefreshDelay
			end
		end
		tracy.ZoneEnd()
	end

	if #commands == 0 and (not alwaysShow or spGetGameFrame() == 0) then -- dont show pregame because factions interface is shown
		tracy.ZoneBeginN("W:OrderMenu:DrawScreen:Hide")
		if displayListGuiShader and WG.guishader then
			WG.guishader.RemoveDlist("ordermenu")
		end
		doUpdate = nil
		tracy.ZoneEnd()
	else
		tracy.ZoneBeginN("W:OrderMenu:DrawScreen:Visible")
		if displayListGuiShader and WG.guishader then
			WG.guishader.InsertDlist(displayListGuiShader, "ordermenu")
		end
		if doUpdate and displayListOrders then
			displayListOrders = gl.DeleteList(displayListOrders)
		end

		if not ordermenuBgTex then
			tracy.ZoneBeginN("W:OrderMenu:DrawScreen:CreateBackgroundTexture")
			ordermenuBgTex = gl.CreateTexture(math_floor(width * vsx), math_floor(height * vsy), {
				target = GL.TEXTURE_2D,
				format = GL.ALPHA,
				fbo = true,
			})
			if ordermenuBgTex then
				gl.R2tHelper.RenderInRect(
					ordermenuBgTex,
					backgroundRect[1],
					backgroundRect[2],
					backgroundRect[3],
					backgroundRect[4],
					drawOrdersBackground,
					true
				)
			end
			tracy.ZoneEnd()
		end
		if not ordermenuTex then
			tracy.ZoneBeginN("W:OrderMenu:DrawScreen:CreateOrdersTexture")
			ordermenuTex = gl.CreateTexture(
				math_floor(width * vsx) * (vsy < 1400 and 2 or 1),
				math_floor(height * vsy) * (vsy < 1400 and 2 or 1),
				{ --*(vsy<1400 and 2 or 1)
					target = GL.TEXTURE_2D,
					format = GL.ALPHA,
					fbo = true,
				}
			)
			tracy.ZoneEnd()
		end
		if ordermenuTex and doUpdate then
			tracy.ZoneBeginN("W:OrderMenu:DrawScreen:RenderOrdersTexture")
			gl.R2tHelper.RenderInRect(
				ordermenuTex,
				backgroundRect[1],
				backgroundRect[2],
				backgroundRect[3],
				backgroundRect[4],
				drawOrders,
				true
			)
			doUpdate = nil
			tracy.ZoneEnd()
		end

		tracy.ZoneBeginN("W:OrderMenu:DrawScreen:BlendTextures")
		if ordermenuBgTex then
			-- background element
			gl.R2tHelper.BlendTexRect(
				ordermenuBgTex,
				backgroundRect[1],
				backgroundRect[2],
				backgroundRect[3],
				backgroundRect[4],
				true
			)
		end
		if ordermenuTex then
			-- content
			gl.R2tHelper.BlendTexRect(
				ordermenuTex,
				backgroundRect[1],
				backgroundRect[2],
				backgroundRect[3],
				backgroundRect[4],
				true
			)
		end
		tracy.ZoneEnd()

		if #commands > 0 then
			-- draw attention highlights (animated, on top of cached content)
			tracy.ZoneBeginN("W:OrderMenu:DrawScreen:Highlights")
			drawHighlights()
			tracy.ZoneEnd()

			-- draw highlight on top of button
			if not WG.topbar or not WG.topbar.showingQuit() then
				if commands and cellHovered then
					tracy.ZoneBeginN("W:OrderMenu:DrawScreen:HoverCell")
					local cell = cellHovered
					if cellRects[cell] and cellRects[cell][4] then
						drawCell(cell, cellHoverZoom)

						local colorMult = 1
						if commands[cell] and activeCommand == commands[cell].name then
							colorMult = 0.4
						end

						local leftMargin = cellMarginPx
						local rightMargin = cellMarginPx2
						local topMargin = cellMarginPx
						local bottomMargin = cellMarginPx2

						if cell % cols == 1 then
							leftMargin = cellMarginPx2
						end
						if cell % cols == 0 then
							rightMargin = cellMarginPx2
						end
						if cols / cell >= 1 then
							topMargin = math_floor(((cellMarginPx + cellMarginPx2) / 2) + 0.5)
						end

						-- gloss highlight
						local pad = math_max(1, math_floor(backgroundPadding * 0.52))
						local pad2 = pad
						glBlending(GL_SRC_ALPHA, GL_ONE)
						RectRound(
							cellRects[cell][1] + leftMargin + pad + pad2,
							cellRects[cell][4]
								- topMargin
								- backgroundPadding
								- pad
								- pad2
								- ((cellRects[cell][4] - cellRects[cell][2]) * 0.42),
							cellRects[cell][3] - rightMargin - pad - pad2,
							(cellRects[cell][4] - topMargin - pad - pad2),
							cellMargin * 0.025,
							2,
							2,
							0,
							0,
							{ 1, 1, 1, 0.035 * colorMult },
							{ 1, 1, 1, (disableInput and 0.14 * colorMult or 0.28 * colorMult) }
						)
						RectRound(
							cellRects[cell][1] + leftMargin + pad + pad2,
							cellRects[cell][2] + bottomMargin + pad + pad2,
							cellRects[cell][3] - rightMargin - pad - pad2,
							(cellRects[cell][2] - bottomMargin - pad - pad2)
								+ ((cellRects[cell][4] - cellRects[cell][2]) * 0.5),
							cellMargin * 0.025,
							0,
							0,
							2,
							2,
							{ 1, 1, 1, (disableInput and 0.045 * colorMult or 0.095 * colorMult) },
							{ 1, 1, 1, 0 }
						)
						glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
					end
					tracy.ZoneEnd()
				end
			end

			-- clicked cell effect
			local cell = clickedCell
			local clickedCommand = cell and commands[cell]
			if clickedCellTime and cell and clickedCommand then
				tracy.ZoneBeginN("W:OrderMenu:DrawScreen:ClickedCell")
				if cellRects[cell] and cellRects[cell][4] then
					local isActiveCmd = (clickedCommand.name == activeCommand)
					local duration = 0.33
					if isActiveCmd then
						duration = 0.45
					elseif isStateCommand[clickedCommand.id] then
						duration = 0.6
					end
					local alpha = 0.33 - ((now - clickedCellTime) / duration)
					if alpha > 0 then
						if isActiveCmd then
							glColor(0, 0, 0, alpha)
						else
							glBlending(GL_SRC_ALPHA, GL_ONE)
							glColor(1, 1, 1, alpha)
						end

						local leftMargin = cellMarginPx
						local rightMargin = cellMarginPx2
						local topMargin = cellMarginPx
						local bottomMargin = cellMarginPx2

						if cell % cols == 1 then
							leftMargin = cellMarginPx2
						end
						if cell % cols == 0 then
							rightMargin = cellMarginPx2
						end
						if cols / cell >= 1 then
							topMargin = math_floor(((cellMarginPx + cellMarginPx2) / 2) + 0.5)
						end
						-- gloss highlight
						local pad = math_max(1, math_floor(backgroundPadding * 0.52))
						RectRound(
							cellRects[cell][1] + leftMargin + pad,
							cellRects[cell][2] + bottomMargin + pad,
							cellRects[cell][3] - rightMargin - pad,
							cellRects[cell][4] - topMargin - pad,
							cellWidth * 0.019,
							2,
							2,
							2,
							2
						)
					else
						clickedCellTime = nil
					end
					glBlending(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
				end
				tracy.ZoneEnd()
			end
		end
		tracy.ZoneEnd()
	end
	tracy.ZoneEnd()
end

function widget:MousePress(x, y, button)
	if not controllerPanelVisible then return false end
	if Spring.IsGUIHidden() then
		return false
	end
	if
		ordermenuShows
		and math_isInRect(x, y, backgroundRect[1], backgroundRect[2], backgroundRect[3], backgroundRect[4])
	then
		if #commands > 0 then
			if not disableInput then
				for cell = 1, #cellRects do
					local cmd = commands[cell]
					if cmd then
						if
							math_isInRect(
								x,
								y,
								cellRects[cell][1],
								cellRects[cell][2],
								cellRects[cell][3],
								cellRects[cell][4]
							)
						then
							clickCountDown = 2
							clickedCell = cell
							clickedCellTime = os_clock()

							if cmd.id == CMD.FIRE_STATE then
								local virtualIndex = cmd.virtualIndex or 1
								clickedCellDesiredState =
									OrderMenuFirestate.nextCycledVirtualIndex(virtualIndex, button ~= 1)
								doUpdate = true
							elseif isStateCommand[cmd.id] then
								local currentStateIndex = tonumber(cmd.params[1]) or 0
								if button == 1 then
									clickedCellDesiredState = currentStateIndex + 1
									if clickedCellDesiredState >= #cmd.params - 1 then
										clickedCellDesiredState = 0
									end
								else
									clickedCellDesiredState = currentStateIndex - 1
									if clickedCellDesiredState < 0 then
										clickedCellDesiredState = #cmd.params - 2
									end
								end
								doUpdate = true
							end

							if playSounds then
								Spring.PlaySoundFile(soundButton, 0.6, "ui")
							end
							if cmd.id == CMD.FIRE_STATE and clickedCellDesiredState ~= nil then
								OrderMenuFirestate.giveVirtualIndex(clickedCellDesiredState, 0)
							elseif cmd.id and Spring.GetCmdDescIndex(cmd.id) then
								Spring.SetActiveCommand(
									Spring.GetCmdDescIndex(cmd.id),
									button,
									true,
									false,
									Spring.GetModKeyState()
								)
							end
							break
						end
					else
						break
					end
				end
			end
			return true
		elseif alwaysShow and spGetGameFrame() > 0 then
			return true
		end
	end
	return false
end

function widget:CommandNotify(cmdID, cmdParams, cmdOptions)
	return OrderMenuFirestate.commandNotify(cmdID, cmdParams, cmdOptions)
end

function widget:UnitCommand(unitID, unitDefID, unitTeam, cmdID, cmdOpts, cmdParams, cmdTag)
	if isStateCommand[cmdID] or cmdID == CMD.WAIT then
		if not hiddenCommands[cmdID] and doUpdateClock == nil then
			doUpdateClock = os_clock() + 0.01
		end
	end
end

function widget:CommandsChanged() -- required to read changes from EditUnitCmdDesc
	-- Respect selection-based throttle instead of always using 10ms
	if not doUpdateClock then
		doUpdateClock = os_clock() + commandRefreshDelay
	end
end

function widget:SelectionChanged(sel)
	clickCountDown = 2
	clickedCellDesiredState = nil

	-- Cache first selected unit to avoid spGetSelectedUnits() table allocation later
	cachedFirstUnit = sel[1] or nil

	-- Update cancel target state using the selection already provided here
	cancelTargetLastState = selectionHasPriorityTarget(sel)

	-- Adaptive throttling: increase delay based on selection size
	local selCount = #sel
	local throttleDelay = 0.01
	if selCount >= 800 then
		throttleDelay = 0.08
	elseif selCount >= 500 then
		throttleDelay = 0.05
	elseif selCount >= 300 then
		throttleDelay = 0.035
	elseif selCount >= 160 then
		throttleDelay = 0.025
	elseif selCount >= 80 then
		throttleDelay = 0.015
	end

	-- Throttle updates during rapid selection changes
	local now = os_clock()
	if not doUpdateClock or (now - lastCommandRefreshTime) > throttleDelay then
		doUpdateClock = now + throttleDelay
	end
end

-- Generic owner preview.  Registered command widgets draw their own native
-- preview; this is used only when no more-specific owner registered the cmdID.
function widget:DrawWorld()
	if controllerActiveTargetAPI ~= controllerTargetOwner or not controllerTargetOwner then return end
	local state = controllerTargetOwner:GetState()
	if not state.anchor or not state.current
			or not state.anchor.x or not state.anchor.y or not state.anchor.z then return end
	gl.DepthTest(false)
	gl.LineWidth(2.4)
	gl.Color(0.30, 0.80, 1.0, 0.90)
	if state.shape == "area" then
		gl.DrawGroundCircle(state.anchor.x, state.anchor.y, state.anchor.z, math.max(1, state.radius or 0), 64)
	else
		gl.BeginEnd(GL.LINES, function()
			gl.Vertex(state.anchor.x, state.anchor.y + 2, state.anchor.z)
			gl.Vertex(state.current.x, state.current.y + 2, state.current.z)
			if state.shape == "rectangle" then
				gl.Vertex(state.anchor.x, state.anchor.y + 2, state.current.z)
				gl.Vertex(state.current.x, state.current.y + 2, state.current.z)
				gl.Vertex(state.current.x, state.current.y + 2, state.anchor.z)
				gl.Vertex(state.anchor.x, state.anchor.y + 2, state.anchor.z)
			end
		end)
	end
	gl.LineWidth(1)
	gl.Color(1, 1, 1, 1)
	gl.DepthTest(false)
end

function widget:LanguageChanged()
	commandTextCache = {}
	translationCache = {}
	widget:ViewResize()
end

function widget:GetConfigData()
	return {
		version = 1,
		colorize = colorize,
		stickToBottom = stickToBottom,
		alwaysShow = alwaysShow,
		disabledCmd = disabledCommand,
	}
end

function widget:SetConfigData(data)
	if data.version then
		if data.stickToBottom ~= nil then
			stickToBottom = data.stickToBottom
		end
	end
	if data.colorize ~= nil then
		colorize = data.colorize
	end
	if data.alwaysShow ~= nil then
		alwaysShow = data.alwaysShow
	end
	if data.disabledCmd ~= nil then
		disabledCommand = data.disabledCmd
	end
end
