-- Controller native radial adapter (v0.8 experimental).
--
-- This module is intentionally free of Spring/WG calls.  Patched BAR widgets
-- own authoritative descriptors and activation; this adapter only gives those
-- descriptors stable identities, categories, pages and radial slots.

local Adapter = {}
Adapter.__index = Adapter

Adapter.SLOT_COUNT = 8
Adapter.BUILDER_CATEGORY_ORDER = {
	"Economy", "Build", "Utility", "Combat",
}
Adapter.FACTORY_CATEGORY_ORDER = { "Constructors", "Utility", "Combat" }
Adapter.TACTICAL_CATEGORY_ORDER = { "utility", "tactical" }

local function shallowCopy(source)
	local result = {}
	for key, value in pairs(type(source) == "table" and source or {}) do
		result[key] = value
	end
	return result
end

local function normalizedText(value)
	return string.lower(tostring(value or ""))
end

local function stableBuildKey(item)
	if type(item) ~= "table" then return nil end
	if item.stableKey then return tostring(item.stableKey) end
	local unitDefID = tonumber(item.unitDefID)
	if unitDefID then return "build:" .. tostring(unitDefID) end
	local cmdID = tonumber(item.cmdID or item.id)
	if cmdID then return "buildcmd:" .. tostring(cmdID) end
	return nil
end

local function stableCommandKey(item)
	if type(item) ~= "table" then return nil end
	if item.stableKey then return tostring(item.stableKey) end
	local cmdID = tonumber(item.cmdID or item.id)
	if cmdID then return "cmd:" .. tostring(cmdID) end
	return nil
end

local function stateLabels(params)
	local labels = {}
	if type(params) == "table" then
		for index = 2, #params do
			local label = params[index]
			if label ~= nil and tostring(label) ~= "" then
				labels[#labels + 1] = tostring(label)
			end
		end
	end
	return labels
end

local function tacticalCategory(item)
	if item.tacticalCategory == "utility" or item.tacticalCategory == "tactical" then
		return item.tacticalCategory
	end
	local text = normalizedText(item.name) .. " " .. normalizedText(item.action)
		.. " " .. normalizedText(item.tooltip)
	if item.isState
		or text:find("cloak", 1, true)
		or text:find("visible", 1, true)
		or text:find("fire state", 1, true)
		or text:find("firestate", 1, true)
		or text:find("move state", 1, true)
		or text:find("movestate", 1, true)
		or text:find("repeat", 1, true)
		or text:find("on/off", 1, true)
		or text:find("onoff", 1, true)
		or text:find("priority", 1, true)
		or text:find("wait", 1, true)
		or text:find("stop", 1, true)
		or text:find("clear queue", 1, true)
		or text:find("self destruct", 1, true)
		or text:find("self-destruct", 1, true)
	then
		return "utility"
	end
	return "tactical"
end

local function tacticalKind(item)
	local action = normalizedText(item.action)
	local text = normalizedText(item.name) .. " " .. action
	if text:find("self destruct", 1, true) or text:find("self-destruct", 1, true)
			or action == "selfd" or action == "selfdestruct" then return "self_destruct" end
	if text:find("reclaim", 1, true) then return "reclaim" end
	if text:find("repair", 1, true) then return "repair" end
	if text:find("guard", 1, true) then return "alliedUnit" end
	if text:find("attack", 1, true) or text:find("manual fire", 1, true)
		or action == "settarget" then return "attack" end
	if text:find("move", 1, true) or text:find("fight", 1, true)
		or text:find("patrol", 1, true) or text:find("restore", 1, true)
		or text:find("capture", 1, true) then return "ground" end
	return "none"
end

local function tacticalAreaMode(item)
	local action = normalizedText(item.action)
	local text = normalizedText(item.name) .. " " .. action .. " " .. normalizedText(item.tooltip)
	local types = rawget(_G, "CMDTYPE") or {}
	local typeID = tonumber(item.type)
	local isArea = typeID == tonumber(types.ICON_AREA)
		or typeID == tonumber(types.ICON_UNIT_OR_AREA)
		or typeID == tonumber(types.ICON_UNIT_FEATURE_OR_AREA)
		or typeID == tonumber(types.ICON_UNIT_OR_RECTANGLE)
	if not isArea and not text:find("area", 1, true) and not text:find("radius", 1, true) then return nil end
	if action == "areamex" or text:find("area mex", 1, true) then return "areaMex" end
	if text:find("reclaim", 1, true) then return "reclaimArea" end
	if text:find("repair", 1, true) then return "repairArea" end
	if text:find("resurrect", 1, true) or action == "rez" then return "resurrectArea" end
	if text:find("restore", 1, true) then return "restoreArea" end
	if text:find("capture", 1, true) then return "captureArea" end
	if text:find("guard", 1, true) then return "guardArea" end
	if text:find("unload", 1, true) then return "unloadArea" end
	if text:find("load", 1, true) then return "loadArea" end
	if text:find("attack", 1, true) then return "attackArea" end
	return isArea and "genericArea" or nil
end

function Adapter.New()
	return setmetatable({}, Adapter)
end

function Adapter.StableBuildKey(item)
	return stableBuildKey(item)
end

function Adapter.StableCommandKey(item)
	return stableCommandKey(item)
end

local function orderedCategories(factory)
	return factory and Adapter.FACTORY_CATEGORY_ORDER or Adapter.BUILDER_CATEGORY_ORDER
end

local function pagePenalty(flat, first, last, targetSize)
	local length = last - first + 1
	local runs, previous = {}, nil
	for index = first, last do
		local item = flat[index]
		if not item then return 1000000000 end
		local category = item.category
		if category ~= previous then
			runs[#runs + 1] = { category = category, count = 1 }
			previous = category
		else
			runs[#runs].count = runs[#runs].count + 1
		end
	end
	local penalty = (length - targetSize) * (length - targetSize) * 10
	if #runs > 1 then
		for _, run in ipairs(runs) do
			if run.count == 1 then penalty = penalty + 10000 end
		end
	end
	if first > 1 and flat[first - 1].category == flat[first].category then penalty = penalty + 2 end
	if last < #flat and flat[last + 1].category == flat[last].category then penalty = penalty + 2 end
	return penalty
end

-- Deterministic minimal-page ordered packing. Dynamic programming selects page
-- breaks without reordering items; its dominant penalty removes avoidable
-- one-slot category wedges, then balances pages and category splits.
function Adapter.PackCategories(flat, slotCount)
	slotCount = tonumber(slotCount) or Adapter.SLOT_COUNT
	local total = #(type(flat) == "table" and flat or {})
	if total == 0 then return {} end
	local pageCount = math.ceil(total / slotCount)
	local targetSize = total / pageCount
	local dp, previous = { [0] = { [0] = 0 } }, {}
	for page = 1, pageCount do
		dp[page], previous[page] = {}, {}
		for last = page, math.min(total, page * slotCount) do
			local bestCost, bestFirst
			for length = 1, slotCount do
				local first = last - length + 1
				local prior = first - 1
				local priorCost = first >= 1 and dp[page - 1] and dp[page - 1][prior]
				if type(priorCost) == "number" then
					local remaining = total - last
					if remaining >= (pageCount - page) and remaining <= (pageCount - page) * slotCount then
						local cost = priorCost + pagePenalty(flat, first, last, targetSize)
						if bestCost == nil or cost < bestCost or (cost == bestCost and first < bestFirst) then
							bestCost, bestFirst = cost, first
						end
					end
				end
			end
			if bestFirst then dp[page][last], previous[page][last] = bestCost, bestFirst end
		end
	end
	local ranges, last = {}, total
	for page = pageCount, 1, -1 do
		local first = previous[page][last]
		ranges[page] = { first = first, last = last }
		last = first - 1
	end
	local pages = {}
	for page, range in ipairs(ranges) do
		local entries, sectors, sector
		entries, sectors = {}, {}
		for index = range.first, range.last do
			local item = flat[index]
			local slot = index - range.first + 1
			entries[#entries + 1] = item
			if not sector or sector.category ~= item.category then
				sector = { category = item.category, firstSlot = slot, lastSlot = slot, count = 1 }
				sectors[#sectors + 1] = sector
			else
				sector.lastSlot, sector.count = slot, sector.count + 1
			end
		end
		pages[page] = { index = page, entries = entries, sectors = sectors, itemCount = #entries }
	end
	return pages
end

function Adapter:BuildBuildModel(sourceItems, context)
	context = context or {}
	local factory = context.isFactory == true
	local grouped, categoriesSeen = {}, {}
	local classifier = type(context.classify) == "function" and context.classify or nil

	for sourceIndex, source in ipairs(type(sourceItems) == "table" and sourceItems or {}) do
		local key = stableBuildKey(source)
		if key then
			local item = shallowCopy(source)
			local category = item.category
			if classifier then category = classifier(item, factory) end
			category = tostring(category or (factory and "Utility" or "Utility"))
			local vanillaPosition = tonumber(item.vanillaIndex or item.cell or item.index) or sourceIndex

			item.stableKey = key
			item.category = category
			item.vanillaIndex = vanillaPosition
			item.cmdID = tonumber(item.cmdID or item.id)
			item.unitDefID = tonumber(item.unitDefID) or (item.cmdID and item.cmdID < 0 and -item.cmdID or nil)
			item.name = item.name or item.label or (item.unitDefID and tostring(item.unitDefID)) or "Build"
			item.shortLabel = item.shortLabel or item.name
			item.iconTexture = item.iconTexture or (item.unitDefID and ("#" .. tostring(item.unitDefID)) or nil)
			item.disabled = item.disabled == true
			item.queueCount = tonumber(item.queueCount) or 0
			grouped[category] = grouped[category] or {}
			grouped[category][#grouped[category] + 1] = item
			categoriesSeen[category] = true
		end
	end

	local categories = {}
	for _, category in ipairs(orderedCategories(factory)) do
		if categoriesSeen[category] then categories[#categories + 1] = category end
	end

	-- The controller wheel is a compact projection of BAR's authoritative list,
	-- not a second grid.  Preserve the source order inside every category while
	-- packing only entries that actually exist into consecutive wheel slots.
	local result, categoryCounts = {}, {}
	for _, category in ipairs(categories) do
		local categoryItems = grouped[category] or {}
		categoryCounts[category] = #categoryItems
		for position, item in ipairs(categoryItems) do
			item.canonicalPosition = position
			result[#result + 1] = item
		end
	end
	local pages = Adapter.PackCategories(result, Adapter.SLOT_COUNT)
	for pageIndex, page in ipairs(pages) do
		for slot, item in ipairs(page.entries) do
			item.radialPage, item.globalPage, item.radialSlot = pageIndex, pageIndex, slot
			item.slotException = false
		end
	end

	local selectedKey = context.previousStableKey
	local selectedIndex
	for index, item in ipairs(result) do
		if item.stableKey == selectedKey then selectedIndex = index; break end
	end
	if not selectedIndex and #result > 0 then selectedIndex, selectedKey = 1, result[1].stableKey end

	return {
		kind = factory and "factory" or "builder",
		items = result,
		categories = categories,
		selectedIndex = selectedIndex or 1,
		selectedStableKey = selectedKey,
		slotCount = Adapter.SLOT_COUNT,
		itemCount = #result,
		categoryCounts = categoryCounts,
		pageCount = #pages,
		pages = pages,
		revision = tonumber(context.revision) or 0,
	}
end

function Adapter:BuildTacticalModel(sourceCommands, context)
	context = context or {}
	local items, byCategory = {}, { utility = {}, tactical = {} }
	for sourceIndex, source in ipairs(type(sourceCommands) == "table" and sourceCommands or {}) do
		local key = stableCommandKey(source)
		if key then
			local item = shallowCopy(source)
			item.stableKey = key
			item.cmdID = tonumber(item.cmdID or item.id)
			item.name = item.name or item.label or item.action or "Command"
			item.shortLabel = item.shortLabel or item.name
			item.tooltip = item.tooltip or ""
			item.disabled = item.disabled == true
			item.isState = item.isState == true
			item.states = stateLabels(item.params)
			item.currentStateIndex = tonumber(item.currentStateIndex)
				or tonumber(type(item.params) == "table" and item.params[1]) or 0
			item.currentStateLabel = item.states[item.currentStateIndex + 1]
			item.isBinaryState = item.isState and #item.states == 2
			item.dragMode = item.dragMode or tacticalAreaMode(item)
			item.kind = item.kind or (item.dragMode and "drag_area") or tacticalKind(item)
			item.tacticalCategory = tacticalCategory(item)
			item.vanillaIndex = tonumber(item.vanillaIndex or item.cell or item.index) or sourceIndex
			items[#items + 1] = item
			byCategory[item.tacticalCategory][#byCategory[item.tacticalCategory] + 1] = item
		end
	end

	local selectedKey = context.previousStableKey
	local category = context.previousCategory
	if category ~= "utility" and category ~= "tactical" then category = "tactical" end
	local selectedIndex
	for index, item in ipairs(byCategory[category]) do
		if item.stableKey == selectedKey then selectedIndex = index; break end
	end
	if not selectedIndex and #byCategory[category] > 0 then
		selectedIndex, selectedKey = 1, byCategory[category][1].stableKey
	end
	if #byCategory[category] == 0 then
		category = category == "utility" and "tactical" or "utility"
		selectedIndex = #byCategory[category] > 0 and 1 or nil
		selectedKey = selectedIndex and byCategory[category][1].stableKey or nil
	end

	return {
		kind = "tactical",
		items = items,
		byCategory = byCategory,
		category = category,
		selectedIndex = selectedIndex or 1,
		selectedStableKey = selectedKey,
		revision = tonumber(context.revision) or 0,
	}
end

function Adapter.FindByStableKey(model, stableKey)
	if not stableKey then return nil end
	for index, item in ipairs(type(model) == "table" and model.items or {}) do
		if item.stableKey == stableKey then return item, index end
	end
	return nil
end

function Adapter.FindTactical(model, stableKey)
	local item = Adapter.FindByStableKey(model, stableKey)
	if not item then return nil end
	local category = item.tacticalCategory
	for index, candidate in ipairs(model.byCategory and model.byCategory[category] or {}) do
		if candidate.stableKey == stableKey then return candidate, index, category end
	end
	return nil
end

return Adapter
