--------------------------------------------------------------------------------
-- Controller UI authoring workspace
-- Pure layout/input state plus an immediate-mode BAR renderer.
--------------------------------------------------------------------------------

local Workspace = {}

local max, min, floor = math.max, math.min, math.floor

local function clamp(value, low, high)
	value = tonumber(value) or low
	return max(low, min(high, value))
end

local function inside(bounds, x, y)
	return bounds and x >= bounds.x1 and x <= bounds.x2 and y >= bounds.y1 and y <= bounds.y2
end

local function copyBounds(bounds)
	return { x1 = bounds.x1, y1 = bounds.y1, x2 = bounds.x2, y2 = bounds.y2,
		width = bounds.x2 - bounds.x1, height = bounds.y2 - bounds.y1 }
end

local function paneState()
	return { scroll = 0, content = 0, viewport = 0, maxScroll = 0, track = nil, thumb = nil }
end

function Workspace.New()
	return {
		panes = { nav = paneState(), inspector = paneState(), preview = paneState(), modal = paneState() },
		inspectorScroll = {}, collapsed = {}, navGroups = {}, componentSearch = "",
		focusId = nil, focusItems = {}, focusIndex = 0, hits = {}, modal = nil,
		dragScrollbar = nil, hovered = nil, previewZoom = 1, previewFit = true,
		showHelp = false, navCollapsed = false, forcedNavCollapsed = false,
		previewCollapsed = false, autoCollapseUnavailable = true, navWidth = 190, previewWidth = 360,
		showSafeMargins = false, showSelectionBounds = true, debugVisible = false,
		dividerDrag = nil, lastDividerClick = {},
	}
end

function Workspace.ExportChrome(state)
	return {
		navWidth = state.navWidth, previewWidth = state.previewWidth,
		navCollapsed = state.navCollapsed == true, previewCollapsed = state.previewCollapsed == true,
		autoCollapseUnavailable = state.autoCollapseUnavailable ~= false,
		previewZoom = state.previewZoom, previewFit = state.previewFit ~= false,
		showSafeMargins = state.showSafeMargins == true, showSelectionBounds = state.showSelectionBounds ~= false,
	}
end

function Workspace.ImportChrome(state, chrome)
	if type(chrome) ~= "table" then return false end
	state.navWidth = clamp(chrome.navWidth or state.navWidth, 120, 420)
	state.previewWidth = clamp(chrome.previewWidth or state.previewWidth, 180, 900)
	state.navCollapsed = chrome.navCollapsed == true
	state.previewCollapsed = chrome.previewCollapsed == true
	state.autoCollapseUnavailable = chrome.autoCollapseUnavailable ~= false
	state.previewZoom = clamp(chrome.previewZoom or state.previewZoom, 0.5, 2)
	state.previewFit = chrome.previewFit ~= false
	state.showSafeMargins = chrome.showSafeMargins == true
	state.showSelectionBounds = chrome.showSelectionBounds ~= false
	return true
end

function Workspace.ResetSession(state)
	state.debugVisible = false
	state.modal, state.showHelp, state.dividerDrag, state.dragScrollbar = nil, false, nil, nil
	state.focusId, state.focusIndex = nil, 0
end

function Workspace.SetBounds(state, bounds, spec)
	state.bounds = copyBounds(bounds)
	spec = spec or {}
	local width, bodyGap = state.bounds.width, 6
	local headerH, toolbarH, footerH = 48, 40, 42
	local body = { x1 = bounds.x1 + 8, y1 = bounds.y1 + footerH, x2 = bounds.x2 - 8,
		y2 = bounds.y2 - headerH - toolbarH }
	local compact = width < 800
	local forcedCollapse = width < 735
	state.forcedNavCollapsed = forcedCollapse
	local collapsed = forcedCollapse or state.navCollapsed
	local navW = collapsed and 48 or clamp(state.navWidth or width * 0.22, 164, min(280, width * 0.32))
	local previewAvailable = spec.previewAvailable ~= false
	local autoCollapsed = not previewAvailable and state.autoCollapseUnavailable ~= false
	local previewCollapsed = compact or state.previewCollapsed or autoCollapsed
	local bodyWidth = body.x2 - body.x1
	local inspectorMin = min(330, max(250, bodyWidth - navW - bodyGap))
	local previewW = 0
	if not previewCollapsed then
		local maximum = max(220, bodyWidth - navW - inspectorMin - bodyGap * 2)
		previewW = clamp(state.previewWidth or width * 0.34, 220, maximum)
	end
	local inspectorW = bodyWidth - navW - bodyGap - (previewW > 0 and previewW + bodyGap or 0)
	state.layout = {
		header = { x1 = bounds.x1, y1 = bounds.y2 - headerH, x2 = bounds.x2, y2 = bounds.y2 },
		toolbar = { x1 = bounds.x1 + 8, y1 = bounds.y2 - headerH - toolbarH, x2 = bounds.x2 - 8, y2 = bounds.y2 - headerH },
		footer = { x1 = bounds.x1 + 8, y1 = bounds.y1 + 5, x2 = bounds.x2 - 8, y2 = bounds.y1 + footerH - 4 },
		nav = { x1 = body.x1, y1 = body.y1, x2 = body.x1 + navW, y2 = body.y2 },
		inspector = { x1 = body.x2 - inspectorW, y1 = body.y1, x2 = body.x2, y2 = body.y2 },
		compact = compact, navCollapsed = collapsed, previewCollapsed = previewCollapsed,
		previewAvailable = previewAvailable, previewAutoCollapsed = autoCollapsed,
	}
	if previewW > 0 then
		state.layout.preview = { x1 = state.layout.nav.x2 + bodyGap, y1 = body.y1,
			x2 = state.layout.nav.x2 + bodyGap + previewW, y2 = body.y2 }
		state.layout.inspector.x1 = state.layout.preview.x2 + bodyGap
		state.layout.dividerNav = { x1 = state.layout.nav.x2, y1 = body.y1, x2 = state.layout.nav.x2 + bodyGap, y2 = body.y2 }
		state.layout.dividerInspector = { x1 = state.layout.preview.x2, y1 = body.y1, x2 = state.layout.preview.x2 + bodyGap, y2 = body.y2 }
	elseif not compact then
		state.layout.previewCollapsedStrip = { x1 = state.layout.nav.x2 + 1, y1 = body.y1,
			x2 = state.layout.nav.x2 + bodyGap + 25, y2 = body.y2 }
		state.layout.inspector.x1 = state.layout.previewCollapsedStrip.x2 + bodyGap
	end
	return state.layout
end

local function updatePane(pane, content, viewport)
	pane.content, pane.viewport = max(0, content or 0), max(0, viewport or 0)
	pane.maxScroll = max(0, pane.content - pane.viewport)
	pane.scroll = clamp(pane.scroll, 0, pane.maxScroll)
end

local function scrollbarFor(pane, bounds)
	if not bounds or pane.maxScroll <= 0 or pane.viewport <= 0 then
		pane.track, pane.thumb = nil, nil
		return nil
	end
	local track = { x1 = bounds.x2 - 10, y1 = bounds.y1, x2 = bounds.x2 - 2, y2 = bounds.y2 }
	local trackH = track.y2 - track.y1
	local thumbH = clamp(trackH * (pane.viewport / pane.content), 28, trackH)
	local travel = max(0, trackH - thumbH)
	local ratio = pane.maxScroll > 0 and pane.scroll / pane.maxScroll or 0
	local thumbY2 = track.y2 - ratio * travel
	pane.track = track
	pane.thumb = { x1 = track.x1, y1 = thumbY2 - thumbH, x2 = track.x2, y2 = thumbY2 }
	return pane.thumb
end

function Workspace.UpdatePane(state, name, content, viewport, bounds)
	local pane = state.panes[name]
	if not pane then return end
	updatePane(pane, content, viewport)
	scrollbarFor(pane, bounds)
end

function Workspace.SetInspectorKey(state, key)
	key = tostring(key or "default")
	if state.inspectorKey == key then return end
	if state.inspectorKey then state.inspectorScroll[state.inspectorKey] = state.panes.inspector.scroll end
	state.inspectorKey = key
	state.panes.inspector.scroll = state.inspectorScroll[key] or 0
end

function Workspace.Scroll(state, name, delta)
	local pane = state.panes[name]
	if not pane then return false end
	local before = pane.scroll
	pane.scroll = clamp(pane.scroll + delta, 0, pane.maxScroll)
	if name == "inspector" and state.inspectorKey then state.inspectorScroll[state.inspectorKey] = pane.scroll end
	return pane.scroll ~= before
end

function Workspace.MouseWheel(state, x, y, direction, shift)
	if not inside(state.bounds, x, y) then return false end
	if state.modal then
		Workspace.Scroll(state, "modal", direction > 0 and -72 or 72)
		return true
	end
	local layout = state.layout or {}
	local paneName = inside(layout.nav, x, y) and "nav" or inside(layout.inspector, x, y) and "inspector" or nil
	if paneName then
		local amount = shift and 24 or 72
		Workspace.Scroll(state, paneName, direction > 0 and -amount or amount)
	end
	return true
end

function Workspace.ScrollbarPress(state, x, y)
	for _, name in ipairs({ "modal", "nav", "inspector" }) do
		local pane = state.panes[name]
		if inside(pane.thumb, x, y) then
			state.dragScrollbar = { name = name, startY = y, startScroll = pane.scroll }
			return true
		elseif inside(pane.track, x, y) then
			local direction = y > pane.thumb.y2 and -1 or 1
			Workspace.Scroll(state, name, direction * max(40, pane.viewport * 0.88))
			return true
		end
	end
	return false
end

function Workspace.ScrollbarDrag(state, y)
	local drag = state.dragScrollbar
	if not drag then return false end
	local pane = state.panes[drag.name]
	local travel = (pane.track.y2 - pane.track.y1) - (pane.thumb.y2 - pane.thumb.y1)
	if travel > 0 then
		Workspace.Scroll(state, drag.name, (y - drag.startY) * -pane.maxScroll / travel + drag.startScroll - pane.scroll)
	end
	return true
end

function Workspace.EndPointer(state)
	local handled = state.dragScrollbar ~= nil or state.dividerDrag ~= nil
	state.dragScrollbar, state.dividerDrag = nil, nil
	return handled
end

function Workspace.DividerPress(state, x, y, now)
	local layout = state.layout or {}
	local kind = inside(layout.dividerNav, x, y) and "nav" or inside(layout.dividerInspector, x, y) and "preview" or nil
	if not kind then return false end
	now = tonumber(now) or 0
	local previous = state.lastDividerClick[kind]
	state.lastDividerClick[kind] = now
	if previous and now - previous <= 0.35 then
		if kind == "nav" then state.navWidth = 190 else state.previewWidth = 360 end
		state.dividerDrag = nil
		return "reset"
	end
	state.dividerDrag = { kind = kind, startX = x, startNav = state.navWidth, startPreview = state.previewWidth }
	return kind
end

function Workspace.DividerDrag(state, x)
	local drag = state.dividerDrag
	if not drag then return false end
	if drag.kind == "nav" then state.navWidth = clamp(drag.startNav + x - drag.startX, 164, 280)
	else state.previewWidth = clamp(drag.startPreview + x - drag.startX, 220, 900) end
	return true
end

function Workspace.TogglePreview(state, available)
	if not available then return false end
	state.previewCollapsed = not state.previewCollapsed
	return true
end

local function addFocus(state, item)
	if item and not item.disabled then state.focusItems[#state.focusItems + 1] = item end
end

local function addHit(state, hit, focusable)
	state.hits[#state.hits + 1] = hit
	if focusable then addFocus(state, hit) end
	return hit
end

local function focused(state, id)
	return state.focusId == id
end

local function findFocus(state, id)
	for index, item in ipairs(state.focusItems) do
		if item.id == id then return index, item end
	end
	return nil, nil
end

local function ensureFocusExists(state)
	local index = state.focusId and findFocus(state, state.focusId) or nil
	if not index then
		state.focusIndex = #state.focusItems > 0 and 1 or 0
		state.focusId = state.focusItems[1] and state.focusItems[1].id or nil
	else
		state.focusIndex = index
	end
end

function Workspace.EnsureFocusVisible(state)
	local _, item = findFocus(state, state.focusId)
	if not item or not item.virtualBounds or not item.pane then return false end
	local paneBounds = item.pane == "inspector" and state.inspectorViewport
		or item.pane == "modal" and state.modalViewport or state.navViewport
	local pane = state.panes[item.pane]
	if not paneBounds or not pane then return false end
	local top = item.virtualBounds.top
	local bottom = item.virtualBounds.bottom
	if top - pane.scroll > pane.viewport then pane.scroll = clamp(top - pane.viewport, 0, pane.maxScroll)
	elseif bottom - pane.scroll < 0 then pane.scroll = clamp(bottom, 0, pane.maxScroll) end
	if item.pane == "inspector" and state.inspectorKey then state.inspectorScroll[state.inspectorKey] = pane.scroll end
	return true
end

function Workspace.SetFocus(state, id)
	local index = findFocus(state, id)
	if not index then return false end
	state.focusId, state.focusIndex = id, index
	Workspace.EnsureFocusVisible(state)
	return true
end

function Workspace.MoveFocus(state, delta)
	if #state.focusItems == 0 then return nil end
	local index = state.focusIndex > 0 and state.focusIndex or 1
	index = ((index - 1 + delta) % #state.focusItems) + 1
	state.focusIndex, state.focusId = index, state.focusItems[index].id
	Workspace.EnsureFocusVisible(state)
	return state.focusItems[index]
end

function Workspace.FocusBoundary(state, last)
	if #state.focusItems == 0 then return nil end
	local index = last and #state.focusItems or 1
	state.focusIndex, state.focusId = index, state.focusItems[index].id
	Workspace.EnsureFocusVisible(state)
	return state.focusItems[index]
end

function Workspace.Page(state, direction)
	local _, item = findFocus(state, state.focusId)
	local paneName = item and item.pane or "inspector"
	local pane = state.panes[paneName] or state.panes.inspector
	Workspace.Scroll(state, paneName, direction * max(40, pane.viewport * 0.88))
	local wanted = direction > 0 and pane.scroll or pane.scroll + pane.viewport
	local candidate
	for _, focusItem in ipairs(state.focusItems) do
		if focusItem.pane == paneName and focusItem.virtualBounds then
			local distance = math.abs(focusItem.virtualBounds.bottom - wanted)
			if not candidate or distance < candidate.distance then candidate = { item = focusItem, distance = distance } end
		end
	end
	if candidate then Workspace.SetFocus(state, candidate.item.id) end
	return candidate and candidate.item or nil
end

function Workspace.Focused(state)
	local _, item = findFocus(state, state.focusId)
	return item
end

function Workspace.OpenModal(state, title, options, opener)
	state.modal = { title = tostring(title or "Choose"), options = options or {}, opener = opener or state.focusId, index = 1 }
	state.panes.modal.scroll = 0
	state.focusId = "modal:1"
end

function Workspace.CloseModal(state)
	if not state.modal then return false end
	local opener = state.modal.opener
	state.modal = nil
	state.panes.modal.scroll = 0
	state.focusId = opener
	return true
end

function Workspace.ToggleGroup(state, id)
	state.collapsed[id] = not state.collapsed[id]
	return state.collapsed[id]
end

function Workspace.FindHit(state, x, y)
	for index = #state.hits, 1, -1 do
		local hit = state.hits[index]
		if inside(hit, x, y) then return hit end
	end
	return nil
end

function Workspace.ComponentSearchResults(components, search)
	local result, needle = {}, string.lower(tostring(search or ""))
	for _, component in ipairs(components or {}) do
		local haystack = string.lower(tostring(component.label or "") .. " " .. tostring(component.group or ""))
		if needle == "" or string.find(haystack, needle, 1, true) then result[#result + 1] = component end
	end
	return result
end

local function groupTitle(scope, level, filterMode, labels)
	local title = labels and labels[scope] or tostring(scope or "Properties")
	if filterMode == "All" and level then title = title .. " / " .. level end
	return title
end

function Workspace.PropertyItems(rows, collapsed, filterMode, labels)
	local items, offset, previous = {}, 0, nil
	for index, row in ipairs(rows or {}) do
		local level = row[8] or "Basic"
		local semanticGroup = tostring(row[3] or ""):match("^[^/]+ / ([^/]+)")
		local group = tostring(row[1]) .. (semanticGroup and (":" .. semanticGroup) or (filterMode == "All" and (":" .. level) or ""))
		if group ~= previous then
			local title = semanticGroup and ((labels and labels[row[1]] or tostring(row[1])) .. " / " .. semanticGroup)
				or groupTitle(row[1], level, filterMode, labels)
			items[#items + 1] = { kind = "group", id = group, label = title, offset = offset, height = 30 }
			offset, previous = offset + 30, group
		end
		if not collapsed[group] then
			local propertyHeight = row[4] == "color" and 238 or 54
			items[#items + 1] = { kind = "property", id = tostring(row[1]) .. "." .. tostring(row[2]), row = row,
				rowIndex = index, offset = offset, height = propertyHeight, group = group }
			offset = offset + propertyHeight
		end
	end
	return items, offset
end

local function themeColor(theme, role, alpha)
	local prefix = role == "background" and "background" or role == "accent" and "accent"
		or role == "muted" and "muted" or role == "danger" and "danger" or "foreground"
	return { theme[prefix .. "R"] or 1, theme[prefix .. "G"] or 1, theme[prefix .. "B"] or 1, alpha == nil and 1 or alpha }
end

local function setColor(color)
	gl.Color(color[1], color[2], color[3], color[4])
end

local function rect(bounds, color)
	setColor(color); gl.Rect(bounds.x1, bounds.y1, bounds.x2, bounds.y2)
end

local function outline(bounds, color, thickness)
	setColor(color); thickness = thickness or 1
	for line = 0, thickness - 1 do
		gl.Rect(bounds.x1 + line, bounds.y1 + line, bounds.x2 - line, bounds.y1 + line + 1)
		gl.Rect(bounds.x1 + line, bounds.y2 - line - 1, bounds.x2 - line, bounds.y2 - line)
		gl.Rect(bounds.x1 + line, bounds.y1 + line, bounds.x1 + line + 1, bounds.y2 - line)
		gl.Rect(bounds.x2 - line - 1, bounds.y1 + line, bounds.x2 - line, bounds.y2 - line)
	end
end

local function label(text, x, y, size, color, options)
	setColor(color); gl.Text(tostring(text or ""), x, y, size, options or "o")
end

local function focusOutline(state, bounds, id, color)
	if focused(state, id) then outline(bounds, color, 2) end
end

local function button(state, bounds, id, textValue, action, colors, tooltip, disabled)
	rect(bounds, disabled and colors.disabled or colors.button)
	outline(bounds, colors.border, 1)
	label(textValue, (bounds.x1 + bounds.x2) * 0.5, bounds.y1 + max(5, (bounds.y2 - bounds.y1 - 11) * 0.5), 10, colors.text, "oc")
	local hit = { x1 = bounds.x1, y1 = bounds.y1, x2 = bounds.x2, y2 = bounds.y2, id = id,
		action = action, tooltip = tooltip or textValue, accessibleLabel = tooltip or textValue, disabled = disabled }
	if not disabled then addHit(state, hit, true) end
	focusOutline(state, bounds, id, colors.focus)
	return hit
end

local function drawScrollbar(state, name, colors)
	local pane = state.panes[name]
	if not pane.track then return end
	rect(pane.track, colors.scrollTrack)
	rect(pane.thumb, state.dragScrollbar and state.dragScrollbar.name == name and colors.scrollActive or colors.scrollThumb)
	outline(pane.thumb, colors.border, 1)
end

local function beginClip(bounds)
	gl.Scissor(bounds.x1, bounds.y1, bounds.x2 - bounds.x1, bounds.y2 - bounds.y1)
end

local function endClip()
	gl.Scissor(false)
end

local function workspaceColors(theme)
	return {
		background = themeColor(theme, "background", 0.98), panel = { 0.025, 0.045, 0.058, 0.98 },
		panelAlt = { 0.038, 0.070, 0.086, 0.98 }, header = { 0.045, 0.110, 0.132, 0.99 },
		button = { 0.055, 0.125, 0.148, 0.98 }, disabled = { 0.04, 0.055, 0.062, 0.72 },
		selected = { 0.08, 0.24, 0.28, 0.98 }, row = { 0.032, 0.062, 0.075, 0.96 },
		rowAlt = { 0.038, 0.073, 0.086, 0.96 }, input = { 0.015, 0.028, 0.036, 0.99 },
		text = themeColor(theme, "foreground", 1), muted = themeColor(theme, "muted", 0.94),
		accent = themeColor(theme, "accent", 1), focus = themeColor(theme, "accent", 1),
		border = themeColor(theme, "muted", 0.50), danger = themeColor(theme, "danger", 0.82),
		scrollTrack = { 0.015, 0.028, 0.035, 0.92 }, scrollThumb = themeColor(theme, "muted", 0.78),
		scrollActive = themeColor(theme, "accent", 0.92),
	}
end

local function drawHeader(state, spec, colors)
	local bounds = state.layout.header
	rect(bounds, colors.header)
	label(spec.title or "Controller UI Authoring", bounds.x1 + 16, bounds.y1 + 17, 18, colors.text)
	if spec.dirty then
		rect({ x1 = bounds.x1 + 260, y1 = bounds.y1 + 20, x2 = bounds.x1 + 268, y2 = bounds.y1 + 28 }, colors.accent)
	end
	label(spec.status or "Ready", bounds.x1 + 282, bounds.y1 + 19, 10, colors.muted)
	local close = { x1 = bounds.x2 - 38, y1 = bounds.y1 + 10, x2 = bounds.x2 - 10, y2 = bounds.y2 - 10 }
	button(state, close, "header:close", "X", { type = "close" }, colors, "Close editor (Escape)")
	addHit(state, { x1 = bounds.x1, y1 = bounds.y1, x2 = close.x1 - 6, y2 = bounds.y2,
		id = "header:move", action = { type = "move-window" }, accessibleLabel = "Move editor window" }, false)
end

local function drawToolbar(state, spec, colors)
	local bounds, x = state.layout.toolbar, state.layout.toolbar.x1
	rect(bounds, colors.panelAlt)
	local defs = {
		{ "Undo", 50, "undo", "Undo (Ctrl+Z)", spec.canUndo == false },
		{ "Redo", 50, "redo", "Redo (Ctrl+Y)", spec.canRedo == false },
		{ "Save", 52, "save", "Save personal settings (Ctrl+S)" },
		{ "Preview: " .. tostring(spec.previewContext or "Normal Gameplay"), 164, "preview-context", "Open categorized preview contexts" },
		{ state.layout.previewCollapsed and "Show pane" or "Hide pane", 66, "toggle-preview", "Show or collapse the live preview pane", not spec.previewAvailable },
		{ "Align", 54, "align-menu", "Alignment and distribution tools" },
		{ "Help", 48, "help", "Keyboard help (F1)" },
	}
	for _, def in ipairs(defs) do
		local b = { x1 = x, y1 = bounds.y1 + 6, x2 = x + def[2], y2 = bounds.y2 - 6 }
		button(state, b, "toolbar:" .. def[3], def[1], { type = def[3] }, colors, def[4], def[5])
		x = b.x2 + 5
	end
	local debug = { x1 = bounds.x2 - 64, y1 = bounds.y1 + 6, x2 = bounds.x2, y2 = bounds.y2 - 6 }
	button(state, debug, "toolbar:debug", spec.controllerDebugVisible and "Debug ON" or "Debug", { type = "toggle-debug" }, colors,
		"Show or hide the session-only Controller Debug panel")
	if spec.developer and bounds.x2 - x > 210 then
		local width = 64
		local draft = { x1 = debug.x1 - 2 * width - 12, y1 = bounds.y1 + 6, x2 = debug.x1 - width - 11, y2 = bounds.y2 - 6 }
		local publish = { x1 = debug.x1 - width - 7, y1 = bounds.y1 + 6, x2 = debug.x1 - 6, y2 = bounds.y2 - 6 }
		button(state, draft, "toolbar:draft", "Draft", { type = "draft" }, colors, "Save authoring draft (Ctrl+Shift+S)")
		button(state, publish, "toolbar:publish", "Publish", { type = "publish" }, colors, "Create explicit publish request (Ctrl+Alt+S)")
		if draft.x1 - x > 82 then
			local diagnostics = { x1 = draft.x1 - 78, y1 = bounds.y1 + 6, x2 = draft.x1 - 6, y2 = bounds.y2 - 6 }
			button(state, diagnostics, "toolbar:authoring-diagnostics", state.debugVisible and "Diag ON" or "Author Diag",
				{ type = "toggle-authoring-diagnostics" }, colors, "Show internal authoring diagnostics (separate from Controller Debug)")
		end
	end
end

local function navItems(state, components)
	local items, offset, previous = {}, 0, nil
	for _, component in ipairs(Workspace.ComponentSearchResults(components, state.componentSearch)) do
		local group = component.group or "Components"
		if group ~= previous then
			items[#items + 1] = { kind = "group", id = "nav-group:" .. group, label = group, offset = offset, height = 28 }
			offset, previous = offset + 28, group
		end
		if not state.navGroups[group] then
			items[#items + 1] = { kind = "component", id = "component:" .. component.id, component = component,
				offset = offset, height = 32 }
			offset = offset + 32
		end
	end
	return items, offset
end

local function drawNavSearch(state, pane, colors)
	local headerH = state.layout.navCollapsed and 42 or 72
	local collapse = { x1 = pane.x1 + 6, y1 = pane.y2 - 34, x2 = pane.x1 + 40, y2 = pane.y2 - 6 }
	button(state, collapse, "nav:collapse", state.layout.navCollapsed and ">" or "<", { type = "toggle-nav" }, colors,
		state.layout.navCollapsed and "Expand component browser" or "Collapse component browser", state.forcedNavCollapsed)
	if not state.layout.navCollapsed then
		label("Components", pane.x1 + 48, pane.y2 - 25, 12, colors.text)
		local search = { x1 = pane.x1 + 6, y1 = pane.y2 - 66, x2 = pane.x2 - 14, y2 = pane.y2 - 40 }
		rect(search, colors.input); outline(search, focused(state, "nav:search") and colors.focus or colors.border, focused(state, "nav:search") and 2 or 1)
		label(state.componentSearch ~= "" and state.componentSearch or "Find component", search.x1 + 7, search.y1 + 7, 10,
			state.componentSearch ~= "" and colors.text or colors.muted)
		addHit(state, { x1 = search.x1, y1 = search.y1, x2 = search.x2, y2 = search.y2, id = "nav:search",
			action = { type = "focus-component-search" }, tooltip = "Search components", accessibleLabel = "Search components" }, true)
	end
	return headerH
end

local function drawNav(state, spec, colors)
	local pane = state.layout.nav
	rect(pane, colors.panel)
	outline(pane, colors.border, 1)
	local headerH = drawNavSearch(state, pane, colors)
	local viewport = { x1 = pane.x1 + 4, y1 = pane.y1 + 4, x2 = pane.x2 - 2, y2 = pane.y2 - headerH }
	state.navViewport = viewport
	local items, content = navItems(state, spec.components)
	Workspace.UpdatePane(state, "nav", content, viewport.y2 - viewport.y1, viewport)
	local scroll = state.panes.nav.scroll
	beginClip(viewport)
	for _, item in ipairs(items) do
		local y2, y1 = viewport.y2 - item.offset + scroll, viewport.y2 - item.offset - item.height + scroll
		local virtual = { top = item.offset + item.height, bottom = item.offset }
		if item.kind == "group" then
			local action = { type = "toggle-nav-group", group = item.label }
			addFocus(state, { id = item.id, action = action, pane = "nav", virtualBounds = virtual, accessibleLabel = item.label .. " group" })
			if y2 >= viewport.y1 and y1 <= viewport.y2 and not state.layout.navCollapsed then
				local b = { x1 = viewport.x1 + 3, y1 = y1, x2 = viewport.x2 - 10, y2 = y2 }
				label((state.navGroups[item.label] and "+ " or "- ") .. item.label, b.x1 + 4, b.y1 + 8, 10, colors.muted)
				addHit(state, { x1 = b.x1, y1 = b.y1, x2 = b.x2, y2 = b.y2, id = item.id, action = action,
					tooltip = "Expand or collapse " .. item.label, accessibleLabel = item.label .. " group" }, false)
				focusOutline(state, b, item.id, colors.focus)
			end
		elseif item.kind == "component" then
			local component = item.component
			local action = { type = "select-component", component = component }
			addFocus(state, { id = item.id, action = action, pane = "nav", virtualBounds = virtual, accessibleLabel = component.label })
			if y2 >= viewport.y1 and y1 <= viewport.y2 then
				local selected = component.id == spec.selectedNav
				local b = { x1 = viewport.x1 + 3, y1 = y1 + 1, x2 = viewport.x2 - 10, y2 = y2 - 1 }
				rect(b, selected and colors.selected or colors.row)
				local short = component.icon or string.sub(component.label, 1, 1)
				label(short, b.x1 + 16, b.y1 + 9, 10, selected and colors.accent or colors.muted, "oc")
				if not state.layout.navCollapsed then label(component.label, b.x1 + 33, b.y1 + 9, 10, colors.text) end
				addHit(state, { x1 = b.x1, y1 = b.y1, x2 = b.x2, y2 = b.y2, id = item.id, action = action,
					tooltip = component.label, accessibleLabel = component.label }, false)
				focusOutline(state, b, item.id, colors.focus)
			end
		end
	end
	endClip()
	drawScrollbar(state, "nav", colors)
end

local function previewShape(spec, pane)
	local sourceW = spec.previewWidth or 420
	local sourceH = spec.previewHeight or 180
	local availableW, availableH = pane.x2 - pane.x1 - 34, pane.y2 - pane.y1 - 116
	local fit = min(availableW / sourceW, availableH / sourceH)
	local zoom = spec.previewFit and fit or min(fit, fit * (spec.previewZoom or 1))
	local width, height = max(36, sourceW * zoom), max(28, sourceH * zoom)
	local cx, cy = (pane.x1 + pane.x2) * 0.5, (pane.y1 + pane.y2 - 20) * 0.5
	return { x1 = cx - width * 0.5, y1 = cy - height * 0.5, x2 = cx + width * 0.5, y2 = cy + height * 0.5 }
end

local function drawPreview(state, spec, colors)
	local pane = state.layout.preview
	if not pane then return end
	rect(pane, { 0.012, 0.023, 0.031, 0.98 }); outline(pane, colors.border, 1)
	label("PRODUCTION RENDERER PREVIEW", pane.x1 + 12, pane.y2 - 24, 10, colors.muted)
	label(spec.previewLabel or "Selected component", pane.x1 + 12, pane.y2 - 44, 14, colors.text)
	if tostring(spec.previewContext or "Live") ~= "Live" then
		label("SIMULATED / NO GAMEPLAY COMMANDS", pane.x1 + 12, pane.y2 - 61, 9, colors.accent)
	end
	local fit = { x1 = pane.x2 - 112, y1 = pane.y2 - 34, x2 = pane.x2 - 76, y2 = pane.y2 - 8 }
	local less = { x1 = pane.x2 - 72, y1 = pane.y2 - 34, x2 = pane.x2 - 42, y2 = pane.y2 - 8 }
	local more = { x1 = pane.x2 - 38, y1 = pane.y2 - 34, x2 = pane.x2 - 8, y2 = pane.y2 - 8 }
	button(state, fit, "preview:fit", "Fit", { type = "preview-fit" }, colors, "Fit selected component in preview")
	button(state, less, "preview:zoom-out", "-", { type = "preview-zoom", delta = -0.1 }, colors, "Zoom preview out")
	button(state, more, "preview:zoom-in", "+", { type = "preview-zoom", delta = 0.1 }, colors, "Zoom preview in")
	local safe = { x1 = pane.x2 - 112, y1 = pane.y1 + 8, x2 = pane.x2 - 62, y2 = pane.y1 + 32 }
	local boundsToggle = { x1 = pane.x2 - 58, y1 = pane.y1 + 8, x2 = pane.x2 - 8, y2 = pane.y1 + 32 }
	button(state, safe, "preview:safe", "Safe", { type = "preview-safe" }, colors, "Toggle preview safe margins")
	button(state, boundsToggle, "preview:bounds", "Bounds", { type = "preview-bounds" }, colors, "Toggle preview selection bounds")
	for line = 1, 5 do
		local y = pane.y1 + (pane.y2 - pane.y1) * line / 6
		rect({ x1 = pane.x1 + 10, y1 = y, x2 = pane.x2 - 10, y2 = y + 1 }, { colors.muted[1], colors.muted[2], colors.muted[3], 0.10 })
	end
	local shape = previewShape({ previewWidth = spec.previewWidth, previewHeight = spec.previewHeight,
		previewFit = state.previewFit, previewZoom = state.previewZoom }, pane)
	if state.showSafeMargins then
		local safeBounds = { x1 = pane.x1 + 20, y1 = pane.y1 + 42, x2 = pane.x2 - 20, y2 = pane.y2 - 72 }
		outline(safeBounds, colors.muted, 1)
	end
	if type(spec.drawPreview) == "function" then spec.drawPreview(shape, colors)
	else label("Preview not available for this component", (pane.x1 + pane.x2) * 0.5, (pane.y1 + pane.y2) * 0.5, 11, colors.muted, "oc") end
	if state.showSelectionBounds then outline(shape, colors.accent, 2) end
	label(spec.previewDetail or "Drag and resize in the live view", pane.x1 + 12, pane.y1 + 16, 9, colors.muted)
end

local function drawPaneChrome(state, spec, colors)
	local layout = state.layout
	for _, item in ipairs({ { layout.dividerNav, "divider:nav", "Resize component and preview panes" },
		{ layout.dividerInspector, "divider:preview", "Resize preview and inspector panes" } }) do
		if item[1] then
			rect(item[1], colors.panelAlt)
			local cx = (item[1].x1 + item[1].x2) * 0.5
			rect({ x1 = cx - 1, y1 = (item[1].y1 + item[1].y2) * 0.5 - 18, x2 = cx + 1,
				y2 = (item[1].y1 + item[1].y2) * 0.5 + 18 }, colors.accent)
			addHit(state, { x1 = item[1].x1, y1 = item[1].y1, x2 = item[1].x2, y2 = item[1].y2,
				id = item[2], action = { type = "pane-divider", divider = item[2] }, tooltip = item[3], accessibleLabel = item[3] }, false)
		end
	end
	if layout.previewCollapsedStrip then
		local strip = layout.previewCollapsedStrip
		rect(strip, colors.panelAlt); outline(strip, colors.border, 1)
		label(layout.previewAvailable and "PREVIEW HIDDEN" or "NO PREVIEW", (strip.x1 + strip.x2) * 0.5,
			(strip.y1 + strip.y2) * 0.5 - 36, 9, colors.muted, "oc")
		addHit(state, { x1 = strip.x1, y1 = strip.y1, x2 = strip.x2, y2 = strip.y2, id = "preview:collapsed",
			action = { type = "toggle-preview" }, tooltip = layout.previewAvailable and "Show preview pane" or "Preview unavailable for this component",
			accessibleLabel = "Collapsed preview pane" }, layout.previewAvailable)
	end
end

local function valueText(spec, row)
	local id = tostring(row[1]) .. "." .. tostring(row[2])
	if spec.editingId == id then return tostring(spec.editingText or "") .. tostring(spec.composition or "") end
	local value = spec.getValue(row)
	if row[4] == "bool" then return value and "ON" or "OFF" end
	if row[4] == "number" then return string.format((row[7] or 1) >= 1 and "%.0f" or "%.3f", tonumber(value) or 0) end
	return tostring(value or "")
end

local function drawGradient(bounds, steps, sample)
	steps = max(2, steps or 18)
	for index = 0, steps - 1 do
		local left = bounds.x1 + (bounds.x2 - bounds.x1) * index / steps
		local right = bounds.x1 + (bounds.x2 - bounds.x1) * (index + 1) / steps
		rect({ x1 = left, y1 = bounds.y1, x2 = right + 1, y2 = bounds.y2 }, sample(index / max(1, steps - 1)))
	end
end

local function drawColorControl(state, spec, item, bounds, colors)
	local row = item.row; local value = spec.getColor and spec.getColor(row) or { r = 1, g = 1, b = 1, a = 1, h = 0, s = 0, v = 1, hex = "#FFFFFF" }
	local editor = { x1 = bounds.x1 + 8, y1 = bounds.y1 + 8, x2 = bounds.x2 - 8, y2 = bounds.y2 - 38 }
	local preview = { x1 = editor.x1, y1 = editor.y2 - 22, x2 = editor.x1 + 42, y2 = editor.y2 }
	rect(preview, { value.r, value.g, value.b, value.a }); outline(preview, colors.border, 1)
	label(tostring(value.hex or "#FFFFFF"), preview.x2 + 7, preview.y1 + 6, 9, colors.text)
	local actionX = max(editor.x1 + 132, editor.x2 - 132)
	for _, buttonDef in ipairs({ { "Copy", "color-copy" }, { "Paste", "color-paste" }, { "Fav", "color-favorite" } }) do
		local b = { x1 = actionX, y1 = preview.y1, x2 = actionX + 40, y2 = preview.y2 }
		button(state, b, buttonDef[2] .. ":" .. item.id, buttonDef[1], { type = buttonDef[2], row = row, rowIndex = item.rowIndex }, colors,
			buttonDef[1] == "Fav" and "Save or remove this favorite color" or buttonDef[1] .. " exact RGBA color")
		actionX = b.x2 + 3
	end

	local sliderTop = preview.y1 - 7; local sliderHeight, sliderGap = 16, 5
	local channels = {
		{ id = "h", label = "H", value = (value.h or 0) / 360, sample = function(t) local r, g, b = spec.hsvToRgb(t * 360, 1, 1); return { r, g, b, 1 } end },
		{ id = "s", label = "S", value = value.s or 0, sample = function(t) local r, g, b = spec.hsvToRgb(value.h or 0, t, value.v or 1); return { r, g, b, 1 } end },
		{ id = "v", label = "V", value = value.v or 0, sample = function(t) local r, g, b = spec.hsvToRgb(value.h or 0, value.s or 0, t); return { r, g, b, 1 } end },
		{ id = "a", label = "A", value = value.a or 1, sample = function(t) return { value.r, value.g, value.b, t } end },
	}
	for index, channel in ipairs(channels) do
		local y2 = sliderTop - (index - 1) * (sliderHeight + sliderGap); local field = { x1 = editor.x2 - 38, y1 = y2 - sliderHeight, x2 = editor.x2, y2 = y2 }
		local control = { x1 = editor.x1 + 22, y1 = y2 - sliderHeight, x2 = field.x1 - 4, y2 = y2 }
		label(channel.label, editor.x1 + 2, control.y1 + 4, 9, colors.muted)
		if channel.id == "a" then
			local checker = 6; for checkerIndex = 0, math.ceil((control.x2 - control.x1) / checker) - 1 do
				local x1 = control.x1 + checkerIndex * checker; rect({ x1 = x1, y1 = control.y1, x2 = min(control.x2, x1 + checker), y2 = control.y2 }, checkerIndex % 2 == 0 and { 0.25, 0.25, 0.25, 1 } or { 0.55, 0.55, 0.55, 1 })
			end
		end
		drawGradient(control, channel.id == "h" and 24 or 18, channel.sample); outline(control,
			spec.colorWheelEditingId == item.id .. ":" .. channel.id and colors.focus or colors.border,
			spec.colorWheelEditingId == item.id .. ":" .. channel.id and 2 or 1)
		local markerX = control.x1 + clamp(channel.value, 0, 1) * (control.x2 - control.x1)
		rect({ x1 = markerX - 1, y1 = control.y1 - 2, x2 = markerX + 2, y2 = control.y2 + 2 }, colors.text)
		addHit(state, { x1 = control.x1, y1 = control.y1, x2 = control.x2, y2 = control.y2,
			id = "color-slider:" .. item.id .. ":" .. channel.id,
			action = { type = "color-slider", row = row, rowIndex = item.rowIndex, channel = channel.id, control = control },
			tooltip = "Drag " .. channel.label .. "; focused wheel edits only this channel", accessibleLabel = channel.label .. " color slider" }, false)
		rect(field, colors.input); outline(field, spec.editingColorId == item.id .. ":" .. channel.id and colors.focus or colors.border, spec.editingColorId == item.id .. ":" .. channel.id and 2 or 1)
		local numeric = channel.id == "h" and math.floor((value.h or 0) + 0.5) or math.floor((channel.value or 0) * 100 + 0.5)
		local numericText = spec.editingColorId == item.id .. ":" .. channel.id and tostring(spec.editingText or "") or tostring(numeric)
		label(numericText, (field.x1 + field.x2) * 0.5, field.y1 + 4, 8, colors.text, "oc")
		addHit(state, { x1 = field.x1, y1 = field.y1, x2 = field.x2, y2 = field.y2,
			id = "color-number:" .. item.id .. ":" .. channel.id,
			action = { type = "color-number-entry", row = row, rowIndex = item.rowIndex, channel = channel.id },
			tooltip = "Enter exact " .. channel.label .. (channel.id == "h" and " degrees" or " percent"), accessibleLabel = "Exact " .. channel.label .. " color value" }, false)
	end

	local presets = spec.colorPresets or {}; local columns, gap = 10, 4
	local swatchSize = min(19, max(13, (editor.x2 - editor.x1 - (columns - 1) * gap) / columns))
	local swatchTop = sliderTop - #channels * (sliderHeight + sliderGap) - 3
	local bestIndex, bestDistance
	for index, preset in ipairs(presets) do
		local distance = math.abs(value.r - preset[2]) + math.abs(value.g - preset[3]) + math.abs(value.b - preset[4]) + math.abs(value.a - (preset[5] or 1))
		if not bestDistance or distance < bestDistance then bestDistance, bestIndex = distance, index end
	end
	for index, preset in ipairs(presets) do
		local column, line = (index - 1) % columns, math.floor((index - 1) / columns)
		local x1 = editor.x1 + column * (swatchSize + gap); local y2 = swatchTop - line * (swatchSize + gap)
		local swatch = { x1 = x1, y1 = y2 - swatchSize, x2 = x1 + swatchSize, y2 = y2 }
		rect(swatch, { preset[2], preset[3], preset[4], preset[5] or 1 }); outline(swatch, index == bestIndex and colors.focus or colors.border, index == bestIndex and 2 or 1)
		local focusID = "color-swatch:" .. item.id .. ":" .. tostring(index)
		local action = { type = "color-swatch", row = row, rowIndex = item.rowIndex, preset = preset, presetIndex = index }
		addHit(state, { x1 = swatch.x1, y1 = swatch.y1, x2 = swatch.x2, y2 = swatch.y2, id = focusID, action = action,
			tooltip = tostring(preset[1]), accessibleLabel = "Apply " .. tostring(preset[1]) .. " color" }, false)
		addFocus(state, { id = focusID, action = action, pane = "inspector", virtualBounds = { top = item.offset + item.height, bottom = item.offset },
			row = row, rowIndex = item.rowIndex, accessibleLabel = "Apply " .. tostring(preset[1]) .. " color" })
		focusOutline(state, swatch, focusID, colors.focus)
	end
end

local function drawPropertyControl(state, spec, item, bounds, colors)
	local row, kind = item.row, item.row[4]
	local control = { x1 = bounds.x1 + max(150, (bounds.x2 - bounds.x1) * 0.48), y1 = bounds.y1 + 8,
		x2 = bounds.x2 - 8, y2 = bounds.y2 - 8 }
	local action = { type = "property-control", row = row, rowIndex = item.rowIndex, kind = kind, control = control }
	if kind == "color" then
		drawColorControl(state, spec, item, bounds, colors)
	elseif kind == "bool" then
		rect(control, spec.getValue(row) and colors.selected or colors.input)
		outline(control, colors.border, 1)
		label(valueText(spec, row), (control.x1 + control.x2) * 0.5, control.y1 + 10, 10, spec.getValue(row) and colors.accent or colors.muted, "oc")
		addHit(state, { x1 = control.x1, y1 = control.y1, x2 = control.x2, y2 = control.y2, id = "control:" .. item.id,
			action = action, tooltip = "Toggle " .. tostring(row[3]), accessibleLabel = tostring(row[3]) .. " " .. valueText(spec, row) }, false)
	elseif kind == "number" then
		local wheelEditing = spec.wheelEditingId == item.id
		local minus = { x1 = control.x1, y1 = control.y1, x2 = control.x1 + 24, y2 = control.y2 }
		local plus = { x1 = control.x2 - 24, y1 = control.y1, x2 = control.x2, y2 = control.y2 }
		local field = { x1 = max(minus.x2 + 48, plus.x1 - 58), y1 = control.y1, x2 = plus.x1 - 2, y2 = control.y2 }
		local slider = { x1 = minus.x2 + 2, y1 = control.y1, x2 = field.x1 - 2, y2 = control.y2 }
		rect(minus, colors.button); rect(plus, colors.button); rect(field, colors.input); rect(slider, colors.input)
		outline(minus, colors.border, 1); outline(plus, colors.border, 1)
		outline(field, wheelEditing and colors.focus or colors.border, wheelEditing and 2 or 1)
		outline(slider, wheelEditing and colors.focus or colors.border, wheelEditing and 2 or 1)
		local ratio = ((tonumber(spec.getValue(row)) or row[5]) - row[5]) / max(0.00001, row[6] - row[5])
		rect({ x1 = slider.x1 + 3, y1 = slider.y1 + 3, x2 = slider.x1 + 3 + max(0, slider.x2 - slider.x1 - 6) * clamp(ratio, 0, 1), y2 = slider.y1 + 7 }, colors.accent)
		label("-", (minus.x1 + minus.x2) * 0.5, minus.y1 + 9, 12, colors.text, "oc")
		label("+", (plus.x1 + plus.x2) * 0.5, plus.y1 + 9, 12, colors.text, "oc")
		label(valueText(spec, row), (field.x1 + field.x2) * 0.5, field.y1 + 10, 9, colors.text, "oc")
		if wheelEditing then label("WHEEL", slider.x1 + 4, slider.y1 + 10, 7, colors.focus, "o") end
		addHit(state, { x1 = minus.x1, y1 = minus.y1, x2 = minus.x2, y2 = minus.y2, id = "minus:" .. item.id,
			action = { type = "property-step", row = row, rowIndex = item.rowIndex, delta = -1 }, tooltip = "Decrease " .. row[3], accessibleLabel = "Decrease " .. row[3] }, false)
		addHit(state, { x1 = plus.x1, y1 = plus.y1, x2 = plus.x2, y2 = plus.y2, id = "plus:" .. item.id,
			action = { type = "property-step", row = row, rowIndex = item.rowIndex, delta = 1 }, tooltip = "Increase " .. row[3], accessibleLabel = "Increase " .. row[3] }, false)
		addHit(state, { x1 = slider.x1, y1 = slider.y1, x2 = slider.x2, y2 = slider.y2, id = "slider:" .. item.id,
			action = { type = "property-slider", row = row, rowIndex = item.rowIndex, control = slider }, tooltip = "Drag to adjust " .. row[3], accessibleLabel = "Slider " .. row[3] }, false)
		addHit(state, { x1 = field.x1, y1 = field.y1, x2 = field.x2, y2 = field.y2, id = "number:" .. item.id,
			action = { type = "property-number-entry", row = row, rowIndex = item.rowIndex }, tooltip = "Type a value for " .. row[3], accessibleLabel = "Numeric field " .. row[3] }, false)
	else
		rect(control, colors.input); outline(control, colors.border, 1)
		local suffix = kind == "enum" and "  [Choose]" or ""
		label(valueText(spec, row) .. suffix, control.x1 + 7, control.y1 + 10, 10, colors.text)
		addHit(state, { x1 = control.x1, y1 = control.y1, x2 = control.x2, y2 = control.y2, id = "control:" .. item.id,
			action = action, tooltip = tostring(row[3]), accessibleLabel = tostring(row[3]) .. " " .. valueText(spec, row) }, false)
	end
end

local function drawInspectorHeader(state, spec, pane, colors)
	local filterH, actionsH = 70, 66
	label(spec.tabName or "Properties", pane.x1 + 10, pane.y2 - 23, 13, colors.text)
	local search = { x1 = pane.x1 + 10, y1 = pane.y2 - 60, x2 = pane.x2 - 12, y2 = pane.y2 - 34 }
	rect(search, colors.input); outline(search, focused(state, "inspector:search") and colors.focus or colors.border,
		focused(state, "inspector:search") and 2 or 1)
	label(spec.search ~= "" and spec.search or "Search properties (Ctrl+F)", search.x1 + 7, search.y1 + 7, 10,
		spec.search ~= "" and colors.text or colors.muted)
	addHit(state, { x1 = search.x1, y1 = search.y1, x2 = search.x2, y2 = search.y2, id = "inspector:search",
		action = { type = "focus-property-search" }, tooltip = "Search properties", accessibleLabel = "Search properties" }, true)
	if state.debugVisible and spec.selectedNav == "advanced" then
		filterH = filterH + 72
		local panel = { x1 = pane.x1 + 8, y1 = pane.y2 - 136, x2 = pane.x2 - 8, y2 = pane.y2 - 66 }
		rect(panel, colors.input); outline(panel, colors.danger, 1)
		label("DEBUG / SESSION ONLY", panel.x1 + 8, panel.y2 - 20, 9, colors.danger)
		label(spec.debugInfo or "Modal ownership active; no gameplay commands", panel.x1 + 8, panel.y2 - 40, 9, colors.muted)
		local audit = { x1 = panel.x2 - 62, y1 = panel.y1 + 6, x2 = panel.x2 - 6, y2 = panel.y1 + 30 }
		button(state, audit, "debug:audit", "Audit", { type = "debug-audit" }, colors, "Write one controller UI audit summary to the console")
	end
	local actionsY1 = pane.y1 + 4
	local selected = spec.rows and spec.rows[spec.selectedRow]
	local x = pane.x1 + 8
	for _, def in ipairs({
		{ "Favorite", 64, "favorite-property", "Favorite selected property" },
		{ "Reset", 52, "reset-property", "Reset selected property" },
		{ "More", 48, "property-menu", "Saved value and shipping-default actions" },
	}) do
		local b = { x1 = x, y1 = actionsY1, x2 = x + def[2], y2 = actionsY1 + 26 }
		button(state, b, "inspector:" .. def[3], def[1], { type = def[3], row = selected }, colors, def[4], selected == nil)
		x = b.x2 + 4
	end
	local filter = { x1 = pane.x1 + 8, y1 = actionsY1 + 32, x2 = min(pane.x2 - 8, pane.x1 + 158), y2 = actionsY1 + 58 }
	button(state, filter, "filter:menu", "View: " .. tostring(spec.filterMode or "Basic"), { type = "filter-menu" }, colors,
		"Choose Basic, Advanced, All, Favorites, Recent, or Modified properties")
	return filterH, actionsH
end

local function drawInspectorItems(state, spec, viewport, items, colors)
	local scroll = state.panes.inspector.scroll
	beginClip(viewport)
	for _, item in ipairs(items) do
		local y2, y1 = viewport.y2 - item.offset + scroll, viewport.y2 - item.offset - item.height + scroll
		local virtual = { top = item.offset + item.height, bottom = item.offset }
		if item.kind == "group" then
			local action = { type = "toggle-property-group", group = item.id }
			addFocus(state, { id = "group:" .. item.id, action = action, pane = "inspector", virtualBounds = virtual,
				accessibleLabel = item.label .. " property group" })
			if y2 >= viewport.y1 and y1 <= viewport.y2 then
				local b = { x1 = viewport.x1 + 4, y1 = y1 + 1, x2 = viewport.x2 - 12, y2 = y2 - 1 }
				rect(b, colors.panelAlt)
				label((state.collapsed[item.id] and "+ " or "- ") .. item.label, b.x1 + 7, b.y1 + 9, 10, colors.muted)
				addHit(state, { x1 = b.x1, y1 = b.y1, x2 = b.x2, y2 = b.y2, id = "group:" .. item.id,
					action = action, tooltip = "Expand or collapse " .. item.label, accessibleLabel = item.label .. " property group" }, false)
				focusOutline(state, b, "group:" .. item.id, colors.focus)
			end
		else
			local rowId = "property:" .. item.id
			local action = { type = "focus-property", row = item.row, rowIndex = item.rowIndex }
			addFocus(state, { id = rowId, action = action, pane = "inspector", virtualBounds = virtual,
				row = item.row, rowIndex = item.rowIndex, accessibleLabel = tostring(item.row[3]) })
			if y2 >= viewport.y1 and y1 <= viewport.y2 then
				local b = { x1 = viewport.x1 + 4, y1 = y1 + 2, x2 = viewport.x2 - 12, y2 = y2 - 2 }
				local selected = item.rowIndex == spec.selectedRow
				rect(b, selected and colors.selected or (item.rowIndex % 2 == 0 and colors.rowAlt or colors.row))
				addHit(state, { x1 = b.x1, y1 = b.y1, x2 = b.x2, y2 = b.y2, id = rowId, action = action,
					tooltip = tostring(item.row[3]), accessibleLabel = tostring(item.row[3]) }, false)
				label(item.row[3], b.x1 + 9, b.y2 - 20, 10, colors.text)
				local source = spec.getSource and spec.getSource(item.row) or "personal"
				local flags = (spec.isModified and spec.isModified(item.row) and "modified / " or "")
					.. (spec.isEnforced and spec.isEnforced(item.row) and "locked / " or "") .. source
				label(flags, b.x1 + 9, b.y1 + 7, 8, colors.muted)
				drawPropertyControl(state, spec, item, b, colors)
				focusOutline(state, b, rowId, colors.focus)
			end
		end
	end
	endClip()
end

local function drawInspector(state, spec, colors)
	local pane = state.layout.inspector
	rect(pane, colors.panel); outline(pane, colors.border, 1)
	local headerH, actionsH = drawInspectorHeader(state, spec, pane, colors)
	local viewport = { x1 = pane.x1 + 4, y1 = pane.y1 + actionsH + 3, x2 = pane.x2 - 2, y2 = pane.y2 - headerH }
	state.inspectorViewport = viewport
	Workspace.SetInspectorKey(state, tostring(spec.inspectorKey or (tostring(spec.tabName or "") .. "|" .. tostring(spec.filterMode or ""))))
	local items, content = Workspace.PropertyItems(spec.rows, state.collapsed, spec.filterMode, spec.scopeLabels)
	Workspace.UpdatePane(state, "inspector", content, viewport.y2 - viewport.y1, viewport)
	if #items == 0 then label(spec.emptyText or "No properties match this view.", viewport.x1 + 10, viewport.y2 - 28, 11, colors.muted) end
	drawInspectorItems(state, spec, viewport, items, colors)
	drawScrollbar(state, "inspector", colors)
end

local function drawFooter(state, spec, colors)
	local pane, x = state.layout.footer, state.layout.footer.x1
	rect(pane, colors.panelAlt)
	local defs = {
		{ "Reset section", 94, "reset-section", "Reset the visible section" },
		{ "Reset all", 70, "reset-all", "Reset all controller UI settings" },
		{ "Save preset", 78, "save-preset", "Save selected component preset" },
		{ "Apply preset", 82, "apply-preset", "Apply selected component preset" },
	}
	for _, def in ipairs(defs) do
		local b = { x1 = x + 4, y1 = pane.y1 + 4, x2 = x + def[2], y2 = pane.y2 - 4 }
		button(state, b, "footer:" .. def[3], def[1], { type = def[3] }, colors, def[4])
		x = b.x2 + 4
	end
	label("Tab: focus  |  Arrows: navigate/adjust  |  F1: help", pane.x2 - 34, pane.y1 + 10, 9, colors.muted, "or")
	local resize = { x1 = pane.x2 - 22, y1 = pane.y1 + 1, x2 = pane.x2, y2 = pane.y1 + 23 }
	for line = 0, 2 do
		rect({ x1 = resize.x2 - 5 - line * 5, y1 = resize.y1 + 3, x2 = resize.x2 - 3, y2 = resize.y1 + 5 + line * 5 }, colors.accent)
	end
	addHit(state, { x1 = resize.x1, y1 = resize.y1, x2 = resize.x2, y2 = resize.y2, id = "footer:resize",
		action = { type = "resize-window" }, tooltip = "Resize editor window", accessibleLabel = "Resize editor window" }, false)
end

local function modalBounds(state, optionCount)
	local bounds = state.bounds
	local width, height = min(420, bounds.width - 40), min(bounds.height - 50, 72 + optionCount * 30)
	return { x1 = (bounds.x1 + bounds.x2 - width) * 0.5, y1 = (bounds.y1 + bounds.y2 - height) * 0.5,
		x2 = (bounds.x1 + bounds.x2 + width) * 0.5, y2 = (bounds.y1 + bounds.y2 + height) * 0.5 }
end

local function drawModal(state, colors)
	local modal = state.modal
	if not modal then return end
	local bounds = modalBounds(state, #modal.options)
	rect(state.bounds, { 0, 0, 0, 0.54 })
	rect(bounds, colors.panelAlt); outline(bounds, colors.focus, 2)
	label(modal.title, bounds.x1 + 12, bounds.y2 - 28, 13, colors.text)
	state.hits, state.focusItems = {}, {}
	addHit(state, { x1 = state.bounds.x1, y1 = state.bounds.y1, x2 = state.bounds.x2, y2 = state.bounds.y2,
		id = "modal:backdrop", action = { type = "close-modal" }, accessibleLabel = "Close menu" }, false)
	local viewport = { x1 = bounds.x1 + 8, y1 = bounds.y1 + 10, x2 = bounds.x2 - 4, y2 = bounds.y2 - 42 }
	state.modalViewport = viewport
	local entries, content, offset = {}, 0, 0
	for index, option in ipairs(modal.options) do
		local height = option.heading and 24 or 30
		entries[#entries + 1] = { index = index, option = option, offset = offset, height = height }
		offset, content = offset + height, offset + height
	end
	Workspace.UpdatePane(state, "modal", content, viewport.y2 - viewport.y1, viewport)
	local scroll = state.panes.modal.scroll
	beginClip(viewport)
	for _, entry in ipairs(entries) do
		local option, index = entry.option, entry.index
		local y2 = viewport.y2 - entry.offset + scroll
		local y1 = y2 - entry.height
		local virtual = { top = entry.offset + entry.height, bottom = entry.offset }
		if option.heading then
			if y2 >= viewport.y1 and y1 <= viewport.y2 then label(string.upper(tostring(option.label)), viewport.x1 + 7, y1 + 7, 9, colors.muted) end
		else
			local id = "modal:" .. index
			local action = { type = "modal-option", option = option, index = index }
			addFocus(state, { id = id, action = action, pane = "modal", virtualBounds = virtual,
				disabled = option.disabled, accessibleLabel = option.label })
			if y2 >= viewport.y1 and y1 <= viewport.y2 then
				local b = { x1 = viewport.x1 + 2, y1 = y1 + 1, x2 = viewport.x2 - 10, y2 = y2 - 1 }
				rect(b, option.disabled and colors.disabled or colors.button); outline(b, colors.border, 1)
				label(option.label, (b.x1 + b.x2) * 0.5, b.y1 + max(5, (b.y2 - b.y1 - 11) * 0.5), 10, colors.text, "oc")
				if not option.disabled then addHit(state, { x1 = b.x1, y1 = b.y1, x2 = b.x2, y2 = b.y2, id = id,
					action = action, tooltip = option.tooltip or option.label, accessibleLabel = option.label }, false) end
				focusOutline(state, b, id, colors.focus)
			end
		end
	end
	endClip()
	drawScrollbar(state, "modal", colors)
	ensureFocusExists(state)
end

local function drawHelp(state, colors)
	if not state.showHelp or state.modal then return end
	local options = {
		{ label = "Tab / Shift+Tab    Next / previous control", disabled = true },
		{ label = "Arrows              Navigate or adjust", disabled = true },
		{ label = "Page Up / Down      Scroll by one page", disabled = true },
		{ label = "Home / End          First / final control", disabled = true },
		{ label = "Enter / Space       Activate selected control", disabled = true },
		{ label = "Ctrl+F / Ctrl+S     Search / save", disabled = true },
		{ label = "Escape              Back or close editor", action = "close-help" },
	}
	Workspace.OpenModal(state, "Keyboard help", options, state.focusId)
end

local function drawTooltip(state, colors)
	if state.modal or not Spring or type(Spring.GetMouseState) ~= "function" then return end
	local x, y = Spring.GetMouseState()
	local hit = Workspace.FindHit(state, x, y)
	state.hovered = hit
	if not hit or not hit.tooltip then return end
	local width = clamp(#tostring(hit.tooltip) * 6.2 + 18, 120, 360)
	local tx = clamp(x + 14, state.bounds.x1 + 4, state.bounds.x2 - width - 4)
	local ty = clamp(y + 14, state.bounds.y1 + 4, state.bounds.y2 - 34)
	local b = { x1 = tx, y1 = ty, x2 = tx + width, y2 = ty + 28 }
	rect(b, colors.panelAlt); outline(b, colors.focus, 1); label(hit.tooltip, b.x1 + 8, b.y1 + 8, 10, colors.text)
end

function Workspace.Draw(state, spec)
	if not gl then return end
	Workspace.SetBounds(state, spec.bounds, spec)
	state.hits, state.focusItems = {}, {}
	local colors = workspaceColors(spec.theme or {})
	rect(state.bounds, colors.background); outline(state.bounds, colors.focus, 1)
	drawHeader(state, spec, colors)
	drawToolbar(state, spec, colors)
	drawNav(state, spec, colors)
	drawPreview(state, spec, colors)
	drawInspector(state, spec, colors)
	drawPaneChrome(state, spec, colors)
	drawFooter(state, spec, colors)
	ensureFocusExists(state)
	if state.showHelp then drawHelp(state, colors) end
	if state.modal then drawModal(state, colors) end
	drawTooltip(state, colors)
	return state.hits
end

function Workspace.OpenPropertyMenu(state, row, developer, hasSaved)
	local options = {
		{ label = "Favorite / unfavorite", action = "favorite", row = row },
		{ label = "Reset property", action = "reset", row = row },
		{ label = "Save current value", action = "save-value", row = row },
		{ label = "Apply saved value", action = "apply-value", row = row, disabled = not hasSaved },
	}
	if developer then options[#options + 1] = { label = "Toggle shipping lock", action = "toggle-enforcement", row = row } end
	Workspace.OpenModal(state, tostring(row and row[3] or "Property actions"), options, state.focusId)
end

function Workspace.OpenAlignmentMenu(state)
	Workspace.OpenModal(state, "Alignment and distribution", {
		{ label = "Align left", action = "align-left" }, { label = "Center horizontally", action = "align-hcenter" },
		{ label = "Align right", action = "align-right" }, { label = "Align bottom", action = "align-bottom" },
		{ label = "Center vertically", action = "align-vcenter" }, { label = "Align top", action = "align-top" },
		{ label = "Distribute horizontally", action = "distribute-horizontal" },
		{ label = "Distribute vertically", action = "distribute-vertical" },
	}, state.focusId)
end

function Workspace.OpenEnumMenu(state, row, options, value)
	local entries = {}
	for _, option in ipairs(options or {}) do entries[#entries + 1] = { label = (option == value and "Selected: " or "") .. tostring(option),
		action = "set-enum", row = row, value = option } end
	Workspace.OpenModal(state, tostring(row and row[3] or "Choose value"), entries, state.focusId)
end

function Workspace.OpenFilterMenu(state, current)
	local options = {}
	for _, mode in ipairs({ "Basic", "Advanced", "All", "Favorites", "Recent", "Modified" }) do
		options[#options + 1] = { label = (mode == current and "Selected: " or "") .. mode, action = "set-filter", value = mode }
	end
	Workspace.OpenModal(state, "Property view", options, state.focusId)
end

function Workspace.OpenPreviewMenu(state, entries)
	Workspace.OpenModal(state, "Preview context", entries or {}, "toolbar:preview-context")
end

Workspace.Clamp = clamp
Workspace.Inside = inside

return Workspace
